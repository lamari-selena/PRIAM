<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:444166bb-c487-4308-9a5d-c586fae7fd99(PRIAM_LANGUAGE.sandbox)">
  <persistence version="9" />
  <languages>
    <use id="e02dfeab-630f-4f6d-86a8-a0833a3f70fc" name="PRIAM_LANGUAGE" version="0" />
    <use id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage" version="11" />
    <use id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core" version="2" />
    <use id="3ecd7c84-cde3-45de-886c-135ecc69b742" name="jetbrains.mps.lang.refactoring" version="0" />
  </languages>
  <imports />
  <registry>
    <language id="e02dfeab-630f-4f6d-86a8-a0833a3f70fc" name="PRIAM_LANGUAGE">
      <concept id="699862489961106632" name="PRIAM_LANGUAGE.structure.PersonalData" flags="ng" index="8tInM">
        <property id="699862489961106650" name="dataConservation" index="8tInw" />
        <property id="6834132425656832624" name="source" index="__Elb" />
        <reference id="7072058747586032807" name="personalDataCategory" index="1aEWHh" />
      </concept>
      <concept id="3526323479971544488" name="PRIAM_LANGUAGE.structure.Actor" flags="ng" index="2y8F$H">
        <property id="4542680411326421431" name="id" index="Ed$TN" />
        <property id="5319992952818338717" name="country" index="TxubU" />
      </concept>
      <concept id="3526323479971544491" name="PRIAM_LANGUAGE.structure.DataSubject" flags="ng" index="2y8F$I">
        <property id="3526323479971544499" name="age" index="2y8F$Q" />
        <property id="4542680411326009908" name="idRef" index="Ef8nK" />
        <reference id="4542680411326349652" name="dsCategory" index="Eclqg" />
      </concept>
      <concept id="6834132425656841904" name="PRIAM_LANGUAGE.structure.DataRef" flags="ng" index="__C6b">
        <reference id="2744329693372584821" name="dataref" index="3e4$8_" />
        <child id="6834132425656841907" name="dataUsage" index="__C68" />
      </concept>
      <concept id="6834132425656832533" name="PRIAM_LANGUAGE.structure.Consent" flags="ng" index="__EkI">
        <property id="6834132425656832614" name="endDate" index="__Elt" />
        <property id="6834132425656832612" name="startDate" index="__Elv" />
        <child id="6834132425656832581" name="processing" index="__ElY" />
      </concept>
      <concept id="6834132425656832631" name="PRIAM_LANGUAGE.structure.DataUsage" flags="ng" index="__Elc">
        <property id="6834132425656834002" name="u" index="__E3D" />
        <property id="6834132425656834007" name="d" index="__E3G" />
        <property id="6834132425656833995" name="c" index="__E3K" />
        <property id="6834132425656833993" name="hasPersonalUsage" index="__E3M" />
        <property id="6834132425656833998" name="r" index="__E3P" />
      </concept>
      <concept id="6834132425656832617" name="PRIAM_LANGUAGE.structure.Data" flags="ng" index="__Eli">
        <property id="4542680411328450152" name="id" index="EklAG" />
        <reference id="23373094781276817" name="dataType" index="2NV_G_" />
      </concept>
      <concept id="6834132425656832578" name="PRIAM_LANGUAGE.structure.Processing" flags="ng" index="__ElT">
        <property id="6834132425656832588" name="createDate" index="__ElR" />
        <property id="6834132425656832583" name="tp" index="__ElW" />
        <property id="8429905822917321402" name="id" index="341Iwk" />
        <child id="6834132425656838581" name="purposes" index="__DUe" />
        <child id="6834132425656832620" name="dataUsed" index="__Eln" />
      </concept>
      <concept id="6834132425656835441" name="PRIAM_LANGUAGE.structure.Purpose" flags="ng" index="__EDa">
        <property id="6834132425656835442" name="description" index="__ED9" />
        <property id="6834132425656835444" name="type" index="__EDf" />
      </concept>
      <concept id="6834132425656797650" name="PRIAM_LANGUAGE.structure.Contract" flags="ng" index="__NVD">
        <property id="6834132425656797685" name="Expirationdate" index="__NVe" />
        <property id="6834132425656797653" name="Signaturedate" index="__NVI" />
        <property id="4542680411327850649" name="id" index="EmbXt" />
        <reference id="5799940921479927994" name="dataSubject" index="2RrpWN" />
        <child id="6834132425656832576" name="consent" index="__ElV" />
      </concept>
      <concept id="4542680411326545150" name="PRIAM_LANGUAGE.structure.DataRequestAnswer" flags="ng" index="EdaGU">
        <property id="4542680411326545153" name="answer" index="EdaF5" />
        <reference id="4542680411326545156" name="request" index="EdaF0" />
      </concept>
      <concept id="2801828014617315133" name="PRIAM_LANGUAGE.structure.ProcessingRef" flags="ng" index="FSH21">
        <property id="6510921239613172442" name="consented" index="2_ULE4" />
        <reference id="2801828014617406486" name="processing" index="FS3IE" />
      </concept>
      <concept id="23373094781276816" name="PRIAM_LANGUAGE.structure.DataType" flags="ng" index="2NV_G$" />
      <concept id="5799940921481343741" name="PRIAM_LANGUAGE.structure.DataSubjectCategory" flags="ng" index="2Rm3lO">
        <property id="5799940921481343744" name="locationId" index="2Rm3i9" />
        <reference id="4248638672751985011" name="personalData" index="3IEbcJ" />
      </concept>
      <concept id="586614309276224451" name="PRIAM_LANGUAGE.structure.PRIAM_GDPR" flags="ng" index="WHx_o">
        <child id="5718002482165470825" name="dataSubjectCategory" index="p73Ev" />
      </concept>
      <concept id="7072058747586032804" name="PRIAM_LANGUAGE.structure.PersonalDataCategory" flags="ng" index="1aEWHi">
        <property id="7072058747586032806" name="id" index="1aEWHg" />
      </concept>
      <concept id="7072058747586032808" name="PRIAM_LANGUAGE.structure.ListPersonalDataCat" flags="ng" index="1aEWHu">
        <child id="7072058747586032809" name="personalDataCategory" index="1aEWHv" />
      </concept>
      <concept id="2744329693373893095" name="PRIAM_LANGUAGE.structure.NonPersonalDataAnnotation" flags="ng" index="3e3_yR">
        <child id="2744329693373893096" name="nonPersonalData" index="3e3_yS" />
      </concept>
      <concept id="2744329693372336144" name="PRIAM_LANGUAGE.structure.NonPersonalData" flags="ng" index="3e5x_0" />
      <concept id="2744329693372893602" name="PRIAM_LANGUAGE.structure.PersonalDataAnnotation" flags="ng" index="3e6pzM">
        <child id="2744329693372893603" name="personalData" index="3e6pzN" />
      </concept>
      <concept id="4248638672751712930" name="PRIAM_LANGUAGE.structure.DataTypeList" flags="ng" index="3IF6zY">
        <child id="4248638672751712931" name="dataType" index="3IF6zZ" />
      </concept>
      <concept id="4648915867537282771" name="PRIAM_LANGUAGE.structure.Request" flags="ng" index="3VIdaa">
        <property id="8273050021459694961" name="id" index="8UP9o" />
        <property id="4648915867537282772" name="claim" index="3VIdad" />
        <property id="4648915867537282774" name="claimDate" index="3VIdaf" />
      </concept>
      <concept id="4648915867537282793" name="PRIAM_LANGUAGE.structure.DataRequest" flags="ng" index="3VIdaK">
        <property id="5799940921480571069" name="type" index="2Rp6WO" />
        <property id="4648915867537282798" name="newValue" index="3VIdaR" />
        <reference id="5799940921480571044" name="datasubject" index="2Rp6WH" />
        <reference id="4648915867537316225" name="dataReq" index="3VIlRo" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ng" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
    </language>
  </registry>
  <node concept="WHx_o" id="3FQc_NkrKoB">
    <node concept="2Rm3lO" id="3FQc_NkrKoC" role="p73Ev">
      <property role="TrG5h" value="nutrition_user" />
      <property role="2Rm3i9" value="user_ID" />
      <ref role="3IEbcJ" node="2ewkApsiKw8" />
    </node>
  </node>
  <node concept="3e6pzM" id="2ewkApsiKw8">
    <node concept="8tInM" id="2ewkApsiKw9" role="3e6pzN">
      <property role="EklAG" value="1" />
      <property role="TrG5h" value="username" />
      <property role="8tInw" value="20" />
      <property role="__Elb" value="Direct" />
      <ref role="2NV_G_" node="2soimBgelFc" resolve="nutrition_account" />
      <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
    </node>
    <node concept="8tInM" id="2soimBgelIW" role="3e6pzN">
      <property role="EklAG" value="2" />
      <property role="TrG5h" value="password" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2soimBgelFc" resolve="nutrition_account" />
      <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
    </node>
    <node concept="8tInM" id="2soimBgelIZ" role="3e6pzN">
      <property role="EklAG" value="3" />
      <property role="TrG5h" value="stat_account" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2soimBgelFc" resolve="nutrition_account" />
      <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
    </node>
    <node concept="8tInM" id="2soimBgelJ3" role="3e6pzN">
      <property role="EklAG" value="4" />
      <property role="TrG5h" value="user_id" />
      <property role="8tInw" value="20" />
      <property role="__Elb" value="5l7YRmKfOvn/Produced" />
      <ref role="2NV_G_" node="2soimBgelFc" resolve="nutrition_account" />
      <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
    </node>
    <node concept="8tInM" id="2soimBgelJ8" role="3e6pzN">
      <property role="EklAG" value="5" />
      <property role="TrG5h" value="user_id" />
      <property role="8tInw" value="20" />
      <property role="__Elb" value="5l7YRmKfOvn/Produced" />
      <ref role="2NV_G_" node="2ewkApsmtcz" resolve="nutrition_user" />
      <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
    </node>
    <node concept="8tInM" id="2soimBgelJe" role="3e6pzN">
      <property role="EklAG" value="6" />
      <property role="TrG5h" value="date_of_birth" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2ewkApsmtcz" resolve="nutrition_user" />
      <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
    </node>
    <node concept="8tInM" id="2soimBgelJl" role="3e6pzN">
      <property role="EklAG" value="7" />
      <property role="TrG5h" value="fat_mass" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2ewkApsmtcz" resolve="nutrition_user" />
      <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
    </node>
    <node concept="8tInM" id="2soimBgelJt" role="3e6pzN">
      <property role="EklAG" value="8" />
      <property role="TrG5h" value="first_name" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2ewkApsmtcz" resolve="nutrition_user" />
      <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
    </node>
    <node concept="8tInM" id="2soimBgelJV" role="3e6pzN">
      <property role="EklAG" value="9" />
      <property role="TrG5h" value="name" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2ewkApsmtcz" resolve="nutrition_user" />
      <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
    </node>
    <node concept="8tInM" id="2soimBgelK7" role="3e6pzN">
      <property role="EklAG" value="10" />
      <property role="TrG5h" value="profession" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2ewkApsmtcz" resolve="nutrition_user" />
      <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
    </node>
    <node concept="8tInM" id="2soimBgelJA" role="3e6pzN">
      <property role="EklAG" value="11" />
      <property role="TrG5h" value="morphological_profil" />
      <property role="8tInw" value="20" />
      <property role="__Elb" value="5l7YRmKfOvn/Produced" />
      <ref role="2NV_G_" node="2ewkApsmtcz" resolve="nutrition_user" />
      <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
    </node>
    <node concept="8tInM" id="2soimBgelJK" role="3e6pzN">
      <property role="EklAG" value="12" />
      <property role="TrG5h" value="psychological_profil" />
      <property role="8tInw" value="20" />
      <property role="__Elb" value="5l7YRmKfOvn/Produced" />
      <ref role="2NV_G_" node="2ewkApsmtcz" resolve="nutrition_user" />
      <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
    </node>
    <node concept="8tInM" id="2soimBgelKk" role="3e6pzN">
      <property role="EklAG" value="13" />
      <property role="TrG5h" value="registration_date" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2ewkApsmtcz" resolve="nutrition_user" />
      <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
    </node>
    <node concept="8tInM" id="2soimBgelKy" role="3e6pzN">
      <property role="EklAG" value="14" />
      <property role="TrG5h" value="waist_size" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2ewkApsmtcz" resolve="nutrition_user" />
      <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
    </node>
    <node concept="8tInM" id="2soimBgelKL" role="3e6pzN">
      <property role="EklAG" value="15" />
      <property role="TrG5h" value="weight" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2ewkApsmtcz" resolve="nutrition_user" />
      <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
    </node>
    <node concept="8tInM" id="2soimBgelLx" role="3e6pzN">
      <property role="EklAG" value="16" />
      <property role="TrG5h" value="id" />
      <property role="8tInw" value="20" />
      <property role="__Elb" value="5l7YRmKfOvn/Produced" />
      <ref role="2NV_G_" node="2soimBgelI0" resolve="nutrition_sport_activity" />
      <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
    </node>
    <node concept="8tInM" id="2soimBgelLM" role="3e6pzN">
      <property role="EklAG" value="17" />
      <property role="TrG5h" value="calory" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2soimBgelI0" resolve="nutrition_sport_activity" />
      <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
    </node>
    <node concept="8tInM" id="2soimBgelM4" role="3e6pzN">
      <property role="EklAG" value="18" />
      <property role="TrG5h" value="duration" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2soimBgelI0" resolve="nutrition_sport_activity" />
      <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
    </node>
    <node concept="8tInM" id="2soimBgelMn" role="3e6pzN">
      <property role="EklAG" value="19" />
      <property role="TrG5h" value="sportdate" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2soimBgelI0" resolve="nutrition_sport_activity" />
      <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
    </node>
    <node concept="8tInM" id="2soimBgelMF" role="3e6pzN">
      <property role="EklAG" value="20" />
      <property role="TrG5h" value="objectID" />
      <property role="8tInw" value="20" />
      <ref role="2NV_G_" node="2soimBgelI0" resolve="nutrition_sport_activity" />
      <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
    </node>
    <node concept="8tInM" id="2soimBgelN0" role="3e6pzN">
      <property role="EklAG" value="21" />
      <property role="TrG5h" value="user_id" />
      <property role="8tInw" value="20" />
      <property role="__Elb" value="5l7YRmKfOvn/Produced" />
      <ref role="2NV_G_" node="2soimBgelI0" resolve="nutrition_sport_activity" />
      <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
    </node>
    <node concept="8tInM" id="2soimBgelNm" role="3e6pzN">
      <property role="EklAG" value="22" />
      <property role="TrG5h" value="exercise_id" />
      <property role="8tInw" value="20" />
      <property role="__Elb" value="5l7YRmKfOvn/Produced" />
      <ref role="2NV_G_" node="2soimBgelI0" resolve="nutrition_sport_activity" />
      <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
    </node>
  </node>
  <node concept="3IF6zY" id="2ewkApsmtcx">
    <node concept="2NV_G$" id="2ewkApsmtcz" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_user" />
    </node>
    <node concept="2NV_G$" id="2soimBgelF8" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_sequence" />
    </node>
    <node concept="2NV_G$" id="2soimBgelFc" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_account" />
    </node>
    <node concept="2NV_G$" id="2soimBgelFh" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_consist" />
    </node>
    <node concept="2NV_G$" id="2soimBgelFn" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_daily_meal" />
    </node>
    <node concept="2NV_G$" id="2soimBgelFu" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_diet" />
    </node>
    <node concept="2NV_G$" id="2soimBgelFA" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_eat" />
    </node>
    <node concept="2NV_G$" id="2soimBgelFJ" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_exercise" />
    </node>
    <node concept="2NV_G$" id="2soimBgelFT" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_sticktodiet" />
    </node>
    <node concept="2NV_G$" id="2soimBgelG4" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_food" />
    </node>
    <node concept="2NV_G$" id="2soimBgelGg" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_food_diets" />
    </node>
    <node concept="2NV_G$" id="2soimBgelGt" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_food_habit" />
    </node>
    <node concept="2NV_G$" id="2soimBgelGF" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_food_habit_food" />
    </node>
    <node concept="2NV_G$" id="2soimBgelGU" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_healthy_meal" />
    </node>
    <node concept="2NV_G$" id="2soimBgelHa" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_healthy_meal_mealcontents" />
    </node>
    <node concept="2NV_G$" id="2soimBgelHr" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_mensuration" />
    </node>
    <node concept="2NV_G$" id="2soimBgelHH" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_user_food_habits" />
    </node>
    <node concept="2NV_G$" id="2soimBgelI0" role="3IF6zZ">
      <property role="TrG5h" value="nutrition_sport_activity" />
    </node>
  </node>
  <node concept="3e3_yR" id="2soimBgelP9">
    <node concept="3e5x_0" id="2soimBgelPa" role="3e3_yS">
      <property role="TrG5h" value="id" />
      <property role="EklAG" value="23" />
      <ref role="2NV_G_" node="2soimBgelG4" resolve="nutrition_food" />
    </node>
    <node concept="3e5x_0" id="2soimBgelPc" role="3e3_yS">
      <property role="TrG5h" value="calories" />
      <property role="EklAG" value="24" />
      <ref role="2NV_G_" node="2soimBgelG4" resolve="nutrition_food" />
    </node>
    <node concept="3e5x_0" id="2soimBgelPf" role="3e3_yS">
      <property role="TrG5h" value="carbs" />
      <property role="EklAG" value="25" />
      <ref role="2NV_G_" node="2soimBgelG4" resolve="nutrition_food" />
    </node>
    <node concept="3e5x_0" id="2soimBgelPj" role="3e3_yS">
      <property role="TrG5h" value="name" />
      <property role="EklAG" value="26" />
      <ref role="2NV_G_" node="2soimBgelG4" resolve="nutrition_food" />
    </node>
    <node concept="3e5x_0" id="2soimBgelPo" role="3e3_yS">
      <property role="TrG5h" value="protein" />
      <property role="EklAG" value="27" />
      <ref role="2NV_G_" node="2soimBgelG4" resolve="nutrition_food" />
    </node>
    <node concept="3e5x_0" id="2soimBgelPu" role="3e3_yS">
      <property role="TrG5h" value="fat" />
      <property role="EklAG" value="28" />
      <ref role="2NV_G_" node="2soimBgelG4" resolve="nutrition_food" />
    </node>
    <node concept="3e5x_0" id="2soimBgelP_" role="3e3_yS">
      <property role="TrG5h" value="saturated_fat" />
      <property role="EklAG" value="29" />
      <ref role="2NV_G_" node="2soimBgelG4" resolve="nutrition_food" />
    </node>
    <node concept="3e5x_0" id="2soimBgelPH" role="3e3_yS">
      <property role="TrG5h" value="sodium" />
      <property role="EklAG" value="30" />
      <ref role="2NV_G_" node="2soimBgelG4" resolve="nutrition_food" />
    </node>
    <node concept="3e5x_0" id="2soimBgelPQ" role="3e3_yS">
      <property role="TrG5h" value="sugar" />
      <property role="EklAG" value="31" />
      <ref role="2NV_G_" node="2soimBgelG4" resolve="nutrition_food" />
    </node>
    <node concept="3e5x_0" id="2soimBgelQ0" role="3e3_yS">
      <property role="TrG5h" value="serving_type_qty" />
      <property role="EklAG" value="32" />
      <ref role="2NV_G_" node="2soimBgelG4" resolve="nutrition_food" />
    </node>
    <node concept="3e5x_0" id="2soimBgelQb" role="3e3_yS">
      <property role="TrG5h" value="id" />
      <property role="EklAG" value="33" />
      <ref role="2NV_G_" node="2soimBgelFJ" resolve="nutrition_exercise" />
    </node>
    <node concept="3e5x_0" id="2soimBgelQn" role="3e3_yS">
      <property role="TrG5h" value="category" />
      <property role="EklAG" value="34" />
      <ref role="2NV_G_" node="2soimBgelFJ" resolve="nutrition_exercise" />
    </node>
    <node concept="3e5x_0" id="2soimBgelQ$" role="3e3_yS">
      <property role="TrG5h" value="code" />
      <property role="EklAG" value="35" />
      <ref role="2NV_G_" node="2soimBgelFJ" resolve="nutrition_exercise" />
    </node>
    <node concept="3e5x_0" id="2soimBgelQM" role="3e3_yS">
      <property role="TrG5h" value="description" />
      <property role="EklAG" value="36" />
      <ref role="2NV_G_" node="2soimBgelFJ" resolve="nutrition_exercise" />
    </node>
    <node concept="3e5x_0" id="2soimBgelR1" role="3e3_yS">
      <property role="TrG5h" value="metabolic_equivalent" />
      <property role="EklAG" value="37" />
      <ref role="2NV_G_" node="2soimBgelFJ" resolve="nutrition_exercise" />
    </node>
  </node>
  <node concept="__ElT" id="7jdn5R6mKOl">
    <property role="341Iwk" value="1" />
    <property role="TrG5h" value="Morphological Profiling" />
    <property role="__ElR" value="22-03-13" />
    <node concept="__EDa" id="7jdn5R6mKOm" role="__DUe">
      <property role="__ED9" value="Support and help of Obese users Who want to reduce their Weight and Allows Them to Maintain the Effects after loss." />
      <property role="__EDf" value="33K18miOIUz/Main" />
    </node>
    <node concept="__EDa" id="7jdn5R6mNSI" role="__DUe">
      <property role="__ED9" value="preventing chronic diseases and other health problems related to diet including obesity and cancer. " />
      <property role="__EDf" value="33K18miOIU$/Secondary" />
    </node>
    <node concept="__C6b" id="7jdn5R6mKOn" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelJV" resolve="name" />
      <node concept="__Elc" id="7jdn5R6mKOo" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mKOp" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelJt" resolve="first_name" />
      <node concept="__Elc" id="7jdn5R6mKOq" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNRc" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelLM" resolve="calory" />
      <node concept="__Elc" id="7jdn5R6mNRd" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNRM" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelJl" resolve="fat_mass" />
      <node concept="__Elc" id="7jdn5R6mNRN" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNSc" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelKL" resolve="weight" />
      <node concept="__Elc" id="7jdn5R6mNSd" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNSs" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelKL" resolve="weight" />
      <node concept="__Elc" id="7jdn5R6mNSt" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNRk" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelJA" resolve="morphological_profil" />
      <node concept="__Elc" id="7jdn5R6mNRl" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
        <property role="__E3D" value="true" />
        <property role="__E3G" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
  </node>
  <node concept="__ElT" id="7jdn5R6mNSL">
    <property role="341Iwk" value="2" />
    <property role="TrG5h" value="Registration" />
    <property role="__ElW" value="4Xqrfpm3WbV/Default" />
    <property role="__ElR" value="22-03-13" />
    <node concept="__EDa" id="7jdn5R6mNSM" role="__DUe">
      <property role="__EDf" value="33K18miOIUz/Main" />
      <property role="__ED9" value="create an account to acces on application" />
    </node>
    <node concept="__C6b" id="7jdn5R6mNSN" role="__Eln">
      <ref role="3e4$8_" node="2ewkApsiKw9" resolve="username" />
      <node concept="__Elc" id="7jdn5R6mNSO" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNSP" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelIW" resolve="password" />
      <node concept="__Elc" id="7jdn5R6mNSQ" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNSV" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelJV" resolve="name" />
      <node concept="__Elc" id="7jdn5R6mNSW" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNT3" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelJt" resolve="first_name" />
      <node concept="__Elc" id="7jdn5R6mNT4" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNTd" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelJe" resolve="date_of_birth" />
      <node concept="__Elc" id="7jdn5R6mNTe" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
      </node>
    </node>
  </node>
  <node concept="__ElT" id="7jdn5R6mNTp">
    <property role="341Iwk" value="3" />
    <property role="TrG5h" value="Prospection" />
    <property role="__ElR" value="22-03-13" />
    <node concept="__EDa" id="7jdn5R6mNTq" role="__DUe">
      <property role="__EDf" value="33K18miOIUz/Main" />
      <property role="__ED9" value="for advertisements of parterns (sport center, manufacturer of slimming foods)" />
    </node>
    <node concept="__C6b" id="7jdn5R6mNTr" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelJV" resolve="name" />
      <node concept="__Elc" id="7jdn5R6mNTs" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNTt" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelJt" resolve="first_name" />
      <node concept="__Elc" id="7jdn5R6mNTu" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNTz" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelJe" resolve="date_of_birth" />
      <node concept="__Elc" id="7jdn5R6mNT$" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="7jdn5R6mNTF" role="__Eln">
      <ref role="3e4$8_" node="2soimBgelKL" resolve="weight" />
      <node concept="__Elc" id="7jdn5R6mNTG" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
  </node>
  <node concept="2Rm3lO" id="7jdn5R6mNTP">
    <property role="TrG5h" value="User" />
    <property role="2Rm3i9" value="User_ID" />
    <ref role="3IEbcJ" node="2ewkApsiKw8" />
  </node>
  <node concept="2y8F$I" id="7jdn5R6mNTQ">
    <property role="TrG5h" value="Anais" />
    <property role="2y8F$Q" value="20" />
    <property role="Ed$TN" value="1" />
    <property role="Ef8nK" value="193258" />
    <property role="TxubU" value="4BkqmtKkjtU/Spain" />
    <ref role="Eclqg" node="3FQc_NkrKoC" resolve="nutrition_user" />
  </node>
  <node concept="3VIdaK" id="7jdn5R6mNTS">
    <property role="8UP9o" value="1" />
    <property role="2Rp6WO" value="51XxSBB6uz2/Rectification" />
    <property role="3VIdaR" value="2002-04-07" />
    <property role="3VIdad" value="there is an error in my birthday" />
    <property role="3VIdaf" value="2002-03-13" />
    <ref role="2Rp6WH" node="7jdn5R6mNTQ" resolve="Anais" />
    <ref role="3VIlRo" node="2soimBgelJe" resolve="date_of_birth" />
  </node>
  <node concept="EdaGU" id="7jdn5R6mNTT">
    <property role="EdaF5" value="true" />
    <ref role="EdaF0" node="7jdn5R6mNTS" />
  </node>
  <node concept="__NVD" id="7jdn5R6mNTV">
    <property role="EmbXt" value="1" />
    <property role="__NVI" value="2002-03-22" />
    <property role="__NVe" value="2022-03-21" />
    <ref role="2RrpWN" node="7jdn5R6mNTQ" resolve="Anais" />
    <node concept="__EkI" id="7jdn5R6mNTW" role="__ElV">
      <property role="__Elv" value="2002-03-22" />
      <property role="__Elt" value="2022-03-21" />
      <node concept="FSH21" id="7jdn5R6mNTX" role="__ElY">
        <property role="2_ULE4" value="true" />
        <ref role="FS3IE" node="7jdn5R6mKOl" resolve="Morphological Profiling" />
      </node>
    </node>
    <node concept="__EkI" id="7jdn5R6mNTY" role="__ElV">
      <property role="__Elv" value=" 2002-03-22" />
      <property role="__Elt" value=" 2022-03-21" />
      <node concept="FSH21" id="7jdn5R6mNTZ" role="__ElY">
        <property role="2_ULE4" value="true" />
        <ref role="FS3IE" node="7jdn5R6mNTp" resolve="Prospection" />
      </node>
    </node>
  </node>
  <node concept="2y8F$I" id="4BkqmtKmMqJ">
    <property role="Ed$TN" value="2" />
    <property role="TrG5h" value="Liliane" />
    <property role="2y8F$Q" value="19" />
    <property role="TxubU" value="4BkqmtKkjtV/USA" />
    <property role="Ef8nK" value="497598" />
    <ref role="Eclqg" node="3FQc_NkrKoC" resolve="nutrition_user" />
  </node>
  <node concept="1aEWHu" id="68$ZZoCB4$i">
    <node concept="1aEWHi" id="68$ZZoCB4$j" role="1aEWHv">
      <property role="1aEWHg" value="1" />
      <property role="TrG5h" value="biometric data" />
    </node>
    <node concept="1aEWHi" id="68$ZZoCB4$k" role="1aEWHv">
      <property role="1aEWHg" value="2" />
      <property role="TrG5h" value="genetic data" />
    </node>
    <node concept="1aEWHi" id="68$ZZoCCusr" role="1aEWHv">
      <property role="1aEWHg" value="3" />
      <property role="TrG5h" value="ethnic origin" />
    </node>
    <node concept="1aEWHi" id="68$ZZoCCuss" role="1aEWHv">
      <property role="1aEWHg" value="4" />
      <property role="TrG5h" value="health data" />
    </node>
    <node concept="1aEWHi" id="68$ZZoCCust" role="1aEWHv">
      <property role="1aEWHg" value="5" />
      <property role="TrG5h" value="political opinions" />
    </node>
    <node concept="1aEWHi" id="40NILoOZXiA" role="1aEWHv">
      <property role="1aEWHg" value="6" />
      <property role="TrG5h" value="physical data" />
    </node>
    <node concept="1aEWHi" id="40NILoOZXiB" role="1aEWHv">
      <property role="1aEWHg" value="7" />
      <property role="TrG5h" value="Profil data" />
    </node>
  </node>
</model>

