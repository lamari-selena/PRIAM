insert into gdpr_processing (processingID, processingName, processingType, processingCategory, creationDate) values (1, 'Morphological Profiling', 'Optional', 'Consent_Contract', "22-03-13");

insert into gdpr_Purpose (description, type, processing) values('Support and help of Obese users Who want to reduce their Weight and Allows Them to Maintain the Effects after loss.', 'Main', '1');
insert into gdpr_Purpose (description, type, processing) values('preventing chronic diseases and other health problems related to diet including obesity and cancer. ', 'Secondary', '1');
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (1, 9, true, false,true, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (1, 8, true, false,true, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (1, 17, true, false,true, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (1, 7, true, false,true, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (1, 15, true, false,true, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (1, 15, true, false,true, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (1, 11, true, true,true, true, true);
