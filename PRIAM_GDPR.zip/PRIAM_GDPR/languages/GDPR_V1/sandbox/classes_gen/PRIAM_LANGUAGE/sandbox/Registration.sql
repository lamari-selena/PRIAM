insert into gdpr_processing (processingID, processingName, processingType, processingCategory, creationDate) values (2, 'Registration', 'Default', 'Consent_Contract', "22-03-13");

insert into gdpr_Purpose (description, type, processing) values('create an account to acces on application', 'Main', '2');
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (2, 1, true, true,false, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (2, 2, true, true,false, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (2, 9, true, true,false, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (2, 8, true, true,false, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (2, 6, true, true,false, false, false);
