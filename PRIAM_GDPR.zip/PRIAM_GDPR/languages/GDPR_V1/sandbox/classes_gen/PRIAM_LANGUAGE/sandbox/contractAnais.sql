insert into gdpr_contract (datasubject, signaturedate, expirationdate) values ('1', '2002-03-22', '2022-03-21');
insert into gdpr_consent(datasubject, contract, processing, startdate, enddate) values ('1', 1, '1', '2002-03-22', '2022-03-21');
insert into gdpr_consent(datasubject, contract, processing, startdate, enddate) values ('1', 1, '3', ' 2002-03-22', ' 2022-03-21');
