insert into gdpr_processing (processingID, processingName, processingType, processingCategory, creationDate) values (3, 'Prospection', 'Optional', 'Consent_Contract', "22-03-13");

insert into gdpr_Purpose (description, type, processing) values('for advertisements of parterns (sport center, manufacturer of slimming foods)', 'Main', '3');
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (3, 9, true, false,true, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (3, 8, true, false,true, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (3, 6, true, false,true, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (3, 15, true, false,true, false, false);
