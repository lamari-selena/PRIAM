insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (1, 'nutrition_account', 'Direct','20',true,'7');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (2, 'nutrition_account', 'Direct','20',true,'7');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (3, 'nutrition_account', 'Direct','20',true,'7');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (4, 'nutrition_account', 'Produced','20',true,'7');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (5, 'nutrition_user', 'Produced','20',true,'7');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (6, 'nutrition_user', 'Direct','20',true,'6');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (7, 'nutrition_user', 'Direct','20',true,'4');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (8, 'nutrition_user', 'Direct','20',true,'6');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (9, 'nutrition_user', 'Direct','20',true,'6');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (10, 'nutrition_user', 'Direct','20',true,'6');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (11, 'nutrition_user', 'Produced','20',true,'7');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (12, 'nutrition_user', 'Produced','20',true,'4');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (13, 'nutrition_user', 'Direct','20',true,'7');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (14, 'nutrition_user', 'Direct','20',true,'6');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (15, 'nutrition_user', 'Direct','20',true,'6');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (16, 'nutrition_sport_activity', 'Produced','20',true,'7');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (17, 'nutrition_sport_activity', 'Direct','20',true,'4');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (18, 'nutrition_sport_activity', 'Direct','20',true,'4');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (19, 'nutrition_sport_activity', 'Direct','20',true,'6');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (20, 'nutrition_sport_activity', 'Direct','20',true,'7');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (21, 'nutrition_sport_activity', 'Produced','20',true,'7');
insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)
   values (22, 'nutrition_sport_activity', 'Produced','20',true,'7');
