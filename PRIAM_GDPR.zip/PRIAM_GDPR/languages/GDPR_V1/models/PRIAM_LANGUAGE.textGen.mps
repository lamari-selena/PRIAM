<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:0504ed10-6c07-440f-84d5-21e63be24e6f(PRIAM_LANGUAGE.textGen)">
  <persistence version="9" />
  <languages>
    <use id="b83431fe-5c8f-40bc-8a36-65e25f4dd253" name="jetbrains.mps.lang.textGen" version="1" />
    <use id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core" version="2" />
    <use id="e02dfeab-630f-4f6d-86a8-a0833a3f70fc" name="PRIAM_LANGUAGE" version="0" />
    <devkit ref="fa73d85a-ac7f-447b-846c-fcdc41caa600(jetbrains.mps.devkit.aspect.textgen)" />
  </languages>
  <imports>
    <import index="20wa" ref="r:515d5f51-79c9-42c9-bba4-54c97b772d5b(PRIAM_LANGUAGE.structure)" />
    <import index="tpck" ref="r:00000000-0000-4000-0000-011c89590288(jetbrains.mps.lang.core.structure)" implicit="true" />
    <import index="c17a" ref="8865b7a8-5271-43d3-884c-6fd1d9cfdd34/java:org.jetbrains.mps.openapi.language(MPS.OpenAPI/)" implicit="true" />
    <import index="wyt6" ref="6354ebe7-c22a-4a0f-ac54-50b52ab9b065/java:java.lang(JDK/)" implicit="true" />
    <import index="oniz" ref="r:e7beee50-bad0-4e7e-a2a7-f43f7868ae0a(PRIAM_LANGUAGE.behavior)" implicit="true" />
  </imports>
  <registry>
    <language id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage">
      <concept id="1215693861676" name="jetbrains.mps.baseLanguage.structure.BaseAssignmentExpression" flags="nn" index="d038R">
        <child id="1068498886297" name="rValue" index="37vLTx" />
        <child id="1068498886295" name="lValue" index="37vLTJ" />
      </concept>
      <concept id="1202948039474" name="jetbrains.mps.baseLanguage.structure.InstanceMethodCallOperation" flags="nn" index="liA8E" />
      <concept id="1239714755177" name="jetbrains.mps.baseLanguage.structure.AbstractUnaryNumberOperation" flags="nn" index="2$Kvd9">
        <child id="1239714902950" name="expression" index="2$L3a6" />
      </concept>
      <concept id="1154032098014" name="jetbrains.mps.baseLanguage.structure.AbstractLoopStatement" flags="nn" index="2LF5Ji">
        <child id="1154032183016" name="body" index="2LFqv$" />
      </concept>
      <concept id="1197027756228" name="jetbrains.mps.baseLanguage.structure.DotExpression" flags="nn" index="2OqwBi">
        <child id="1197027771414" name="operand" index="2Oq$k0" />
        <child id="1197027833540" name="operation" index="2OqNvi" />
      </concept>
      <concept id="1137021947720" name="jetbrains.mps.baseLanguage.structure.ConceptFunction" flags="in" index="2VMwT0">
        <child id="1137022507850" name="body" index="2VODD2" />
      </concept>
      <concept id="1070475926800" name="jetbrains.mps.baseLanguage.structure.StringLiteral" flags="nn" index="Xl_RD">
        <property id="1070475926801" name="value" index="Xl_RC" />
      </concept>
      <concept id="1070534370425" name="jetbrains.mps.baseLanguage.structure.IntegerType" flags="in" index="10Oyi0" />
      <concept id="1068431474542" name="jetbrains.mps.baseLanguage.structure.VariableDeclaration" flags="ng" index="33uBYm">
        <child id="1068431790190" name="initializer" index="33vP2m" />
      </concept>
      <concept id="1068498886296" name="jetbrains.mps.baseLanguage.structure.VariableReference" flags="nn" index="37vLTw">
        <reference id="1068581517664" name="variableDeclaration" index="3cqZAo" />
      </concept>
      <concept id="1068498886294" name="jetbrains.mps.baseLanguage.structure.AssignmentExpression" flags="nn" index="37vLTI" />
      <concept id="1225271177708" name="jetbrains.mps.baseLanguage.structure.StringType" flags="in" index="17QB3L" />
      <concept id="4972933694980447171" name="jetbrains.mps.baseLanguage.structure.BaseVariableDeclaration" flags="ng" index="19Szcq">
        <child id="5680397130376446158" name="type" index="1tU5fm" />
      </concept>
      <concept id="1068580123152" name="jetbrains.mps.baseLanguage.structure.EqualsExpression" flags="nn" index="3clFbC" />
      <concept id="1068580123155" name="jetbrains.mps.baseLanguage.structure.ExpressionStatement" flags="nn" index="3clFbF">
        <child id="1068580123156" name="expression" index="3clFbG" />
      </concept>
      <concept id="1068580123157" name="jetbrains.mps.baseLanguage.structure.Statement" flags="nn" index="3clFbH" />
      <concept id="1068580123159" name="jetbrains.mps.baseLanguage.structure.IfStatement" flags="nn" index="3clFbJ">
        <child id="1068580123160" name="condition" index="3clFbw" />
        <child id="1068580123161" name="ifTrue" index="3clFbx" />
      </concept>
      <concept id="1068580123136" name="jetbrains.mps.baseLanguage.structure.StatementList" flags="sn" stub="5293379017992965193" index="3clFbS">
        <child id="1068581517665" name="statement" index="3cqZAp" />
      </concept>
      <concept id="1068580320020" name="jetbrains.mps.baseLanguage.structure.IntegerConstant" flags="nn" index="3cmrfG">
        <property id="1068580320021" name="value" index="3cmrfH" />
      </concept>
      <concept id="1068581242875" name="jetbrains.mps.baseLanguage.structure.PlusExpression" flags="nn" index="3cpWs3" />
      <concept id="1068581242864" name="jetbrains.mps.baseLanguage.structure.LocalVariableDeclarationStatement" flags="nn" index="3cpWs8">
        <child id="1068581242865" name="localVariableDeclaration" index="3cpWs9" />
      </concept>
      <concept id="1068581242863" name="jetbrains.mps.baseLanguage.structure.LocalVariableDeclaration" flags="nr" index="3cpWsn" />
      <concept id="1204053956946" name="jetbrains.mps.baseLanguage.structure.IMethodCall" flags="ng" index="1ndlxa">
        <reference id="1068499141037" name="baseMethodDeclaration" index="37wK5l" />
      </concept>
      <concept id="1081773326031" name="jetbrains.mps.baseLanguage.structure.BinaryOperation" flags="nn" index="3uHJSO">
        <child id="1081773367579" name="rightExpression" index="3uHU7w" />
        <child id="1081773367580" name="leftExpression" index="3uHU7B" />
      </concept>
      <concept id="1214918800624" name="jetbrains.mps.baseLanguage.structure.PostfixIncrementExpression" flags="nn" index="3uNrnE" />
      <concept id="6329021646629104954" name="jetbrains.mps.baseLanguage.structure.SingleLineComment" flags="nn" index="3SKdUt">
        <child id="8356039341262087992" name="line" index="1aUNEU" />
      </concept>
    </language>
    <language id="b83431fe-5c8f-40bc-8a36-65e25f4dd253" name="jetbrains.mps.lang.textGen">
      <concept id="45307784116571022" name="jetbrains.mps.lang.textGen.structure.FilenameFunction" flags="ig" index="29tfMY" />
      <concept id="8931911391946696733" name="jetbrains.mps.lang.textGen.structure.ExtensionDeclaration" flags="in" index="9MYSb" />
      <concept id="1237305208784" name="jetbrains.mps.lang.textGen.structure.NewLineAppendPart" flags="ng" index="l8MVK" />
      <concept id="1237305334312" name="jetbrains.mps.lang.textGen.structure.NodeAppendPart" flags="ng" index="l9hG8">
        <child id="1237305790512" name="value" index="lb14g" />
      </concept>
      <concept id="1237305557638" name="jetbrains.mps.lang.textGen.structure.ConstantStringAppendPart" flags="ng" index="la8eA">
        <property id="1237305576108" name="value" index="lacIc" />
      </concept>
      <concept id="1237306079178" name="jetbrains.mps.lang.textGen.structure.AppendOperation" flags="nn" index="lc7rE">
        <child id="1237306115446" name="part" index="lcghm" />
      </concept>
      <concept id="1233670071145" name="jetbrains.mps.lang.textGen.structure.ConceptTextGenDeclaration" flags="ig" index="WtQ9Q">
        <reference id="1233670257997" name="conceptDeclaration" index="WuzLi" />
        <child id="45307784116711884" name="filename" index="29tGrW" />
        <child id="1233749296504" name="textGenBlock" index="11c4hB" />
        <child id="7991274449437422201" name="extension" index="33IsuW" />
      </concept>
      <concept id="1233748055915" name="jetbrains.mps.lang.textGen.structure.NodeParameter" flags="nn" index="117lpO" />
      <concept id="1233749247888" name="jetbrains.mps.lang.textGen.structure.GenerateTextDeclaration" flags="in" index="11bSqf" />
    </language>
    <language id="7866978e-a0f0-4cc7-81bc-4d213d9375e1" name="jetbrains.mps.lang.smodel">
      <concept id="1179409122411" name="jetbrains.mps.lang.smodel.structure.Node_ConceptMethodCall" flags="nn" index="2qgKlT" />
      <concept id="1138056022639" name="jetbrains.mps.lang.smodel.structure.SPropertyAccess" flags="nn" index="3TrcHB">
        <reference id="1138056395725" name="property" index="3TsBF5" />
      </concept>
      <concept id="1138056143562" name="jetbrains.mps.lang.smodel.structure.SLinkAccess" flags="nn" index="3TrEf2">
        <reference id="1138056516764" name="link" index="3Tt5mk" />
      </concept>
      <concept id="1138056282393" name="jetbrains.mps.lang.smodel.structure.SLinkListAccess" flags="nn" index="3Tsc0h">
        <reference id="1138056546658" name="link" index="3TtcxE" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1133920641626" name="jetbrains.mps.lang.core.structure.BaseConcept" flags="ng" index="2VYdi">
        <child id="5169995583184591170" name="smodelAttribute" index="lGtFl" />
      </concept>
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ng" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
      <concept id="709746936026466394" name="jetbrains.mps.lang.core.structure.ChildAttribute" flags="ng" index="3VBwX9">
        <property id="709746936026609031" name="linkId" index="3V$3ak" />
        <property id="709746936026609029" name="role_DebugInfo" index="3V$3am" />
      </concept>
      <concept id="4452961908202556907" name="jetbrains.mps.lang.core.structure.BaseCommentAttribute" flags="ng" index="1X3_iC">
        <child id="3078666699043039389" name="commentedNode" index="8Wnug" />
      </concept>
    </language>
    <language id="c7fb639f-be78-4307-89b0-b5959c3fa8c8" name="jetbrains.mps.lang.text">
      <concept id="155656958578482948" name="jetbrains.mps.lang.text.structure.Word" flags="nn" index="3oM_SD">
        <property id="155656958578482949" name="value" index="3oM_SC" />
      </concept>
      <concept id="2535923850359271782" name="jetbrains.mps.lang.text.structure.Line" flags="nn" index="1PaTwC">
        <child id="2535923850359271783" name="elements" index="1PaTwD" />
      </concept>
    </language>
    <language id="83888646-71ce-4f1c-9c53-c54016f6ad4f" name="jetbrains.mps.baseLanguage.collections">
      <concept id="540871147943773365" name="jetbrains.mps.baseLanguage.collections.structure.SingleArgumentSequenceOperation" flags="nn" index="25WWJ4">
        <child id="540871147943773366" name="argument" index="25WWJ7" />
      </concept>
      <concept id="1153943597977" name="jetbrains.mps.baseLanguage.collections.structure.ForEachStatement" flags="nn" index="2Gpval">
        <child id="1153944400369" name="variable" index="2Gsz3X" />
        <child id="1153944424730" name="inputSequence" index="2GsD0m" />
      </concept>
      <concept id="1153944193378" name="jetbrains.mps.baseLanguage.collections.structure.ForEachVariable" flags="nr" index="2GrKxI" />
      <concept id="1153944233411" name="jetbrains.mps.baseLanguage.collections.structure.ForEachVariableReference" flags="nn" index="2GrUjf">
        <reference id="1153944258490" name="variable" index="2Gs0qQ" />
      </concept>
      <concept id="1162934736510" name="jetbrains.mps.baseLanguage.collections.structure.GetElementOperation" flags="nn" index="34jXtK" />
    </language>
  </registry>
  <node concept="WtQ9Q" id="7bfLM_U7Gt1">
    <ref role="WuzLi" to="20wa:5VnHNHVgh92" resolve="Processing" />
    <node concept="29tfMY" id="7bfLM_U7Gt2" role="29tGrW">
      <node concept="3clFbS" id="7bfLM_U7Gt3" role="2VODD2">
        <node concept="3clFbF" id="7bfLM_U7G_S" role="3cqZAp">
          <node concept="2OqwBi" id="7bfLM_U7GKo" role="3clFbG">
            <node concept="117lpO" id="7bfLM_U7G_R" role="2Oq$k0" />
            <node concept="3TrcHB" id="7bfLM_U7GXH" role="2OqNvi">
              <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="7bfLM_U7H4B" role="33IsuW">
      <node concept="3clFbS" id="7bfLM_U7H4C" role="2VODD2">
        <node concept="3clFbF" id="7bfLM_U7H5_" role="3cqZAp">
          <node concept="Xl_RD" id="7bfLM_U7H5$" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="7bfLM_U7HbX" role="11c4hB">
      <node concept="3clFbS" id="7bfLM_U7HbY" role="2VODD2">
        <node concept="3cpWs8" id="7bfLM_U7ZSC" role="3cqZAp">
          <node concept="3cpWsn" id="7bfLM_U7ZS$" role="3cpWs9">
            <property role="TrG5h" value="datesString" />
            <node concept="17QB3L" id="7bfLM_U7ZUV" role="1tU5fm" />
            <node concept="3cpWs3" id="7bfLM_U84nS" role="33vP2m">
              <node concept="Xl_RD" id="7bfLM_U84ow" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="7bfLM_U83yD" role="3uHU7B">
                <node concept="117lpO" id="7bfLM_U83sw" role="2Oq$k0" />
                <node concept="3TrcHB" id="7bfLM_U83F0" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5VnHNHVgh9c" resolve="createDate" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="1ASe9EYyveL" role="3cqZAp" />
        <node concept="lc7rE" id="7bfLM_U7Hhz" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7HhS" role="lcghm">
            <property role="lacIc" value="insert into gdpr_processing (processingID, processingName, processingType, processingCategory, creationDate) values (" />
          </node>
        </node>
        <node concept="lc7rE" id="7bfLM_U7Hli" role="3cqZAp">
          <node concept="l9hG8" id="1PjvIwH_fIO" role="lcghm">
            <node concept="3cpWs3" id="1PjvIwH_gYs" role="lb14g">
              <node concept="Xl_RD" id="1PjvIwH_gYw" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="1PjvIwH_fYp" role="3uHU7B">
                <node concept="117lpO" id="1PjvIwH_fR9" role="2Oq$k0" />
                <node concept="3TrcHB" id="1PjvIwH_g7l" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:7jX2EUKYYaU" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="1PjvIwH_f8X" role="lcghm">
            <property role="lacIc" value=", '" />
          </node>
          <node concept="l9hG8" id="7bfLM_U7HKQ" role="lcghm">
            <node concept="2OqwBi" id="7bfLM_U7HT2" role="lb14g">
              <node concept="117lpO" id="7bfLM_U7HLF" role="2Oq$k0" />
              <node concept="3TrcHB" id="7bfLM_U7I1Z" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="7bfLM_U7I9$" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="7bfLM_U7Ivq" role="lcghm">
            <node concept="2OqwBi" id="4Xqrfpm45lq" role="lb14g">
              <node concept="2OqwBi" id="7bfLM_U7IC3" role="2Oq$k0">
                <node concept="117lpO" id="7bfLM_U7IwG" role="2Oq$k0" />
                <node concept="3TrcHB" id="7bfLM_U7IKZ" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5VnHNHVgh97" resolve="tp" />
                </node>
              </node>
              <node concept="liA8E" id="4Xqrfpm45IB" role="2OqNvi">
                <ref role="37wK5l" to="c17a:~SEnumerationLiteral.getName()" resolve="getName" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="7bfLM_U7IMM" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="7bfLM_U7IR$" role="lcghm">
            <node concept="2OqwBi" id="33K18miPvHG" role="lb14g">
              <node concept="2OqwBi" id="33K18miPvoo" role="2Oq$k0">
                <node concept="117lpO" id="7bfLM_U7ITi" role="2Oq$k0" />
                <node concept="3TrcHB" id="33K18miPvy7" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5VnHNHVgh99" resolve="pc" />
                </node>
              </node>
              <node concept="liA8E" id="33K18miPNTE" role="2OqNvi">
                <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="7bfLM_U7JbO" role="lcghm">
            <property role="lacIc" value="', &quot;" />
          </node>
          <node concept="l9hG8" id="7bfLM_U867r" role="lcghm">
            <node concept="37vLTw" id="7bfLM_U869B" role="lb14g">
              <ref role="3cqZAo" node="7bfLM_U7ZS$" resolve="datesString" />
            </node>
          </node>
          <node concept="la8eA" id="7bfLM_U7JBQ" role="lcghm">
            <property role="lacIc" value="&quot;);" />
          </node>
          <node concept="l8MVK" id="2NO6V5fWi$w" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7K5K" role="3cqZAp">
          <node concept="l8MVK" id="7bfLM_U7K7W" role="lcghm" />
        </node>
        <node concept="3clFbH" id="7bfLM_U9epa" role="3cqZAp" />
        <node concept="3cpWs8" id="33K18miT1H_" role="3cqZAp">
          <node concept="3cpWsn" id="33K18miT1HC" role="3cpWs9">
            <property role="TrG5h" value="i" />
            <node concept="10Oyi0" id="33K18miT1Hz" role="1tU5fm" />
            <node concept="3cmrfG" id="33K18miT1Rh" role="33vP2m">
              <property role="3cmrfH" value="-1" />
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="4Xqrfpmf$9H" role="3cqZAp">
          <node concept="2GrKxI" id="4Xqrfpmf$9J" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="4Xqrfpmf_zY" role="2GsD0m">
            <node concept="117lpO" id="4Xqrfpmf$mW" role="2Oq$k0" />
            <node concept="2qgKlT" id="4Xqrfpmf_Lo" role="2OqNvi">
              <ref role="37wK5l" to="oniz:4Xqrfpm5qCx" resolve="getAllDescriptionPurpose" />
            </node>
          </node>
          <node concept="3clFbS" id="4Xqrfpmf$9N" role="2LFqv$">
            <node concept="3clFbF" id="33K18miT21M" role="3cqZAp">
              <node concept="3uNrnE" id="33K18miT2CX" role="3clFbG">
                <node concept="37vLTw" id="33K18miT2CZ" role="2$L3a6">
                  <ref role="3cqZAo" node="33K18miT1HC" resolve="i" />
                </node>
              </node>
            </node>
            <node concept="lc7rE" id="4Xqrfpmf_Sb" role="3cqZAp">
              <node concept="la8eA" id="4Xqrfpmf_Sv" role="lcghm">
                <property role="lacIc" value="insert into gdpr_Purpose (description, type, processing) values('" />
              </node>
              <node concept="l9hG8" id="4Xqrfpmf_VT" role="lcghm">
                <node concept="2GrUjf" id="4XqrfpmfAgc" role="lb14g">
                  <ref role="2Gs0qQ" node="4Xqrfpmf$9J" resolve="e" />
                </node>
              </node>
              <node concept="la8eA" id="4XqrfpmfKId" role="lcghm">
                <property role="lacIc" value="', '" />
              </node>
              <node concept="l9hG8" id="4XqrfpmfB4j" role="lcghm">
                <node concept="2OqwBi" id="4XqrfpmfP4C" role="lb14g">
                  <node concept="2OqwBi" id="4XqrfpmfCzN" role="2Oq$k0">
                    <node concept="2OqwBi" id="4XqrfpmfBeB" role="2Oq$k0">
                      <node concept="117lpO" id="4XqrfpmfBc1" role="2Oq$k0" />
                      <node concept="2qgKlT" id="4XqrfpmfBgh" role="2OqNvi">
                        <ref role="37wK5l" to="oniz:4Xqrfpm6wZE" resolve="getAllTypePurpose" />
                      </node>
                    </node>
                    <node concept="34jXtK" id="4XqrfpmfDLb" role="2OqNvi">
                      <node concept="37vLTw" id="33K18miSiFX" role="25WWJ7">
                        <ref role="3cqZAo" node="33K18miT1HC" resolve="i" />
                      </node>
                    </node>
                  </node>
                  <node concept="liA8E" id="4XqrfpmfP_L" role="2OqNvi">
                    <ref role="37wK5l" to="wyt6:~String.toString()" resolve="toString" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="4XqrfpmfKoG" role="lcghm">
                <property role="lacIc" value="', '" />
              </node>
              <node concept="l9hG8" id="IIjfDnUGee" role="lcghm">
                <node concept="3cpWs3" id="7McLYwdKmSo" role="lb14g">
                  <node concept="Xl_RD" id="7McLYwdKmSs" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="IIjfDnUGqB" role="3uHU7B">
                    <node concept="117lpO" id="IIjfDnUGij" role="2Oq$k0" />
                    <node concept="3TrcHB" id="7McLYwdKm2$" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:7jX2EUKYYaU" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="IIjfDnUGM6" role="lcghm">
                <property role="lacIc" value="');" />
              </node>
              <node concept="l8MVK" id="2NO6V5fWio_" role="lcghm" />
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="2NO6V5fTG43" role="3cqZAp">
          <node concept="2GrKxI" id="2NO6V5fTG45" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="2NO6V5fTGzw" role="2GsD0m">
            <node concept="117lpO" id="2NO6V5fTGkt" role="2Oq$k0" />
            <node concept="3Tsc0h" id="2NO6V5fTGMD" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:5VnHNHVgh9G" resolve="dataUsed" />
            </node>
          </node>
          <node concept="3clFbS" id="2NO6V5fTG49" role="2LFqv$">
            <node concept="lc7rE" id="2NO6V5fTPS4" role="3cqZAp">
              <node concept="la8eA" id="2NO6V5fU41p" role="lcghm">
                <property role="lacIc" value="insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (" />
              </node>
              <node concept="l9hG8" id="2NO6V5fU4IJ" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fU5PE" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fU5QL" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fU4ZB" role="3uHU7B">
                    <node concept="117lpO" id="2NO6V5fU4Rj" role="2Oq$k0" />
                    <node concept="3TrcHB" id="2NO6V5fU58z" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:7jX2EUKYYaU" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fU608" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="2NO6V5fTPSo" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fU7Ar" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fU7Jt" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fU3qw" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fU2tI" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fU2n1" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fU2M0" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:2olOl3C1TdP" resolve="dataref" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fU3Je" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fX_yT" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="2NO6V5fX_Ay" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fXBSS" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fXC4X" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fXABf" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fX_Jw" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fX_CN" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fXAiR" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fXBqQ" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghv9" resolve="hasPersonalUsage" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fU8t3" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="2NO6V5fU8Ky" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fUbeV" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fUbo$" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fU9PI" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fU90I" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fU8U1" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fU9hV" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fUapH" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghvb" resolve="c" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fUaP6" role="lcghm">
                <property role="lacIc" value="," />
              </node>
              <node concept="l9hG8" id="2NO6V5fUcf1" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fUeb2" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fUeb6" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fUdvs" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fUcvX" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fUcpg" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fUdcT" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fUdMo" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghve" resolve="r" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fUf38" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="2NO6V5fUfog" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fUhkv" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fUhkz" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fUgCi" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fUfDW" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fUfzf" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fUgl8" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fUgVe" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghvi" resolve="u" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fUidW" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="2NO6V5fUi$$" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fUkCX" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fUkD1" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fUjvA" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fUiR0" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fUiKj" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fUjbP" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fUjN9" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghvn" resolve="d" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fUlpu" role="lcghm">
                <property role="lacIc" value=");" />
              </node>
              <node concept="l8MVK" id="2NO6V5fUZmy" role="lcghm" />
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="2NO6V5fTLtz" role="3cqZAp" />
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="3WaPWgleQE8">
    <ref role="WuzLi" to="20wa:33K18miOFQF" resolve="DataSubject" />
    <node concept="29tfMY" id="3WaPWgleQE9" role="29tGrW">
      <node concept="3clFbS" id="3WaPWgleQEa" role="2VODD2">
        <node concept="3clFbF" id="3WaPWgleQIL" role="3cqZAp">
          <node concept="2OqwBi" id="3WaPWgleQUR" role="3clFbG">
            <node concept="117lpO" id="3WaPWgleQIK" role="2Oq$k0" />
            <node concept="3TrcHB" id="3WaPWgleR7t" role="2OqNvi">
              <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="3WaPWgleRMT" role="33IsuW">
      <node concept="3clFbS" id="3WaPWgleRMU" role="2VODD2">
        <node concept="3clFbF" id="3WaPWgleRNQ" role="3cqZAp">
          <node concept="Xl_RD" id="3WaPWgleRNP" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="3WaPWgleS0w" role="11c4hB">
      <node concept="3clFbS" id="3WaPWgleS0x" role="2VODD2">
        <node concept="lc7rE" id="3WaPWgleS1P" role="3cqZAp">
          <node concept="la8eA" id="3WaPWgleS29" role="lcghm">
            <property role="lacIc" value="insert into gdpr_datasubject (datasubjectID, userName, age, Country, dsCategory, tutor," />
          </node>
          <node concept="l9hG8" id="IIjfDnTogk" role="lcghm">
            <node concept="2OqwBi" id="IIjfDnToLZ" role="lb14g">
              <node concept="2OqwBi" id="IIjfDnTos2" role="2Oq$k0">
                <node concept="117lpO" id="IIjfDnToro" role="2Oq$k0" />
                <node concept="3TrEf2" id="IIjfDnToD0" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                </node>
              </node>
              <node concept="3TrcHB" id="IIjfDnToXy" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
              </node>
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWgleSff" role="3cqZAp">
          <node concept="la8eA" id="IIjfDnTocD" role="lcghm">
            <property role="lacIc" value=") values(" />
          </node>
          <node concept="l9hG8" id="1PjvIwH_aR2" role="lcghm">
            <node concept="3cpWs3" id="1PjvIwHB6wg" role="lb14g">
              <node concept="Xl_RD" id="1PjvIwHB6wk" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="1PjvIwH_b4o" role="3uHU7B">
                <node concept="117lpO" id="1PjvIwH_aVz" role="2Oq$k0" />
                <node concept="3TrcHB" id="1PjvIwH_bhm" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="1PjvIwH_aIr" role="lcghm">
            <property role="lacIc" value=", '" />
          </node>
          <node concept="l9hG8" id="3WaPWgleSg_" role="lcghm">
            <node concept="2OqwBi" id="3WaPWgleSqn" role="lb14g">
              <node concept="117lpO" id="3WaPWgleShp" role="2Oq$k0" />
              <node concept="3TrcHB" id="3WaPWgleSBl" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgleSF5" role="lcghm">
            <property role="lacIc" value="', " />
          </node>
          <node concept="l9hG8" id="3WaPWgleVkI" role="lcghm">
            <node concept="3cpWs3" id="3WaPWgleWxn" role="lb14g">
              <node concept="Xl_RD" id="3WaPWgleWyu" role="3uHU7w" />
              <node concept="2OqwBi" id="3WaPWgleVu$" role="3uHU7B">
                <node concept="117lpO" id="3WaPWgleVms" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWgleVFy" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:33K18miOFQN" resolve="age" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgleXed" role="lcghm">
            <property role="lacIc" value=",'" />
          </node>
          <node concept="l9hG8" id="3FQc_NktjGG" role="lcghm">
            <node concept="2OqwBi" id="4BkqmtKkp_t" role="lb14g">
              <node concept="2OqwBi" id="3FQc_NktjUF" role="2Oq$k0">
                <node concept="117lpO" id="3FQc_NktjKp" role="2Oq$k0" />
                <node concept="3TrcHB" id="4BkqmtKkprL" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:4BkqmtKkoIt" resolve="country" />
                </node>
              </node>
              <node concept="liA8E" id="4BkqmtKkpKi" role="2OqNvi">
                <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3FQc_Nktke0" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWgleXpR" role="lcghm">
            <node concept="2OqwBi" id="3WaPWgleXVU" role="lb14g">
              <node concept="2OqwBi" id="3WaPWgleX$o" role="2Oq$k0">
                <node concept="117lpO" id="3WaPWgleXsg" role="2Oq$k0" />
                <node concept="3TrEf2" id="3WaPWgleXLT" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                </node>
              </node>
              <node concept="3TrcHB" id="7jX2EUL01g_" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgleYwM" role="lcghm">
            <property role="lacIc" value="'," />
          </node>
          <node concept="l9hG8" id="3WaPWglf46G" role="lcghm">
            <node concept="3cpWs3" id="3WaPWglfyG5" role="lb14g">
              <node concept="Xl_RD" id="3WaPWglfyHn" role="3uHU7w" />
              <node concept="2OqwBi" id="3WaPWglfxys" role="3uHU7B">
                <node concept="2OqwBi" id="3WaPWglf4hJ" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWglf49B" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWglf4uH" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:3WaPWgleThq" resolve="tutor" />
                  </node>
                </node>
                <node concept="3TrcHB" id="3WaPWglfxNK" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="IIjfDnTpNE" role="lcghm">
            <property role="lacIc" value=", " />
          </node>
          <node concept="l9hG8" id="IIjfDnTplW" role="lcghm">
            <node concept="2OqwBi" id="IIjfDnTpyu" role="lb14g">
              <node concept="117lpO" id="IIjfDnTppD" role="2Oq$k0" />
              <node concept="3TrcHB" id="IIjfDnTpJs" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:3WaPWgld_8O" resolve="idRef" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglf4_m" role="lcghm">
            <property role="lacIc" value=");" />
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="3WaPWglkpg4">
    <ref role="WuzLi" to="20wa:5VnHNHVg8Bi" resolve="Contract" />
    <node concept="29tfMY" id="3WaPWglkpg5" role="29tGrW">
      <node concept="3clFbS" id="3WaPWglkpg6" role="2VODD2">
        <node concept="3clFbF" id="3WaPWglkpkE" role="3cqZAp">
          <node concept="3cpWs3" id="3WaPWglkqhM" role="3clFbG">
            <node concept="Xl_RD" id="3WaPWglkqiJ" role="3uHU7B">
              <property role="Xl_RC" value="contract" />
            </node>
            <node concept="2OqwBi" id="3WaPWglkpQ9" role="3uHU7w">
              <node concept="2OqwBi" id="3WaPWglkpyg" role="2Oq$k0">
                <node concept="117lpO" id="3WaPWglkpkD" role="2Oq$k0" />
                <node concept="3TrEf2" id="3WaPWglkpDq" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:51XxSBB41yU" resolve="dataSubject" />
                </node>
              </node>
              <node concept="3TrcHB" id="3WaPWglkq4C" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="3WaPWglkqox" role="33IsuW">
      <node concept="3clFbS" id="3WaPWglkqoy" role="2VODD2">
        <node concept="3clFbF" id="3WaPWglkqAj" role="3cqZAp">
          <node concept="Xl_RD" id="3WaPWglkqAi" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="3WaPWglkqCS" role="11c4hB">
      <node concept="3clFbS" id="3WaPWglkqCT" role="2VODD2">
        <node concept="3clFbH" id="3WaPWglkr29" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglkssC" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglksut" role="lcghm">
            <property role="lacIc" value="insert into gdpr_contract (datasubject, signaturedate, expirationdate) values ('" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglksyz" role="3cqZAp">
          <node concept="l9hG8" id="3WaPWglksTs" role="lcghm">
            <node concept="3cpWs3" id="7McLYwdJRBo" role="lb14g">
              <node concept="Xl_RD" id="7McLYwdJRBC" role="3uHU7w" />
              <node concept="2OqwBi" id="7McLYwdJQFf" role="3uHU7B">
                <node concept="2OqwBi" id="3WaPWglkt1Y" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWglksUj" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWglkt9_" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:51XxSBB41yU" resolve="dataSubject" />
                  </node>
                </node>
                <node concept="3TrcHB" id="7McLYwdJQUa" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglkteb" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWglktgm" role="lcghm">
            <node concept="3cpWs3" id="3WaPWglkui8" role="lb14g">
              <node concept="Xl_RD" id="3WaPWglkuic" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="3WaPWglktik" role="3uHU7B">
                <node concept="117lpO" id="3WaPWglkthD" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWglktjZ" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5VnHNHVg8Bl" resolve="Signaturedate" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglkwYy" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWglkuy3" role="lcghm">
            <node concept="3cpWs3" id="3WaPWglkLhl" role="lb14g">
              <node concept="Xl_RD" id="3WaPWglkLhp" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="3WaPWglkuFv" role="3uHU7B">
                <node concept="117lpO" id="3WaPWglku$0" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWglkwvX" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5VnHNHVg8BP" resolve="Expirationdate" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgllDVq" role="lcghm">
            <property role="lacIc" value="');" />
          </node>
        </node>
        <node concept="3clFbH" id="3WaPWgloUID" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWgllE39" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWgllE8J" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWgloocA" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWgloUb2" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWglpki2" role="3cqZAp" />
        <node concept="2Gpval" id="3WaPWglkrnq" role="3cqZAp">
          <node concept="2GrKxI" id="3WaPWglkrnr" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="3WaPWglkrns" role="2GsD0m">
            <node concept="117lpO" id="3WaPWglkrnt" role="2Oq$k0" />
            <node concept="3Tsc0h" id="3WaPWglkr$n" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:5VnHNHVgh90" resolve="consent" />
            </node>
          </node>
          <node concept="3clFbS" id="3WaPWglkrnv" role="2LFqv$">
            <node concept="lc7rE" id="3WaPWglkrnw" role="3cqZAp">
              <node concept="la8eA" id="3WaPWglkrnx" role="lcghm">
                <property role="lacIc" value="insert into gdpr_consent(datasubject, contract, processing, startdate, enddate) values ('" />
              </node>
              <node concept="l9hG8" id="3WaPWglk_YU" role="lcghm">
                <node concept="3cpWs3" id="7McLYwdJPR0" role="lb14g">
                  <node concept="Xl_RD" id="7McLYwdJPR4" role="3uHU7w" />
                  <node concept="2OqwBi" id="7McLYwdJOJO" role="3uHU7B">
                    <node concept="2OqwBi" id="3WaPWglkA8A" role="2Oq$k0">
                      <node concept="117lpO" id="3WaPWglkA01" role="2Oq$k0" />
                      <node concept="3TrEf2" id="3WaPWglkAgd" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:51XxSBB41yU" resolve="dataSubject" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="7McLYwdJOYJ" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3WaPWglpkK8" role="lcghm">
                <property role="lacIc" value="', " />
              </node>
              <node concept="l9hG8" id="3WaPWglkAmQ" role="lcghm">
                <node concept="3cpWs3" id="3WaPWglkJQw" role="lb14g">
                  <node concept="Xl_RD" id="3WaPWglkJQ$" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="3WaPWglkAp3" role="3uHU7B">
                    <node concept="117lpO" id="3WaPWglkAoo" role="2Oq$k0" />
                    <node concept="3TrcHB" id="3WaPWglkIYR" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:3WaPWglkAyp" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3WaPWglpkOa" role="lcghm">
                <property role="lacIc" value=", '" />
              </node>
              <node concept="l9hG8" id="3WaPWglkrny" role="lcghm">
                <node concept="3cpWs3" id="7jX2EUKZ85g" role="lb14g">
                  <node concept="Xl_RD" id="7jX2EUKZ8o5" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="3WaPWglpJe7" role="3uHU7B">
                    <node concept="2OqwBi" id="3WaPWglpI9_" role="2Oq$k0">
                      <node concept="2OqwBi" id="3WaPWglkrnz" role="2Oq$k0">
                        <node concept="2GrUjf" id="3WaPWglkrn$" role="2Oq$k0">
                          <ref role="2Gs0qQ" node="3WaPWglkrnr" resolve="e" />
                        </node>
                        <node concept="3TrEf2" id="3WaPWglk$xi" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:5VnHNHVgh95" resolve="processing" />
                        </node>
                      </node>
                      <node concept="3TrEf2" id="3WaPWglpIUg" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:2ry5VKd0yKm" resolve="processing" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="7jX2EUKZ7dr" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:7jX2EUKYYaU" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3WaPWglkrnA" role="lcghm">
                <property role="lacIc" value="', '" />
              </node>
              <node concept="l9hG8" id="3WaPWglkrnB" role="lcghm">
                <node concept="2OqwBi" id="3WaPWglkrnC" role="lb14g">
                  <node concept="2GrUjf" id="3WaPWglkrnE" role="2Oq$k0">
                    <ref role="2Gs0qQ" node="3WaPWglkrnr" resolve="e" />
                  </node>
                  <node concept="3TrcHB" id="3WaPWglk$D7" role="2OqNvi">
                    <ref role="3TsBF5" to="20wa:5VnHNHVgh9$" resolve="startDate" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3WaPWglkrnF" role="lcghm">
                <property role="lacIc" value="', '" />
              </node>
              <node concept="l9hG8" id="3WaPWglk_nK" role="lcghm">
                <node concept="2OqwBi" id="3WaPWglk_vj" role="lb14g">
                  <node concept="2GrUjf" id="3WaPWglk_oM" role="2Oq$k0">
                    <ref role="2Gs0qQ" node="3WaPWglkrnr" resolve="e" />
                  </node>
                  <node concept="3TrcHB" id="3WaPWglk_Vg" role="2OqNvi">
                    <ref role="3TsBF5" to="20wa:5VnHNHVgh9A" resolve="endDate" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3WaPWglk_X_" role="lcghm">
                <property role="lacIc" value="');" />
              </node>
            </node>
            <node concept="lc7rE" id="3WaPWgllE9$" role="3cqZAp">
              <node concept="l8MVK" id="3WaPWgllEbk" role="lcghm" />
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="3WaPWglkrn9" role="3cqZAp" />
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="w$4DGO$wJ4">
    <ref role="WuzLi" to="20wa:w$4DGO$wJ3" resolve="PRIAM_GDPR" />
    <node concept="9MYSb" id="w$4DGO$wJ5" role="33IsuW">
      <node concept="3clFbS" id="w$4DGO$wJ6" role="2VODD2">
        <node concept="3clFbF" id="7bfLM_U7AOW" role="3cqZAp">
          <node concept="Xl_RD" id="7bfLM_U7AOV" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="w$4DGO$wNH" role="11c4hB">
      <node concept="3clFbS" id="w$4DGO$wNI" role="2VODD2">
        <node concept="3clFbH" id="3FQc_NkmzJ3" role="3cqZAp" />
        <node concept="lc7rE" id="1PjvIwH_clc" role="3cqZAp">
          <node concept="la8eA" id="1PjvIwH_cld" role="lcghm">
            <property role="lacIc" value="-- Personal Data Category annotation table creation" />
          </node>
          <node concept="l8MVK" id="1PjvIwH_cle" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1PjvIwH_ccY" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur7cv" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur7hD" role="lcghm">
            <property role="lacIc" value="create table gdpr_PersonalDataCategory(" />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur7oE" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur7tQ" role="lcghm">
            <property role="lacIc" value="PDCategoryID int primary key," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur7O3" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur7Tk" role="lcghm">
            <property role="lacIc" value="personalDataCategory varchar(150));" />
          </node>
        </node>
        <node concept="3clFbH" id="1ZMIcpur7u9" role="3cqZAp" />
        <node concept="3clFbH" id="3casRoZzpob" role="3cqZAp" />
        <node concept="lc7rE" id="7bfLM_U7tXA" role="3cqZAp">
          <node concept="l8MVK" id="7bfLM_U7tXB" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7tsz" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7ts$" role="lcghm">
            <property role="lacIc" value="-- Data Annotation table Creation --" />
          </node>
          <node concept="l8MVK" id="1ZMIcpur2Xw" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur32e" role="3cqZAp" />
        <node concept="lc7rE" id="3FQc_NkmyZz" role="3cqZAp">
          <node concept="l8MVK" id="3FQc_Nkmzb4" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3FQc_NkmznP" role="3cqZAp">
          <node concept="la8eA" id="3FQc_Nkmzv_" role="lcghm">
            <property role="lacIc" value="-- DataType table creation" />
          </node>
          <node concept="l8MVK" id="40yFoui0RF_" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3FQc_NkmzUz" role="3cqZAp">
          <node concept="la8eA" id="3FQc_Nkm$2n" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataType (" />
          </node>
        </node>
        <node concept="lc7rE" id="3FQc_Nkm$g4" role="3cqZAp">
          <node concept="la8eA" id="3FQc_Nkm$nU" role="lcghm">
            <property role="lacIc" value="dataTypeName varchar(40) primary key);" />
          </node>
        </node>
        <node concept="3clFbH" id="3FQc_NkmzCp" role="3cqZAp" />
        <node concept="lc7rE" id="40yFouhZGKW" role="3cqZAp">
          <node concept="l8MVK" id="40yFouhZGWO" role="lcghm" />
        </node>
        <node concept="lc7rE" id="40yFoui1yxU" role="3cqZAp">
          <node concept="la8eA" id="40yFoui1yxV" role="lcghm">
            <property role="lacIc" value="-- Data table creation" />
          </node>
          <node concept="l8MVK" id="40yFoui1yxW" role="lcghm" />
        </node>
        <node concept="3clFbH" id="40yFoui1ypG" role="3cqZAp" />
        <node concept="3clFbH" id="40yFouhZGX7" role="3cqZAp" />
        <node concept="lc7rE" id="w$4DGO$wOn" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wOo" role="lcghm">
            <property role="lacIc" value="create table gdpr_Data( " />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglmrU$" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglms0s" role="lcghm">
            <property role="lacIc" value="dataID int primary key," />
          </node>
        </node>
        <node concept="1X3_iC" id="3casRoZyJau" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="w$4DGO$wOt" role="8Wnug">
            <node concept="la8eA" id="w$4DGO$wOu" role="lcghm">
              <property role="lacIc" value="attributeName varchar(25), " />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="w$4DGO$wOz" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wO$" role="lcghm">
            <property role="lacIc" value="source varchar(25), " />
          </node>
        </node>
        <node concept="lc7rE" id="w$4DGO$wOA" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wOB" role="lcghm">
            <property role="lacIc" value="dataConservation int, " />
          </node>
        </node>
        <node concept="lc7rE" id="w$4DGO$wOD" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wOE" role="lcghm">
            <property role="lacIc" value="isPersonal boolean," />
          </node>
        </node>
        <node concept="lc7rE" id="3FQc_Nkm_4P" role="3cqZAp">
          <node concept="la8eA" id="3FQc_Nkm_4Q" role="lcghm">
            <property role="lacIc" value="dataTypeName varchar(40)," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur6Ul" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur6Zs" role="lcghm">
            <property role="lacIc" value="personalDataCategory int," />
          </node>
        </node>
        <node concept="lc7rE" id="3FQc_Nkm$yG" role="3cqZAp">
          <node concept="la8eA" id="3FQc_Nkm$yH" role="lcghm">
            <property role="lacIc" value="foreign key (dataTypeName) references gdpr_DataType(dataTypeName)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w3Yu" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w3Yv" role="lcghm">
            <property role="lacIc" value="foreign key(personalDataCategory) references gdpr_PersonalDataCategory(PDCategoryID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3v35F" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3v3bz" role="lcghm">
            <property role="lacIc" value="constraint const1 check  (source in ('Direct', 'Indirect', 'Produced')));" />
          </node>
          <node concept="l8MVK" id="23QIlu3vZHN" role="lcghm" />
        </node>
        <node concept="3clFbH" id="w$4DGO$wPT" role="3cqZAp" />
        <node concept="lc7rE" id="7bfLM_U7tar" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7tcz" role="lcghm">
            <property role="lacIc" value="-- Processing Annotation table Creation --" />
          </node>
          <node concept="l8MVK" id="1ZMIcpur2Su" role="lcghm" />
        </node>
        <node concept="3clFbH" id="7bfLM_U7ti7" role="3cqZAp" />
        <node concept="lc7rE" id="2yHMJEzijGW" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzijSu" role="lcghm">
            <property role="lacIc" value="create table gdpr_context (" />
          </node>
        </node>
        <node concept="lc7rE" id="2yHMJEzik2v" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzike3" role="lcghm">
            <property role="lacIc" value="environmentName varchar(100) primary key);" />
          </node>
        </node>
        <node concept="3clFbH" id="2yHMJEzikil" role="3cqZAp" />
        <node concept="lc7rE" id="2yHMJEzik_H" role="3cqZAp">
          <node concept="l8MVK" id="2yHMJEzikLk" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2yHMJEzikTy" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzil1$" role="lcghm">
            <property role="lacIc" value="create table gdpr_ontology (" />
          </node>
        </node>
        <node concept="lc7rE" id="2yHMJEzilen" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzilmr" role="lcghm">
            <property role="lacIc" value="ontologyName varchar(100) primary key, " />
          </node>
        </node>
        <node concept="lc7rE" id="2yHMJEzilvz" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzilFg" role="lcghm">
            <property role="lacIc" value="context varchar(100), " />
          </node>
        </node>
        <node concept="lc7rE" id="2yHMJEzilSO" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzim0W" role="lcghm">
            <property role="lacIc" value="foreign key (context) references gdpr_Context(environmentName));" />
          </node>
        </node>
        <node concept="3clFbH" id="2yHMJEzimhO" role="3cqZAp" />
        <node concept="lc7rE" id="2yHMJEziol1" role="3cqZAp">
          <node concept="l8MVK" id="2yHMJEziotj" role="lcghm" />
        </node>
        <node concept="3clFbH" id="2yHMJEzinSR" role="3cqZAp" />
        <node concept="lc7rE" id="w$4DGO$wR4" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wR5" role="lcghm">
            <property role="lacIc" value="create table gdpr_Processing (" />
          </node>
        </node>
        <node concept="lc7rE" id="w$4DGO$wR7" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wR8" role="lcghm">
            <property role="lacIc" value="processingID int primary key , " />
          </node>
        </node>
        <node concept="lc7rE" id="w$4DGO$wRa" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wRb" role="lcghm">
            <property role="lacIc" value="processingName varchar(25), " />
          </node>
        </node>
        <node concept="lc7rE" id="w$4DGO$wRd" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wRe" role="lcghm">
            <property role="lacIc" value="processingType varchar(25), " />
          </node>
        </node>
        <node concept="lc7rE" id="w$4DGO$wRg" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wRh" role="lcghm">
            <property role="lacIc" value="processingCategory varchar(25) , " />
          </node>
        </node>
        <node concept="lc7rE" id="w$4DGO$wRj" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wRk" role="lcghm">
            <property role="lacIc" value="creationDate date, " />
          </node>
        </node>
        <node concept="lc7rE" id="w$4DGO$wRm" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wRn" role="lcghm">
            <property role="lacIc" value="updatingDate date," />
          </node>
        </node>
        <node concept="lc7rE" id="3FQc_NkmyeB" role="3cqZAp">
          <node concept="la8eA" id="3FQc_NkmyeC" role="lcghm">
            <property role="lacIc" value="isService boolean," />
          </node>
        </node>
        <node concept="lc7rE" id="2yHMJEzind9" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzinda" role="lcghm">
            <property role="lacIc" value="context varchar(100), " />
          </node>
        </node>
        <node concept="lc7rE" id="2yHMJEzimWQ" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzimWR" role="lcghm">
            <property role="lacIc" value="foreign key (context) references gdpr_Context(environmentName), " />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3vZOA" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3vZOB" role="lcghm">
            <property role="lacIc" value="constraint const1 check (processingType in('Default','Mandatory','Optional'))," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w06X" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w06Y" role="lcghm">
            <property role="lacIc" value="constraint const2 check (processingCategory in('Consent_Contract','Legitimate interest','Legal Obligation','Public interest','Vital interest')));" />
          </node>
          <node concept="l8MVK" id="23QIlu3w06Z" role="lcghm" />
        </node>
        <node concept="3clFbH" id="23QIlu3vZIN" role="3cqZAp" />
        <node concept="3clFbH" id="2yHMJEzim5e" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqV7K" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpuqVay" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqUYE" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqV1o" role="lcghm">
            <property role="lacIc" value="create table gdpr_Purpose (" />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqVmx" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVmy" role="lcghm">
            <property role="lacIc" value="purposeID int primary key auto_increment, " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqV51" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqV52" role="lcghm">
            <property role="lacIc" value="description varchar(200) not null," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqVdy" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVgm" role="lcghm">
            <property role="lacIc" value="type varchar(10) ," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqVjo" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVme" role="lcghm">
            <property role="lacIc" value="processing int ," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w0rb" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w0rc" role="lcghm">
            <property role="lacIc" value="foreign key (processing) references  gdpr_Processing(processingID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w8VW" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w8VX" role="lcghm">
            <property role="lacIc" value="constraint const1 check(type in ('Main', 'Secondary')));" />
          </node>
        </node>
        <node concept="3clFbH" id="23QIlu3w92E" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqVyX" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpuqV_R" role="lcghm" />
        </node>
        <node concept="3clFbH" id="23QIlu3w9n2" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqVCZ" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVG8" role="lcghm">
            <property role="lacIc" value="create table gdpr_ProcessingLink(" />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqVL9" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVO7" role="lcghm">
            <property role="lacIc" value="processing1 int, " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqVSK" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVVK" role="lcghm">
            <property role="lacIc" value="processing2 int, " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqW0o" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqW3q" role="lcghm">
            <property role="lacIc" value="typeLink varchar(20)," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqW6E" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqW9I" role="lcghm">
            <property role="lacIc" value="primary key(processing1, processing2)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w8vR" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w8Az" role="lcghm">
            <property role="lacIc" value="foreign key (processing1) references  gdpr_Processing(processingID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w8Ip" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w8Iq" role="lcghm">
            <property role="lacIc" value="foreign key (processing2) references  gdpr_Processing(processingID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w0Es" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w0Et" role="lcghm">
            <property role="lacIc" value="constraint const1 check (typelink in('SimilarityLink', 'IndusionLink', 'AgregationLink')));" />
          </node>
        </node>
        <node concept="3clFbH" id="1ZMIcpuqV2o" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqWr5" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpuqWr6" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1PjvIwH_bTS" role="3cqZAp" />
        <node concept="3clFbH" id="1PjvIwH_c12" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqWEJ" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqWHX" role="lcghm">
            <property role="lacIc" value="-- actors creation ---" />
          </node>
          <node concept="l8MVK" id="1ZMIcpur2RR" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpuqZX7" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpur2Eb" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur0Jf" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur0Np" role="lcghm">
            <property role="lacIc" value="-- Creation of static table Country --" />
          </node>
          <node concept="l8MVK" id="1ZMIcpusvWE" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpusvWY" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur04I" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur08J" role="lcghm">
            <property role="lacIc" value="create Table gdpr_Country( " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur0o$" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur0sD" role="lcghm">
            <property role="lacIc" value="countryName varchar(100) primary key);" />
          </node>
        </node>
        <node concept="3clFbH" id="1ZMIcpur0vx" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur2_G" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpur2_H" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur2xj" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqWMN" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqWQ3" role="lcghm">
            <property role="lacIc" value="create table gdpr_Provider(" />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqX9D" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXcX" role="lcghm">
            <property role="lacIc" value="providerID int primary key auto_increment," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXi8" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXlu" role="lcghm">
            <property role="lacIc" value="prName varchar(40) not null," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqY5N" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqY5O" role="lcghm">
            <property role="lacIc" value="username varchar(25), " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXr9" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXra" role="lcghm">
            <property role="lacIc" value="prAdress varchar(250) not null," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXyx" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXyy" role="lcghm">
            <property role="lacIc" value="prPostalCode varchar(40)," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXEt" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXEu" role="lcghm">
            <property role="lacIc" value="city varchar(40)," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXM1" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXM2" role="lcghm">
            <property role="lacIc" value="prPhone varchar(40)," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXTF" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXTG" role="lcghm">
            <property role="lacIc" value="prEmail varchar(40), " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqZxg" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqZ_m" role="lcghm">
            <property role="lacIc" value="country varchar(100), " />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w0Zo" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w15v" role="lcghm">
            <property role="lacIc" value="foreign key(country) references gdpr_Country(countryName));" />
          </node>
        </node>
        <node concept="3clFbH" id="1ZMIcpuqXQe" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur2sR" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpur2sS" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur2ox" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqYeG" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqYeH" role="lcghm">
            <property role="lacIc" value="create table gdpr_Tutor(" />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqYeI" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqYeJ" role="lcghm">
            <property role="lacIc" value="tutorID int primary key auto_increment," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqYeK" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqYeL" role="lcghm">
            <property role="lacIc" value="tutorName varchar(40) not null," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqYeM" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqYeN" role="lcghm">
            <property role="lacIc" value="username varchar(25), " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqZGW" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqZGX" role="lcghm">
            <property role="lacIc" value="country varchar(100), " />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w1nE" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w1nF" role="lcghm">
            <property role="lacIc" value="foreign key(country) references gdpr_Country(countryName));" />
          </node>
        </node>
        <node concept="3clFbH" id="1ZMIcpuqZCV" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur2fO" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpur2fP" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur2kc" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur1eR" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur1eS" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataConsumerCategory(" />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur1eT" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur1eU" role="lcghm">
            <property role="lacIc" value="dcCategoryID int primary key auto_increment," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur1eV" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur1eW" role="lcghm">
            <property role="lacIc" value="dcCategoryName varchar(40) );" />
          </node>
        </node>
        <node concept="3clFbH" id="1ZMIcpur1Mg" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur22U" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpur22V" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpuqYoF" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqYwa" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqYwb" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataConsumer(" />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqYwc" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqYwd" role="lcghm">
            <property role="lacIc" value="dataConsumerID int primary key auto_increment," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqYwe" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqYwf" role="lcghm">
            <property role="lacIc" value="dconsumerName varchar(40) not null," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur1n_" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur1nA" role="lcghm">
            <property role="lacIc" value="dcCategory int," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpuqZTb" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqZTc" role="lcghm">
            <property role="lacIc" value="country varchar(100)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w2hj" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w2hk" role="lcghm">
            <property role="lacIc" value="foreign key(dcCategory) references gdpr_DataConsumerCategory(dcCategoryID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w1_0" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w1_1" role="lcghm">
            <property role="lacIc" value="foreign key(country) references gdpr_Country(countryName));" />
          </node>
        </node>
        <node concept="3clFbH" id="23QIlu3w1uW" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpuqZPl" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpuqYsq" role="3cqZAp" />
        <node concept="lc7rE" id="7bfLM_U7t_k" role="3cqZAp">
          <node concept="l8MVK" id="7bfLM_U7t_l" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7t_h" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7t_i" role="lcghm">
            <property role="lacIc" value="-- DataSubject table gdpr_Creation --" />
          </node>
          <node concept="l8MVK" id="7bfLM_U7t_j" role="lcghm" />
        </node>
        <node concept="3clFbH" id="7bfLM_U7u88" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcnDh" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcnDi" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataSubjectCategory (" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglcnDj" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcnDk" role="lcghm">
            <property role="lacIc" value="dsCategory varchar(25) primary key , " />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglcnDl" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcnDm" role="lcghm">
            <property role="lacIc" value="locationID varchar(40));" />
          </node>
        </node>
        <node concept="3clFbH" id="23QIlu3w1SC" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcnDt" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcnDu" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglcnDv" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcpao" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcpap" role="lcghm">
            <property role="lacIc" value="insert into gdpr_DatasubjectCategory (locationID, dsCategory) values ('" />
          </node>
          <node concept="l9hG8" id="5Erw5yf9OQl" role="lcghm">
            <node concept="2OqwBi" id="5Erw5yf9PkG" role="lb14g">
              <node concept="2OqwBi" id="5Erw5yf9OZR" role="2Oq$k0">
                <node concept="117lpO" id="5Erw5yf9ORc" role="2Oq$k0" />
                <node concept="3TrEf2" id="5Erw5yf9P9m" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:4Xqrfpmh_pD" resolve="dataSubjectCategory" />
                </node>
              </node>
              <node concept="3TrcHB" id="3FQc_NkokT2" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="5Erw5yf9PAY" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="5Erw5yf9PD6" role="lcghm">
            <node concept="2OqwBi" id="3FQc_Nkol8Y" role="lb14g">
              <node concept="2OqwBi" id="5Erw5yf9PLb" role="2Oq$k0">
                <node concept="117lpO" id="5Erw5yf9PEv" role="2Oq$k0" />
                <node concept="3TrEf2" id="5Erw5yf9PU7" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:4Xqrfpmh_pD" resolve="dataSubjectCategory" />
                </node>
              </node>
              <node concept="3TrcHB" id="3FQc_NkolaV" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="5Erw5yf9Qyu" role="lcghm">
            <property role="lacIc" value="');" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglcpaq" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcpar" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglcpau" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcpav" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglcpgD" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWglcnzA" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcm7v" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcmdg" role="lcghm">
            <property role="lacIc" value="delimiter $\n CREATE DEFINER=`root`@`localhost` PROCEDURE `CreateDataSubject`()\n    NO SQL\nBEGIN\n\n    DECLARE id_ref Varchar(200);\n    DECLARE tab_ref Varchar(200);\n    DECLARE req Varchar(200);\n\n\n\n    select  dsCategory into tab_ref FROM `gdpr_datasubjectcategory`   ;\n    select  locationID into id_ref FROM `gdpr_datasubjectcategory`;\n\n\n    set req = CONCAT('create table gdpr_DataSubject as Select ', id_ref);\n    set req = CONCAT(req, ' from ');\n    set req = CONCAT(req,tab_ref );\n    set req = CONCAT(req, ' where 1&lt;0;' );\n\n    set @query = null;\n    \n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD dataSubjectID int primary key FIRST;';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD userName varchar(40);';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD password varchar(40);';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD age int;';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD country varchar(100) references gdpr_Country ;';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD dsCategory varchar(40) ;';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD tutor int ;';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD constraint const1 foreign key(dsCategory) references gdpr_DataSubjectCategory(dsCategory);';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n    set req=CONCAT('ALTER TABLE gdpr_DataSubject ADD CONSTRAINT const2 foreign key (', id_ref);\n    set req=CONCAT(req,') references  ');\n    set req=CONCAT(req, tab_ref);\n    set req=CONCAT(req, '(');\n    set req=CONCAT(req , id_ref);\n    set req=CONCAT(req,');');\n\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\nend\n$\n" />
          </node>
        </node>
        <node concept="3clFbH" id="3WaPWglco0O" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcn1n" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcn76" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglcnV6" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcmNF" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcmT_" role="lcghm">
            <property role="lacIc" value="call CreateDataSubject();" />
          </node>
        </node>
        <node concept="3clFbH" id="3WaPWglcnPp" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcn7p" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcnd9" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur1Ux" role="3cqZAp" />
        <node concept="3clFbH" id="7bfLM_U7u3Y" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur4y8" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur4AR" role="lcghm">
            <property role="lacIc" value="-- DataUsage Annotation --" />
          </node>
          <node concept="l8MVK" id="1ZMIcpur4N8" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur4Dw" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpur72A" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpur7Wc" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur4S9" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur4WX" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataUsage(" />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur53a" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur580" role="lcghm">
            <property role="lacIc" value="id int primary key auto_increment," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur5q6" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur5uY" role="lcghm">
            <property role="lacIc" value="personalStatus boolean default 0," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur5Ab" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur5F5" role="lcghm">
            <property role="lacIc" value="C boolean default 0," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur5KF" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur5PB" role="lcghm">
            <property role="lacIc" value="r boolean default 0," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur5VK" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur60I" role="lcghm">
            <property role="lacIc" value="u boolean default 0," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur6hi" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur6mi" role="lcghm">
            <property role="lacIc" value="d boolean default 0," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur6ss" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur6xu" role="lcghm">
            <property role="lacIc" value="data int," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur6C8" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur6Hc" role="lcghm">
            <property role="lacIc" value="processing int," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w3_e" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w3_f" role="lcghm">
            <property role="lacIc" value="foreign key(data) references gdpr_Data(dataID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w3LN" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w3LO" role="lcghm">
            <property role="lacIc" value="foreign key(processing) references gdpr_Processing(processingID));" />
          </node>
        </node>
        <node concept="3clFbH" id="23QIlu3w3Sa" role="3cqZAp" />
        <node concept="3clFbH" id="23QIlu3w3Fy" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpur6Ic" role="3cqZAp" />
        <node concept="lc7rE" id="7bfLM_U7urv" role="3cqZAp">
          <node concept="l8MVK" id="7bfLM_U7urw" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur8lU" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur8JY" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur8Pi" role="lcghm">
            <property role="lacIc" value="-- annotation of all tranfert data to any receiver --" />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpus3Rx" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpus3Xe" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur92S" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur98f" role="lcghm">
            <property role="lacIc" value="create table gdpr_PersonalDataReception(" />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur9ex" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur9jU" role="lcghm">
            <property role="lacIc" value="data int, " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur9ra" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur9rb" role="lcghm">
            <property role="lacIc" value="processing int," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur9Dd" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur9IF" role="lcghm">
            <property role="lacIc" value="dataConsumer int," />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur9QH" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur9Wd" role="lcghm">
            <property role="lacIc" value="primary key (data, processing, dataConsumer)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3xvQV" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3xvQW" role="lcghm">
            <property role="lacIc" value="foreign key(data) references gdpr_Data(dataID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w2_j" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w2_k" role="lcghm">
            <property role="lacIc" value="foreign key(processing) references gdpr_Processing(processingID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w2_l" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w2_m" role="lcghm">
            <property role="lacIc" value="foreign key(dataConsumer) references gdpr_DataConsumer(dataConsumerID));" />
          </node>
        </node>
        <node concept="3clFbH" id="1ZMIcpur9lQ" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpur8EL" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur8w1" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpur8_i" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7urx" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7ury" role="lcghm">
            <property role="lacIc" value="-- DataSubject Rights Creation--" />
          </node>
          <node concept="l8MVK" id="7bfLM_U7urz" role="lcghm" />
        </node>
        <node concept="3clFbH" id="7bfLM_U7upl" role="3cqZAp" />
        <node concept="lc7rE" id="7bfLM_U7sJI" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJJ" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataRequest ( " />
          </node>
        </node>
        <node concept="lc7rE" id="7bfLM_U7sJL" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJM" role="lcghm">
            <property role="lacIc" value="DataRequestID int primary key , " />
          </node>
        </node>
        <node concept="lc7rE" id="7bfLM_U7sJO" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJP" role="lcghm">
            <property role="lacIc" value="claim varchar(250), " />
          </node>
        </node>
        <node concept="lc7rE" id="7bfLM_U7sJR" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJS" role="lcghm">
            <property role="lacIc" value="claimDate datetime, " />
          </node>
        </node>
        <node concept="lc7rE" id="7bfLM_U7sJU" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJV" role="lcghm">
            <property role="lacIc" value="newValue varchar(250), " />
          </node>
        </node>
        <node concept="lc7rE" id="2cm5$ryb8Cx" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb8S0" role="lcghm">
            <property role="lacIc" value="dataReqType varchar(25)," />
          </node>
        </node>
        <node concept="lc7rE" id="7bfLM_U7sJX" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJY" role="lcghm">
            <property role="lacIc" value="dataSubject int," />
          </node>
        </node>
        <node concept="lc7rE" id="7bfLM_U7sZW" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7t1M" role="lcghm">
            <property role="lacIc" value="data int," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w2OO" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w2OP" role="lcghm">
            <property role="lacIc" value="foreign key(data) references gdpr_Data(dataID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w2OQ" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w2OR" role="lcghm">
            <property role="lacIc" value="foreign key(dataSubject) references gdpr_DataSubject(datasubjectID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w5RJ" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w5RK" role="lcghm">
            <property role="lacIc" value="constraint const1 check (dataReqType in ('Rectification', 'Erasure', 'Access')));" />
          </node>
        </node>
        <node concept="3clFbH" id="23QIlu3w2IG" role="3cqZAp" />
        <node concept="3clFbH" id="2cm5$ryb92B" role="3cqZAp" />
        <node concept="lc7rE" id="2cm5$ryb98v" role="3cqZAp">
          <node concept="l8MVK" id="2cm5$ryb9b8" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglg3bn" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglg3xU" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg3C9" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataRequestAnswer(" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglg3KT" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg3RG" role="lcghm">
            <property role="lacIc" value="dataRequestAnswerid int primary key ," />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglg3Zx" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg45j" role="lcghm">
            <property role="lacIc" value="answer boolean," />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglg4bL" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg4h_" role="lcghm">
            <property role="lacIc" value="justification varchar(150)," />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglg4p1" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg4uR" role="lcghm">
            <property role="lacIc" value="datarequest int," />
          </node>
        </node>
        <node concept="lc7rE" id="IIjfDnQJ$w" role="3cqZAp">
          <node concept="la8eA" id="IIjfDnQJEp" role="lcghm">
            <property role="lacIc" value="foreign key (datarequest) references gdpr_DataRequest(DataRequestID));" />
          </node>
        </node>
        <node concept="3clFbH" id="IIjfDnQI8y" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglg3mk" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglg3s0" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2cm5$ryb9du" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9fC" role="lcghm">
            <property role="lacIc" value="create table gdpr_ProcessingRequest(" />
          </node>
        </node>
        <node concept="lc7rE" id="2cm5$ryb9if" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9kr" role="lcghm">
            <property role="lacIc" value="id int primary key, " />
          </node>
        </node>
        <node concept="lc7rE" id="2cm5$ryb9pS" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9s6" role="lcghm">
            <property role="lacIc" value="claim varchar(250), " />
          </node>
        </node>
        <node concept="lc7rE" id="2cm5$ryb9wG" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9yW" role="lcghm">
            <property role="lacIc" value="claimDate datetime, " />
          </node>
        </node>
        <node concept="lc7rE" id="2cm5$ryb9HZ" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9KL" role="lcghm">
            <property role="lacIc" value="procReqType varchar(25)," />
          </node>
        </node>
        <node concept="lc7rE" id="2cm5$ryb9B3" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9Dl" role="lcghm">
            <property role="lacIc" value="dataSubject int, " />
          </node>
        </node>
        <node concept="lc7rE" id="2cm5$rybadC" role="3cqZAp">
          <node concept="la8eA" id="2cm5$rybafX" role="lcghm">
            <property role="lacIc" value="processing int, " />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w4tv" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w4tw" role="lcghm">
            <property role="lacIc" value="foreign key (dataSubject) references gdpr_DataSubject(datasubjectID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w4_k" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w4_l" role="lcghm">
            <property role="lacIc" value="foreign key (processing) references gdpr_Processing(processingID)," />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w4NO" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w4NP" role="lcghm">
            <property role="lacIc" value="constraint const1 check (procReqType in ('Objection', 'Knowldge')));" />
          </node>
        </node>
        <node concept="3clFbH" id="23QIlu3w4Hq" role="3cqZAp" />
        <node concept="3clFbH" id="7bfLM_U7t52" role="3cqZAp" />
        <node concept="lc7rE" id="2cm5$ryb96g" role="3cqZAp">
          <node concept="l8MVK" id="2cm5$ryb96h" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpurIH3" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcput64H" role="3cqZAp" />
        <node concept="lc7rE" id="2cm5$rybH5P" role="3cqZAp">
          <node concept="la8eA" id="2cm5$rybH8i" role="lcghm">
            <property role="lacIc" value="-- Contract and consent management --" />
          </node>
          <node concept="l8MVK" id="2cm5$rybHca" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpus4tM" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglco6M" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcocC" role="lcghm">
            <property role="lacIc" value="create table gdpr_Contract(" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglcojC" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcopw" role="lcghm">
            <property role="lacIc" value="contractID int primary key auto_increment," />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglcoxH" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcoBB" role="lcghm">
            <property role="lacIc" value="signaturedate date, " />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglcoIU" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcoOQ" role="lcghm">
            <property role="lacIc" value="expirationDate date, " />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglcoWq" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcp2o" role="lcghm">
            <property role="lacIc" value="dataSubject int, " />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w4WH" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w4WI" role="lcghm">
            <property role="lacIc" value="foreign key (dataSubject) references gdpr_Datasubject(datasubjectID));" />
          </node>
        </node>
        <node concept="3clFbH" id="1ZMIcpusaao" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcpyk" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcpCi" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglcpC_" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur3t6" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur3t7" role="lcghm">
            <property role="lacIc" value="create table gdpr_Consent (" />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur3t8" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur3t9" role="lcghm">
            <property role="lacIc" value="consentID int primary key auto_increment,  " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur3tg" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur3th" role="lcghm">
            <property role="lacIc" value="startDate date, " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur3ti" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur3tj" role="lcghm">
            <property role="lacIc" value="endDate date, " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur3VS" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur40$" role="lcghm">
            <property role="lacIc" value="processing int, " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur46D" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur4bn" role="lcghm">
            <property role="lacIc" value="contract int, " />
          </node>
        </node>
        <node concept="lc7rE" id="1ZMIcpur4hi" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur4m2" role="lcghm">
            <property role="lacIc" value="dataSubject int, " />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w5DQ" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w5DR" role="lcghm">
            <property role="lacIc" value="foreign key (processing) references gdpr_Processing(processingID), " />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w5k4" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w5k5" role="lcghm">
            <property role="lacIc" value="foreign key (contract) references gdpr_Contract(contractID), " />
          </node>
        </node>
        <node concept="lc7rE" id="23QIlu3w55_" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w55A" role="lcghm">
            <property role="lacIc" value="foreign key (dataSubject) references gdpr_Datasubject(datasubjectID));" />
          </node>
        </node>
        <node concept="3clFbH" id="7bfLM_U7syQ" role="3cqZAp" />
        <node concept="3clFbH" id="w$4DGO$wQu" role="3cqZAp" />
      </node>
    </node>
    <node concept="29tfMY" id="7bfLM_U7Bnw" role="29tGrW">
      <node concept="3clFbS" id="7bfLM_U7Bnx" role="2VODD2">
        <node concept="3clFbF" id="7bfLM_U7Bs$" role="3cqZAp">
          <node concept="Xl_RD" id="5Erw5yfbvGZ" role="3clFbG">
            <property role="Xl_RC" value="PRIAM_GDPR" />
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="424h5AVip6N">
    <ref role="WuzLi" to="20wa:2olOl3C34Ay" resolve="PersonalDataAnnotation" />
    <node concept="29tfMY" id="424h5AVip6O" role="29tGrW">
      <node concept="3clFbS" id="424h5AVip6P" role="2VODD2">
        <node concept="3clFbF" id="2olOl3C5Kkq" role="3cqZAp">
          <node concept="Xl_RD" id="2olOl3C5Kkp" role="3clFbG">
            <property role="Xl_RC" value="PersonalDataAnnotation" />
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="424h5AVipIL" role="33IsuW">
      <node concept="3clFbS" id="424h5AVipIM" role="2VODD2">
        <node concept="3clFbF" id="424h5AVipJI" role="3cqZAp">
          <node concept="Xl_RD" id="424h5AViqkP" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="424h5AViqt3" role="11c4hB">
      <node concept="3clFbS" id="424h5AViqt4" role="2VODD2">
        <node concept="3cpWs8" id="2U9My3wq0SP" role="3cqZAp">
          <node concept="3cpWsn" id="2U9My3wq0SL" role="3cpWs9">
            <property role="TrG5h" value="p" />
            <node concept="17QB3L" id="2U9My3wq0VM" role="1tU5fm" />
            <node concept="Xl_RD" id="2U9My3wq2vv" role="33vP2m">
              <property role="Xl_RC" value="true" />
            </node>
          </node>
        </node>
        <node concept="3SKdUt" id="AQqjC1KQJr" role="3cqZAp">
          <node concept="1PaTwC" id="AQqjC1KQJs" role="1aUNEU" />
        </node>
        <node concept="3clFbH" id="2olOl3C5ERU" role="3cqZAp" />
        <node concept="2Gpval" id="2olOl3C5FHx" role="3cqZAp">
          <node concept="2GrKxI" id="2olOl3C5FHy" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="2olOl3C5FHz" role="2GsD0m">
            <node concept="117lpO" id="2olOl3C5FH$" role="2Oq$k0" />
            <node concept="3Tsc0h" id="2olOl3C5Gfz" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:2olOl3C34Az" resolve="personalData" />
            </node>
          </node>
          <node concept="3clFbS" id="2olOl3C5FHA" role="2LFqv$">
            <node concept="lc7rE" id="2U9My3wpWlh" role="3cqZAp">
              <node concept="la8eA" id="2U9My3wpWlP" role="lcghm">
                <property role="lacIc" value="insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)" />
              </node>
              <node concept="l8MVK" id="40NILoP1oBH" role="lcghm" />
              <node concept="la8eA" id="40NILoP1oDy" role="lcghm">
                <property role="lacIc" value="   values (" />
              </node>
              <node concept="l9hG8" id="1PjvIwH_teX" role="lcghm">
                <node concept="3cpWs3" id="1PjvIwH_w$m" role="lb14g">
                  <node concept="Xl_RD" id="1PjvIwH_w$q" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="1PjvIwH_tqO" role="3uHU7B">
                    <node concept="2GrUjf" id="1PjvIwH_thT" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="2olOl3C5FHy" resolve="e" />
                    </node>
                    <node concept="3TrcHB" id="1PjvIwH_u23" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="1PjvIwH_t96" role="lcghm">
                <property role="lacIc" value=", '" />
              </node>
              <node concept="l9hG8" id="2U9My3wpWO5" role="lcghm">
                <node concept="2OqwBi" id="2ewkApsoL5N" role="lb14g">
                  <node concept="2OqwBi" id="2U9My3wpWPP" role="2Oq$k0">
                    <node concept="3TrEf2" id="1j2riNJE$E" role="2OqNvi">
                      <ref role="3Tt5mk" to="20wa:1j2riNJlah" resolve="dataType" />
                    </node>
                    <node concept="2GrUjf" id="2olOl3C5Ht5" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="2olOl3C5FHy" resolve="e" />
                    </node>
                  </node>
                  <node concept="3TrcHB" id="2ewkApsoLi8" role="2OqNvi">
                    <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2U9My3wpWTj" role="lcghm">
                <property role="lacIc" value="', '" />
              </node>
              <node concept="l9hG8" id="2U9My3wpWWm" role="lcghm">
                <node concept="2OqwBi" id="5l7YRmKfU7b" role="lb14g">
                  <node concept="2OqwBi" id="2U9My3wpX4z" role="2Oq$k0">
                    <node concept="2GrUjf" id="2olOl3C5Hwx" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="2olOl3C5FHy" resolve="e" />
                    </node>
                    <node concept="3TrcHB" id="5l7YRmKfTXw" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVgh9K" resolve="source" />
                    </node>
                  </node>
                  <node concept="liA8E" id="5l7YRmKfUFh" role="2OqNvi">
                    <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2olOl3C6rf7" role="lcghm">
                <property role="lacIc" value="','" />
              </node>
              <node concept="l9hG8" id="2olOl3C6rgP" role="lcghm">
                <node concept="3cpWs3" id="2olOl3C6y_V" role="lb14g">
                  <node concept="Xl_RD" id="2olOl3C6yCS" role="3uHU7w" />
                  <node concept="2OqwBi" id="2olOl3C6rqP" role="3uHU7B">
                    <node concept="2GrUjf" id="2olOl3C6ri1" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="2olOl3C5FHy" resolve="e" />
                    </node>
                    <node concept="3TrcHB" id="2olOl3C6yoT" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:AQqjC1K8Nq" resolve="dataConservation" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2U9My3wpXjv" role="lcghm">
                <property role="lacIc" value="'," />
              </node>
              <node concept="l9hG8" id="2U9My3wpXqp" role="lcghm">
                <node concept="37vLTw" id="2U9My3wq2sX" role="lb14g">
                  <ref role="3cqZAo" node="2U9My3wq0SL" resolve="p" />
                </node>
              </node>
              <node concept="la8eA" id="40NILoOZndy" role="lcghm">
                <property role="lacIc" value=",'" />
              </node>
              <node concept="l9hG8" id="40NILoOZnfu" role="lcghm">
                <node concept="3cpWs3" id="3casRoZA3sr" role="lb14g">
                  <node concept="Xl_RD" id="3casRoZA3sv" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="40NILoP0Ua4" role="3uHU7B">
                    <node concept="2OqwBi" id="40NILoOZnre" role="2Oq$k0">
                      <node concept="2GrUjf" id="40NILoOZngR" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2olOl3C5FHy" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="40NILoOZo3h" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:68$ZZoCzNiB" resolve="personalDataCategory" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="3casRoZA2$K" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:68$ZZoCzNiA" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2U9My3wpXCt" role="lcghm">
                <property role="lacIc" value="');" />
              </node>
              <node concept="l8MVK" id="2olOl3C66Oz" role="lcghm" />
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="2olOl3C5FDE" role="3cqZAp" />
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="2olOl3C8zGS">
    <ref role="WuzLi" to="20wa:2olOl3C6SBB" resolve="NonPersonalDataAnnotation" />
    <node concept="29tfMY" id="2olOl3C8$bp" role="29tGrW">
      <node concept="3clFbS" id="2olOl3C8$bq" role="2VODD2">
        <node concept="3clFbF" id="2olOl3C8$bL" role="3cqZAp">
          <node concept="Xl_RD" id="2olOl3C8$bK" role="3clFbG">
            <property role="Xl_RC" value="NonPersonalDataAnnotation" />
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="2olOl3C8$eh" role="33IsuW">
      <node concept="3clFbS" id="2olOl3C8$ei" role="2VODD2">
        <node concept="3clFbF" id="2olOl3C8$eJ" role="3cqZAp">
          <node concept="Xl_RD" id="2olOl3C8$eI" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="2olOl3C8$hu" role="11c4hB">
      <node concept="3clFbS" id="2olOl3C8$hv" role="2VODD2">
        <node concept="2Gpval" id="2olOl3C8$mx" role="3cqZAp">
          <node concept="2GrKxI" id="2olOl3C8$my" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="2olOl3C8$mz" role="2GsD0m">
            <node concept="117lpO" id="2olOl3C8$m$" role="2Oq$k0" />
            <node concept="3Tsc0h" id="2olOl3C8$m_" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:2olOl3C6SBC" resolve="nonPersonalData" />
            </node>
          </node>
          <node concept="3clFbS" id="2olOl3C8$mA" role="2LFqv$">
            <node concept="lc7rE" id="2olOl3C8$mB" role="3cqZAp">
              <node concept="la8eA" id="2olOl3C8$mC" role="lcghm">
                <property role="lacIc" value="insert into gdpr_data(dataID, dataTypeName, isPersonal) values (" />
              </node>
              <node concept="l9hG8" id="1PjvIwH_uh5" role="lcghm">
                <node concept="3cpWs3" id="1PjvIwH_vCj" role="lb14g">
                  <node concept="Xl_RD" id="1PjvIwH_vCn" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="1PjvIwH_ur1" role="3uHU7B">
                    <node concept="2GrUjf" id="1PjvIwH_ui6" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="2olOl3C8$my" resolve="e" />
                    </node>
                    <node concept="3TrcHB" id="1PjvIwH_uKp" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="1PjvIwH_ufW" role="lcghm">
                <property role="lacIc" value=", '" />
              </node>
              <node concept="l9hG8" id="2olOl3C8$mI" role="lcghm">
                <node concept="2OqwBi" id="4BkqmtKeGuz" role="lb14g">
                  <node concept="2OqwBi" id="2olOl3C8$mJ" role="2Oq$k0">
                    <node concept="3TrEf2" id="1j2riNJDKi" role="2OqNvi">
                      <ref role="3Tt5mk" to="20wa:1j2riNJlah" resolve="dataType" />
                    </node>
                    <node concept="2GrUjf" id="2olOl3C8$mL" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="2olOl3C8$my" resolve="e" />
                    </node>
                  </node>
                  <node concept="3TrcHB" id="4BkqmtKeGHW" role="2OqNvi">
                    <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="9qZcQHYYEJ" role="lcghm">
                <property role="lacIc" value="', false" />
              </node>
              <node concept="la8eA" id="2olOl3C8$n1" role="lcghm">
                <property role="lacIc" value=");" />
              </node>
              <node concept="l8MVK" id="2olOl3C8$n2" role="lcghm" />
            </node>
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="3FQc_NktoHw">
    <ref role="WuzLi" to="20wa:3FQc_Nkm_Ey" resolve="DataTypeList" />
    <node concept="29tfMY" id="3FQc_NktoHx" role="29tGrW">
      <node concept="3clFbS" id="3FQc_NktoHy" role="2VODD2">
        <node concept="3clFbF" id="3FQc_NktoM6" role="3cqZAp">
          <node concept="Xl_RD" id="3FQc_Nktsju" role="3clFbG">
            <property role="Xl_RC" value="Data type" />
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="3FQc_Nktsq9" role="33IsuW">
      <node concept="3clFbS" id="3FQc_Nktsqa" role="2VODD2">
        <node concept="3clFbF" id="3FQc_Nktsr3" role="3cqZAp">
          <node concept="Xl_RD" id="3FQc_Nktsr2" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="3FQc_Nktsu2" role="11c4hB">
      <node concept="3clFbS" id="3FQc_Nktsu3" role="2VODD2">
        <node concept="2Gpval" id="3FQc_NktsUx" role="3cqZAp">
          <node concept="2GrKxI" id="3FQc_NktsUy" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="3FQc_NktsUz" role="2GsD0m">
            <node concept="117lpO" id="3FQc_NktsU$" role="2Oq$k0" />
            <node concept="3Tsc0h" id="3FQc_Nkttug" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:3FQc_Nkm_Ez" resolve="dataType" />
            </node>
          </node>
          <node concept="3clFbS" id="3FQc_NktsUA" role="2LFqv$">
            <node concept="lc7rE" id="3FQc_NktsUB" role="3cqZAp">
              <node concept="la8eA" id="3FQc_NktsUC" role="lcghm">
                <property role="lacIc" value="insert into gdpr_DataType(DataTypeName) values ('" />
              </node>
              <node concept="l9hG8" id="3FQc_NktsUD" role="lcghm">
                <node concept="2OqwBi" id="3FQc_NktsUE" role="lb14g">
                  <node concept="2GrUjf" id="3FQc_NktsUF" role="2Oq$k0">
                    <ref role="2Gs0qQ" node="3FQc_NktsUy" resolve="e" />
                  </node>
                  <node concept="3TrcHB" id="3FQc_Nktuvr" role="2OqNvi">
                    <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3FQc_Nku2PL" role="lcghm">
                <property role="lacIc" value="');" />
              </node>
              <node concept="l8MVK" id="3FQc_NktsV2" role="lcghm" />
            </node>
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="5Erw5yfcJJy">
    <ref role="WuzLi" to="20wa:51XxSBB9rbX" resolve="DataSubjectCategory" />
    <node concept="29tfMY" id="5Erw5yfcJJz" role="29tGrW">
      <node concept="3clFbS" id="5Erw5yfcJJ$" role="2VODD2">
        <node concept="3clFbF" id="5Erw5yfcJO8" role="3cqZAp">
          <node concept="3cpWs3" id="5Erw5yfcLk$" role="3clFbG">
            <node concept="Xl_RD" id="5Erw5yfcLlj" role="3uHU7w">
              <property role="Xl_RC" value="_Userstories" />
            </node>
            <node concept="2OqwBi" id="5Erw5yfcKsA" role="3uHU7B">
              <node concept="117lpO" id="5Erw5yfcKXw" role="2Oq$k0" />
              <node concept="3TrcHB" id="5Erw5yfcKDp" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="5Erw5yfcJUS" role="3cqZAp" />
      </node>
    </node>
    <node concept="9MYSb" id="5Erw5yfcLDs" role="33IsuW">
      <node concept="3clFbS" id="5Erw5yfcLDt" role="2VODD2">
        <node concept="3clFbF" id="5Erw5yfcLEB" role="3cqZAp">
          <node concept="Xl_RD" id="5Erw5yfcLEA" role="3clFbG">
            <property role="Xl_RC" value="txt" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="5Erw5yfcM9Q" role="11c4hB">
      <node concept="3clFbS" id="5Erw5yfcM9R" role="2VODD2">
        <node concept="lc7rE" id="9qZcQHWdOY" role="3cqZAp">
          <node concept="la8eA" id="9qZcQHWdZ2" role="lcghm">
            <property role="lacIc" value="                                                                           USER STORIES" />
          </node>
          <node concept="l8MVK" id="9qZcQHWFit" role="lcghm" />
          <node concept="l8MVK" id="9qZcQHX9f_" role="lcghm" />
        </node>
        <node concept="3SKdUt" id="9qZcQHTRm8" role="3cqZAp">
          <node concept="1PaTwC" id="9qZcQHTRm9" role="1aUNEU">
            <node concept="3oM_SD" id="9qZcQHTRow" role="1PaTwD">
              <property role="3oM_SC" value="ACCESS" />
            </node>
            <node concept="3oM_SD" id="9qZcQHTRoC" role="1PaTwD">
              <property role="3oM_SC" value="RIGHT" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="9qZcQHWdu$" role="3cqZAp">
          <node concept="la8eA" id="9qZcQHWdu_" role="lcghm">
            <property role="lacIc" value="-------------- ACCESS RIGHT --------------------" />
          </node>
          <node concept="l8MVK" id="9qZcQHWFoo" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5Erw5yfcMbp" role="3cqZAp">
          <node concept="la8eA" id="5Erw5yfcMbH" role="lcghm">
            <property role="lacIc" value="AS A " />
          </node>
          <node concept="l9hG8" id="5Erw5yfcMcL" role="lcghm">
            <node concept="2OqwBi" id="5Erw5yfcMlW" role="lb14g">
              <node concept="117lpO" id="5Erw5yfcMdC" role="2Oq$k0" />
              <node concept="3TrcHB" id="5Erw5yfcMMo" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
          <node concept="l8MVK" id="9qZcQHSVZW" role="lcghm" />
        </node>
        <node concept="lc7rE" id="9qZcQHSWai" role="3cqZAp">
          <node concept="la8eA" id="9qZcQHSWg3" role="lcghm">
            <property role="lacIc" value="I WANT to acces to all my personal data witch:  " />
          </node>
        </node>
        <node concept="2Gpval" id="5Erw5yfcRgo" role="3cqZAp">
          <node concept="2GrKxI" id="5Erw5yfcRgq" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="5Erw5yfefdL" role="2GsD0m">
            <node concept="2OqwBi" id="5Erw5yfcRs_" role="2Oq$k0">
              <node concept="117lpO" id="5Erw5yfcRkz" role="2Oq$k0" />
              <node concept="3TrEf2" id="5Erw5yfed6b" role="2OqNvi">
                <ref role="3Tt5mk" to="20wa:3FQc_NknC5N" resolve="personalData" />
              </node>
            </node>
            <node concept="2qgKlT" id="5Erw5yfefnT" role="2OqNvi">
              <ref role="37wK5l" to="oniz:5Erw5yfdx17" resolve="ReturnPersonalData" />
            </node>
          </node>
          <node concept="3clFbS" id="5Erw5yfcRgu" role="2LFqv$">
            <node concept="lc7rE" id="5Erw5yfcRvZ" role="3cqZAp">
              <node concept="l9hG8" id="5Erw5yfcT2T" role="lcghm">
                <node concept="2GrUjf" id="5Erw5yfefKP" role="lb14g">
                  <ref role="2Gs0qQ" node="5Erw5yfcRgq" resolve="e" />
                </node>
              </node>
              <node concept="la8eA" id="5Erw5yfefTF" role="lcghm">
                <property role="lacIc" value=",  " />
              </node>
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="9qZcQHTpNJ" role="3cqZAp">
          <node concept="la8eA" id="9qZcQHTTeE" role="lcghm">
            <property role="lacIc" value="." />
          </node>
          <node concept="l8MVK" id="9qZcQHTpQ8" role="lcghm" />
        </node>
        <node concept="lc7rE" id="9qZcQHSWzP" role="3cqZAp">
          <node concept="la8eA" id="9qZcQHSWAc" role="lcghm">
            <property role="lacIc" value="SO THAT exercise my right of access to personal data " />
          </node>
        </node>
        <node concept="3clFbH" id="9qZcQHTRoL" role="3cqZAp" />
        <node concept="lc7rE" id="9qZcQHTRLx" role="3cqZAp">
          <node concept="l8MVK" id="9qZcQHTRO_" role="lcghm" />
          <node concept="l8MVK" id="9qZcQHTRRP" role="lcghm" />
        </node>
        <node concept="3SKdUt" id="9qZcQHTRty" role="3cqZAp">
          <node concept="1PaTwC" id="9qZcQHTRtz" role="1aUNEU">
            <node concept="3oM_SD" id="9qZcQHTRvZ" role="1PaTwD">
              <property role="3oM_SC" value="RECTIFICATION" />
            </node>
            <node concept="3oM_SD" id="9qZcQHTRwe" role="1PaTwD">
              <property role="3oM_SC" value="RIGHT" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="9qZcQHWd9T" role="3cqZAp">
          <node concept="la8eA" id="9qZcQHWdeC" role="lcghm">
            <property role="lacIc" value="------------- RECTIFICATION RIGHT --------------" />
          </node>
          <node concept="l8MVK" id="9qZcQHWFuj" role="lcghm" />
        </node>
        <node concept="lc7rE" id="9qZcQHTRC6" role="3cqZAp">
          <node concept="la8eA" id="9qZcQHTRC7" role="lcghm">
            <property role="lacIc" value="AS A " />
          </node>
          <node concept="l9hG8" id="9qZcQHTRC8" role="lcghm">
            <node concept="2OqwBi" id="9qZcQHTRC9" role="lb14g">
              <node concept="117lpO" id="9qZcQHTRCa" role="2Oq$k0" />
              <node concept="3TrcHB" id="9qZcQHTRCb" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
          <node concept="l8MVK" id="9qZcQHTRCc" role="lcghm" />
        </node>
        <node concept="lc7rE" id="9qZcQHTRTu" role="3cqZAp">
          <node concept="la8eA" id="9qZcQHTRTv" role="lcghm">
            <property role="lacIc" value="I want to rectify any of my personal data " />
          </node>
          <node concept="l8MVK" id="40NILoP5ShR" role="lcghm" />
        </node>
        <node concept="lc7rE" id="40NILoP2U$7" role="3cqZAp">
          <node concept="l8MVK" id="40NILoP2UDn" role="lcghm" />
          <node concept="la8eA" id="40NILoP2UMm" role="lcghm">
            <property role="lacIc" value="    (" />
          </node>
        </node>
        <node concept="3cpWs8" id="40NILoP2mnj" role="3cqZAp">
          <node concept="3cpWsn" id="40NILoP2mnm" role="3cpWs9">
            <property role="TrG5h" value="i" />
            <node concept="10Oyi0" id="40NILoP2mnh" role="1tU5fm" />
            <node concept="3cmrfG" id="40NILoP2mt6" role="33vP2m">
              <property role="3cmrfH" value="1" />
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="9qZcQHTS7r" role="3cqZAp">
          <node concept="2GrKxI" id="9qZcQHTS7s" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="9qZcQHTS7t" role="2GsD0m">
            <node concept="2OqwBi" id="9qZcQHTS7u" role="2Oq$k0">
              <node concept="117lpO" id="9qZcQHTS7v" role="2Oq$k0" />
              <node concept="3TrEf2" id="9qZcQHTS7w" role="2OqNvi">
                <ref role="3Tt5mk" to="20wa:3FQc_NknC5N" resolve="personalData" />
              </node>
            </node>
            <node concept="2qgKlT" id="9qZcQHTS7x" role="2OqNvi">
              <ref role="37wK5l" to="oniz:5Erw5yfdx17" resolve="ReturnPersonalData" />
            </node>
          </node>
          <node concept="3clFbS" id="9qZcQHTS7y" role="2LFqv$">
            <node concept="lc7rE" id="9qZcQHTS7z" role="3cqZAp">
              <node concept="l9hG8" id="9qZcQHTS7$" role="lcghm">
                <node concept="2GrUjf" id="9qZcQHTS7_" role="lb14g">
                  <ref role="2Gs0qQ" node="9qZcQHTS7s" resolve="e" />
                </node>
              </node>
              <node concept="la8eA" id="9qZcQHTS7A" role="lcghm">
                <property role="lacIc" value=",  " />
              </node>
            </node>
            <node concept="3clFbF" id="40NILoP2mtF" role="3cqZAp">
              <node concept="37vLTI" id="40NILoP2n17" role="3clFbG">
                <node concept="3cpWs3" id="40NILoP2n1P" role="37vLTx">
                  <node concept="3cmrfG" id="40NILoP2n1T" role="3uHU7w">
                    <property role="3cmrfH" value="1" />
                  </node>
                  <node concept="37vLTw" id="40NILoP2n1w" role="3uHU7B">
                    <ref role="3cqZAo" node="40NILoP2mnm" resolve="i" />
                  </node>
                </node>
                <node concept="37vLTw" id="40NILoP2mtD" role="37vLTJ">
                  <ref role="3cqZAo" node="40NILoP2mnm" resolve="i" />
                </node>
              </node>
            </node>
            <node concept="3clFbJ" id="40NILoP2o58" role="3cqZAp">
              <node concept="3clFbS" id="40NILoP2o5a" role="3clFbx">
                <node concept="3clFbF" id="40NILoP2oDF" role="3cqZAp">
                  <node concept="37vLTI" id="40NILoP2oE5" role="3clFbG">
                    <node concept="3cmrfG" id="40NILoP2oEi" role="37vLTx">
                      <property role="3cmrfH" value="1" />
                    </node>
                    <node concept="37vLTw" id="40NILoP2oDD" role="37vLTJ">
                      <ref role="3cqZAo" node="40NILoP2mnm" resolve="i" />
                    </node>
                  </node>
                </node>
                <node concept="lc7rE" id="40NILoP2oNE" role="3cqZAp">
                  <node concept="l8MVK" id="40NILoP2oNY" role="lcghm" />
                  <node concept="la8eA" id="40NILoP3pcN" role="lcghm">
                    <property role="lacIc" value="     " />
                  </node>
                </node>
              </node>
              <node concept="3clFbC" id="40NILoP2oeu" role="3clFbw">
                <node concept="3cmrfG" id="40NILoP2oD8" role="3uHU7w">
                  <property role="3cmrfH" value="5" />
                </node>
                <node concept="37vLTw" id="40NILoP2o5w" role="3uHU7B">
                  <ref role="3cqZAo" node="40NILoP2mnm" resolve="i" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="9qZcQHTSft" role="3cqZAp">
          <node concept="la8eA" id="9qZcQHUOG_" role="lcghm">
            <property role="lacIc" value=")." />
          </node>
          <node concept="l8MVK" id="9qZcQHTSfu" role="lcghm" />
        </node>
        <node concept="lc7rE" id="9qZcQHTSfQ" role="3cqZAp">
          <node concept="la8eA" id="9qZcQHTSfR" role="lcghm">
            <property role="lacIc" value="SO THAT I exercise my right to rectify personal data " />
          </node>
        </node>
        <node concept="3clFbH" id="9qZcQHTRZ8" role="3cqZAp" />
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="3WaPWglg0GW">
    <ref role="WuzLi" to="20wa:3WaPWglfBNY" resolve="DataRequestAnswer" />
    <node concept="29tfMY" id="3WaPWglg1oX" role="29tGrW">
      <node concept="3clFbS" id="3WaPWglg1oY" role="2VODD2">
        <node concept="3clFbF" id="3WaPWglg1pm" role="3cqZAp">
          <node concept="3cpWs3" id="3WaPWglg2xE" role="3clFbG">
            <node concept="2OqwBi" id="3WaPWglg2KR" role="3uHU7w">
              <node concept="117lpO" id="3WaPWglg2yi" role="2Oq$k0" />
              <node concept="3TrcHB" id="3WaPWglg2S8" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:3WaPWglfBNZ" resolve="id" />
              </node>
            </node>
            <node concept="Xl_RD" id="3WaPWglg2i3" role="3uHU7B">
              <property role="Xl_RC" value="answer" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="3WaPWglg1L6" role="33IsuW">
      <node concept="3clFbS" id="3WaPWglg1L7" role="2VODD2">
        <node concept="3clFbF" id="3WaPWglg1M4" role="3cqZAp">
          <node concept="Xl_RD" id="3WaPWglg1M3" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="3WaPWglg1Oc" role="11c4hB">
      <node concept="3clFbS" id="3WaPWglg1Od" role="2VODD2">
        <node concept="3clFbH" id="3WaPWglkclH" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglg2j$" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg30z" role="lcghm">
            <property role="lacIc" value="insert into gdpr_DataRequestAnswer(dataRequestAnswerid, answer, justification, datarequest) values (" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglg4yj" role="3cqZAp">
          <node concept="l9hG8" id="1PjvIwH_7Uc" role="lcghm">
            <node concept="3cpWs3" id="1PjvIwH_8Zq" role="lb14g">
              <node concept="Xl_RD" id="1PjvIwH_8Zu" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="1PjvIwH_8aI" role="3uHU7B">
                <node concept="117lpO" id="1PjvIwH_841" role="2Oq$k0" />
                <node concept="3TrcHB" id="1PjvIwH_8ik" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglfBNZ" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="1PjvIwH_9U9" role="lcghm">
            <property role="lacIc" value=", " />
          </node>
          <node concept="l9hG8" id="3WaPWglg4ze" role="lcghm">
            <node concept="3cpWs3" id="3WaPWglg5aQ" role="lb14g">
              <node concept="Xl_RD" id="3WaPWglg5aU" role="3uHU7w" />
              <node concept="2OqwBi" id="3WaPWglg4EK" role="3uHU7B">
                <node concept="117lpO" id="3WaPWglg4$3" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWglg4Mn" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglfBO1" resolve="answer" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglg5mm" role="lcghm">
            <property role="lacIc" value=", '" />
          </node>
          <node concept="l9hG8" id="3WaPWglg5oZ" role="lcghm">
            <node concept="2OqwBi" id="3WaPWglg5xe" role="lb14g">
              <node concept="117lpO" id="3WaPWglg5qx" role="2Oq$k0" />
              <node concept="3TrcHB" id="3WaPWglg5CP" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:3WaPWglfBO6" resolve="proof" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglg5HR" role="lcghm">
            <property role="lacIc" value="', " />
          </node>
          <node concept="l9hG8" id="3WaPWglg5KU" role="lcghm">
            <node concept="3cpWs3" id="3WaPWglg7nk" role="lb14g">
              <node concept="2OqwBi" id="3WaPWglg6k7" role="3uHU7B">
                <node concept="2OqwBi" id="3WaPWglg62u" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWglg5VL" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWglg6a5" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                  </node>
                </node>
                <node concept="3TrcHB" id="3WaPWglg6uS" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:7bfLM_U99lL" resolve="id" />
                </node>
              </node>
              <node concept="Xl_RD" id="3WaPWglg7zD" role="3uHU7w" />
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglg$$s" role="lcghm">
            <property role="lacIc" value=");" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglhuLN" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglhvwK" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglkdMR" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWglkcXD" role="3cqZAp" />
        <node concept="3clFbJ" id="3WaPWglg1Py" role="3cqZAp">
          <node concept="2OqwBi" id="3WaPWglg1Xc" role="3clFbw">
            <node concept="117lpO" id="3WaPWglg1PW" role="2Oq$k0" />
            <node concept="3TrcHB" id="3WaPWglg24g" role="2OqNvi">
              <ref role="3TsBF5" to="20wa:3WaPWglfBO1" resolve="answer" />
            </node>
          </node>
          <node concept="3clFbS" id="3WaPWglg1P$" role="3clFbx">
            <node concept="3clFbJ" id="3WaPWglgZpn" role="3cqZAp">
              <node concept="3clFbS" id="3WaPWglgZpp" role="3clFbx">
                <node concept="3clFbH" id="3WaPWgliQyx" role="3cqZAp" />
                <node concept="lc7rE" id="3WaPWglijAI" role="3cqZAp">
                  <node concept="la8eA" id="3WaPWglijCU" role="lcghm">
                    <property role="lacIc" value="update " />
                  </node>
                  <node concept="l9hG8" id="3WaPWglijDL" role="lcghm">
                    <node concept="2OqwBi" id="7jdn5R6mRFt" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWgliRJ7" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWgliRj_" role="2Oq$k0">
                          <node concept="2OqwBi" id="3WaPWglijLm" role="2Oq$k0">
                            <node concept="117lpO" id="3WaPWglijED" role="2Oq$k0" />
                            <node concept="3TrEf2" id="3WaPWglijSX" role="2OqNvi">
                              <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                            </node>
                          </node>
                          <node concept="3TrEf2" id="3WaPWgliRwK" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="1j2riNJziX" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:1j2riNJlah" resolve="dataType" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="7jdn5R6mRQF" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglil$Z" role="lcghm">
                    <property role="lacIc" value=" set " />
                  </node>
                </node>
                <node concept="lc7rE" id="3WaPWglilF$" role="3cqZAp">
                  <node concept="l9hG8" id="3WaPWglilIw" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglimFz" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglimhO" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglilQ4" role="2Oq$k0">
                          <node concept="117lpO" id="3WaPWglilJn" role="2Oq$k0" />
                          <node concept="3TrEf2" id="3WaPWglim7M" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglimtc" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglimUY" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglimZa" role="lcghm">
                    <property role="lacIc" value="=&quot;" />
                  </node>
                  <node concept="l9hG8" id="3WaPWglin7Z" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglinxK" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglinh9" role="2Oq$k0">
                        <node concept="117lpO" id="3WaPWglin9u" role="2Oq$k0" />
                        <node concept="3TrEf2" id="3WaPWglinoK" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglinH8" role="2OqNvi">
                        <ref role="3TsBF5" to="20wa:424h5AVf9rI" resolve="newValue" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglio03" role="lcghm">
                    <property role="lacIc" value="&quot; " />
                  </node>
                </node>
                <node concept="lc7rE" id="3WaPWgliogq" role="3cqZAp">
                  <node concept="la8eA" id="3WaPWgliokx" role="lcghm">
                    <property role="lacIc" value="where " />
                  </node>
                  <node concept="l9hG8" id="3WaPWgliolQ" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglipIT" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglipe6" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglioI2" role="2Oq$k0">
                          <node concept="2OqwBi" id="3WaPWgliotr" role="2Oq$k0">
                            <node concept="117lpO" id="3WaPWgliomI" role="2Oq$k0" />
                            <node concept="3TrEf2" id="3WaPWglio_2" role="2OqNvi">
                              <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                            </node>
                          </node>
                          <node concept="3TrEf2" id="3WaPWglioTq" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglipxF" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglipU8" role="2OqNvi">
                        <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglipY0" role="lcghm">
                    <property role="lacIc" value=" in (select " />
                  </node>
                  <node concept="l9hG8" id="3WaPWgliq9i" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglirqn" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWgliqUb" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWgliqzH" role="2Oq$k0">
                          <node concept="2OqwBi" id="3WaPWgliqiz" role="2Oq$k0">
                            <node concept="117lpO" id="3WaPWgliqaS" role="2Oq$k0" />
                            <node concept="3TrEf2" id="3WaPWgliqqH" role="2OqNvi">
                              <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                            </node>
                          </node>
                          <node concept="3TrEf2" id="3WaPWgliqJ5" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglirdK" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglirAd" role="2OqNvi">
                        <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglitzT" role="lcghm">
                    <property role="lacIc" value=" from gdpr_datasubject as D where username='" />
                  </node>
                  <node concept="l9hG8" id="3WaPWglis55" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglit78" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglisvh" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglise7" role="2Oq$k0">
                          <node concept="117lpO" id="3WaPWglis7q" role="2Oq$k0" />
                          <node concept="3TrEf2" id="3WaPWglismh" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglisE2" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglitq6" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWgljdwC" role="lcghm">
                    <property role="lacIc" value="');" />
                  </node>
                </node>
              </node>
              <node concept="3clFbC" id="3WaPWglh0JT" role="3clFbw">
                <node concept="Xl_RD" id="3WaPWglh0TI" role="3uHU7w">
                  <property role="Xl_RC" value="rectification" />
                </node>
                <node concept="2OqwBi" id="3WaPWglhSFb" role="3uHU7B">
                  <node concept="2OqwBi" id="3WaPWglgZRa" role="2Oq$k0">
                    <node concept="2OqwBi" id="3WaPWglgZyZ" role="2Oq$k0">
                      <node concept="117lpO" id="3WaPWglgZrJ" role="2Oq$k0" />
                      <node concept="3TrEf2" id="3WaPWglgZE3" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="3WaPWglh03b" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:51XxSBB6uyX" resolve="type" />
                    </node>
                  </node>
                  <node concept="liA8E" id="3WaPWglhSPb" role="2OqNvi">
                    <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
                  </node>
                </node>
              </node>
            </node>
            <node concept="3clFbJ" id="3WaPWglkfux" role="3cqZAp">
              <node concept="3clFbS" id="3WaPWglkfuz" role="3clFbx">
                <node concept="lc7rE" id="3WaPWglkgWE" role="3cqZAp">
                  <node concept="la8eA" id="3WaPWglkgWF" role="lcghm">
                    <property role="lacIc" value="update " />
                  </node>
                  <node concept="l9hG8" id="3WaPWglkgWG" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglkgWH" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglkgWI" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglkgWJ" role="2Oq$k0">
                          <node concept="117lpO" id="3WaPWglkgWK" role="2Oq$k0" />
                          <node concept="3TrEf2" id="3WaPWglkgWL" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglkgWM" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                        </node>
                      </node>
                      <node concept="3TrEf2" id="1j2riNJzsN" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:1j2riNJlah" resolve="dataType" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglkgWO" role="lcghm">
                    <property role="lacIc" value=" set ( " />
                  </node>
                </node>
                <node concept="lc7rE" id="3WaPWglkgWP" role="3cqZAp">
                  <node concept="l9hG8" id="3WaPWglkgWQ" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglkgWR" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglkgWS" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglkgWT" role="2Oq$k0">
                          <node concept="117lpO" id="3WaPWglkgWU" role="2Oq$k0" />
                          <node concept="3TrEf2" id="3WaPWglkgWV" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglkgWW" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglkgWX" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglkgWY" role="lcghm">
                    <property role="lacIc" value="= null)" />
                  </node>
                </node>
                <node concept="lc7rE" id="3WaPWglkgX6" role="3cqZAp">
                  <node concept="la8eA" id="3WaPWglkgX7" role="lcghm">
                    <property role="lacIc" value="where " />
                  </node>
                  <node concept="l9hG8" id="3WaPWglkgX8" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglkgX9" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglkgXa" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglkgXb" role="2Oq$k0">
                          <node concept="2OqwBi" id="3WaPWglkgXc" role="2Oq$k0">
                            <node concept="117lpO" id="3WaPWglkgXd" role="2Oq$k0" />
                            <node concept="3TrEf2" id="3WaPWglkgXe" role="2OqNvi">
                              <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                            </node>
                          </node>
                          <node concept="3TrEf2" id="3WaPWglkgXf" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglkgXg" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglkgXh" role="2OqNvi">
                        <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglkgXi" role="lcghm">
                    <property role="lacIc" value="= select " />
                  </node>
                  <node concept="l9hG8" id="3WaPWglkgXj" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglkgXk" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglkgXl" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglkgXm" role="2Oq$k0">
                          <node concept="2OqwBi" id="3WaPWglkgXn" role="2Oq$k0">
                            <node concept="117lpO" id="3WaPWglkgXo" role="2Oq$k0" />
                            <node concept="3TrEf2" id="3WaPWglkgXp" role="2OqNvi">
                              <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                            </node>
                          </node>
                          <node concept="3TrEf2" id="3WaPWglkgXq" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglkgXr" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglkgXs" role="2OqNvi">
                        <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglkgXt" role="lcghm">
                    <property role="lacIc" value=" from gdpr_datasubject where username='" />
                  </node>
                  <node concept="l9hG8" id="3WaPWglkgXu" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglkgXv" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglkgXw" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglkgXx" role="2Oq$k0">
                          <node concept="117lpO" id="3WaPWglkgXy" role="2Oq$k0" />
                          <node concept="3TrEf2" id="3WaPWglkgXz" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglkgX$" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglkgX_" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglkgXA" role="lcghm">
                    <property role="lacIc" value="';" />
                  </node>
                </node>
                <node concept="3clFbH" id="3WaPWglkfuy" role="3cqZAp" />
                <node concept="3clFbH" id="3WaPWglkgWq" role="3cqZAp" />
              </node>
              <node concept="3clFbC" id="3WaPWglkgHq" role="3clFbw">
                <node concept="Xl_RD" id="3WaPWglkgRf" role="3uHU7w">
                  <property role="Xl_RC" value="erase" />
                </node>
                <node concept="2OqwBi" id="3WaPWglkgii" role="3uHU7B">
                  <node concept="2OqwBi" id="3WaPWglkfVq" role="2Oq$k0">
                    <node concept="2OqwBi" id="3WaPWglkfF2" role="2Oq$k0">
                      <node concept="117lpO" id="3WaPWglkfzM" role="2Oq$k0" />
                      <node concept="3TrEf2" id="3WaPWglkfMC" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="3WaPWglkg81" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:51XxSBB6uyX" resolve="type" />
                    </node>
                  </node>
                  <node concept="liA8E" id="3WaPWglkgqH" role="2OqNvi">
                    <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
                  </node>
                </node>
              </node>
            </node>
            <node concept="3clFbH" id="3WaPWglkfps" role="3cqZAp" />
          </node>
        </node>
        <node concept="3clFbH" id="3WaPWgljKvc" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWgljKxa" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWgljKz9" role="3cqZAp" />
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="3WaPWgldDDm">
    <ref role="WuzLi" to="20wa:424h5AVf9rD" resolve="DataRequest" />
    <node concept="29tfMY" id="3WaPWgldDRQ" role="29tGrW">
      <node concept="3clFbS" id="3WaPWgldDRR" role="2VODD2">
        <node concept="3clFbF" id="3WaPWgldDWr" role="3cqZAp">
          <node concept="3cpWs3" id="3WaPWgldWzy" role="3clFbG">
            <node concept="3cpWs3" id="3WaPWgldY5G" role="3uHU7B">
              <node concept="2OqwBi" id="3WaPWgldYg3" role="3uHU7B">
                <node concept="117lpO" id="3WaPWgldY6S" role="2Oq$k0" />
                <node concept="3TrEf2" id="3WaPWgldYpa" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                </node>
              </node>
              <node concept="2OqwBi" id="3WaPWgldZMI" role="3uHU7w">
                <node concept="2OqwBi" id="3WaPWgldEf6" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWgldDWq" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWgldWi6" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                  </node>
                </node>
                <node concept="3TrcHB" id="3WaPWgle024" role="2OqNvi">
                  <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                </node>
              </node>
            </node>
            <node concept="2OqwBi" id="3WaPWgldXg$" role="3uHU7w">
              <node concept="2OqwBi" id="3WaPWgldWZm" role="2Oq$k0">
                <node concept="117lpO" id="3WaPWgldWKo" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWgldX83" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:51XxSBB6uyX" resolve="type" />
                </node>
              </node>
              <node concept="liA8E" id="3WaPWgldXo4" role="2OqNvi">
                <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
              </node>
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="3WaPWgldEGU" role="33IsuW">
      <node concept="3clFbS" id="3WaPWgldEGV" role="2VODD2">
        <node concept="3clFbF" id="3WaPWgldEO4" role="3cqZAp">
          <node concept="Xl_RD" id="3WaPWgldEO3" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="3WaPWgldEPa" role="11c4hB">
      <node concept="3clFbS" id="3WaPWgldEPb" role="2VODD2">
        <node concept="3clFbH" id="3WaPWgldP8K" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWgldF5q" role="3cqZAp">
          <node concept="la8eA" id="3WaPWgldF5I" role="lcghm">
            <property role="lacIc" value="insert into gdpr_datarequest (DataRequestID, claim, newValue, datareqType, datasubject, data) values(" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWgldJ8R" role="3cqZAp">
          <node concept="l9hG8" id="1PjvIwH_2_V" role="lcghm">
            <node concept="3cpWs3" id="1PjvIwH_57a" role="lb14g">
              <node concept="Xl_RD" id="1PjvIwH_57e" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="1PjvIwH_2L9" role="3uHU7B">
                <node concept="117lpO" id="1PjvIwH_2DU" role="2Oq$k0" />
                <node concept="3TrcHB" id="1PjvIwH_2U5" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:7bfLM_U99lL" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="1PjvIwH_5Ud" role="lcghm">
            <property role="lacIc" value=", '" />
          </node>
          <node concept="l9hG8" id="3WaPWgldJYl" role="lcghm">
            <node concept="2OqwBi" id="3WaPWgldK9s" role="lb14g">
              <node concept="117lpO" id="3WaPWgldK25" role="2Oq$k0" />
              <node concept="3TrcHB" id="3WaPWgldKio" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:424h5AVf9rk" resolve="claim" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgldKlJ" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWgldL4T" role="lcghm">
            <node concept="2OqwBi" id="3WaPWgldLeV" role="lb14g">
              <node concept="117lpO" id="3WaPWgldL6B" role="2Oq$k0" />
              <node concept="3TrcHB" id="3WaPWgldLnR" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:424h5AVf9rI" resolve="newValue" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgldL$O" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWgldLCH" role="lcghm">
            <node concept="2OqwBi" id="3WaPWgldPAq" role="lb14g">
              <node concept="2OqwBi" id="3WaPWgldLMe" role="2Oq$k0">
                <node concept="117lpO" id="3WaPWgldLER" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWgldLVa" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:51XxSBB6uyX" resolve="type" />
                </node>
              </node>
              <node concept="liA8E" id="3WaPWgldPK9" role="2OqNvi">
                <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgldMdZ" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWgldMix" role="lcghm">
            <node concept="3cpWs3" id="2NO6V5fSoHX" role="lb14g">
              <node concept="Xl_RD" id="2NO6V5fSoI1" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="3WaPWgleL3c" role="3uHU7B">
                <node concept="2OqwBi" id="3WaPWgldM_0" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWgldMtD" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWgldMHW" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                  </node>
                </node>
                <node concept="3TrcHB" id="2NO6V5fSo0J" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgldN6x" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWgldNcp" role="lcghm">
            <node concept="3cpWs3" id="3WaPWgln8wp" role="lb14g">
              <node concept="Xl_RD" id="3WaPWgln8wt" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="3WaPWgleLvs" role="3uHU7B">
                <node concept="2OqwBi" id="3WaPWgldNiG" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWgldNfr" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWgldNsY" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                  </node>
                </node>
                <node concept="3TrcHB" id="3WaPWgln7nd" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgldNOw" role="lcghm">
            <property role="lacIc" value="');" />
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="68$ZZoCA2GX">
    <ref role="WuzLi" to="20wa:68$ZZoCzNiC" resolve="ListPersonalDataCat" />
    <node concept="11bSqf" id="68$ZZoCA2GY" role="11c4hB">
      <node concept="3clFbS" id="68$ZZoCA2GZ" role="2VODD2">
        <node concept="2Gpval" id="68$ZZoCA2Hg" role="3cqZAp">
          <node concept="2GrKxI" id="68$ZZoCA2Hh" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="68$ZZoCA2Hi" role="2GsD0m">
            <node concept="117lpO" id="68$ZZoCA2Hj" role="2Oq$k0" />
            <node concept="3Tsc0h" id="68$ZZoCA3Jp" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:68$ZZoCzNiD" resolve="personalDataCategory" />
            </node>
          </node>
          <node concept="3clFbS" id="68$ZZoCA2Hl" role="2LFqv$">
            <node concept="lc7rE" id="68$ZZoCA2Hm" role="3cqZAp">
              <node concept="la8eA" id="68$ZZoCA2Hn" role="lcghm">
                <property role="lacIc" value="insert into gdpr_PersonalDataCategory(PDCategoryID, personalDataCategory) values (" />
              </node>
              <node concept="l9hG8" id="68$ZZoCA2Ho" role="lcghm">
                <node concept="3cpWs3" id="68$ZZoCAh$W" role="lb14g">
                  <node concept="Xl_RD" id="68$ZZoCAh_0" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="68$ZZoCA2Hp" role="3uHU7B">
                    <node concept="2GrUjf" id="68$ZZoCA2Hq" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="68$ZZoCA2Hh" resolve="e" />
                    </node>
                    <node concept="3TrcHB" id="68$ZZoCAaXv" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:68$ZZoCzNiA" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="68$ZZoCA2Hs" role="lcghm">
                <property role="lacIc" value=", '" />
              </node>
              <node concept="l9hG8" id="68$ZZoCA2Ht" role="lcghm">
                <node concept="2OqwBi" id="68$ZZoCA2Hv" role="lb14g">
                  <node concept="2GrUjf" id="68$ZZoCA2Hx" role="2Oq$k0">
                    <ref role="2Gs0qQ" node="68$ZZoCA2Hh" resolve="e" />
                  </node>
                  <node concept="3TrcHB" id="68$ZZoCAbnc" role="2OqNvi">
                    <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="68$ZZoCA2Hz" role="lcghm">
                <property role="lacIc" value="');" />
              </node>
              <node concept="l8MVK" id="68$ZZoCA2HP" role="lcghm" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="29tfMY" id="68$ZZoCA4zN" role="29tGrW">
      <node concept="3clFbS" id="68$ZZoCA4zO" role="2VODD2">
        <node concept="3clFbF" id="68$ZZoCA4ER" role="3cqZAp">
          <node concept="Xl_RD" id="68$ZZoCA4EQ" role="3clFbG">
            <property role="Xl_RC" value="Definition of personal data categories" />
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="68$ZZoCA4KY" role="33IsuW">
      <node concept="3clFbS" id="68$ZZoCA4KZ" role="2VODD2">
        <node concept="3clFbF" id="68$ZZoCA5k6" role="3cqZAp">
          <node concept="Xl_RD" id="68$ZZoCA5k5" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
  </node>
</model>

