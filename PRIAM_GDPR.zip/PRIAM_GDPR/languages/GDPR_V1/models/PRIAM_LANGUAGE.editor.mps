<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:27113111-9033-4ab9-ab13-8459229ac46b(PRIAM_LANGUAGE.editor)">
  <persistence version="9" />
  <languages>
    <use id="18bc6592-03a6-4e29-a83a-7ff23bde13ba" name="jetbrains.mps.lang.editor" version="14" />
    <use id="aee9cad2-acd4-4608-aef2-0004f6a1cdbd" name="jetbrains.mps.lang.actions" version="4" />
    <use id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core" version="2" />
    <use id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage" version="11" />
    <devkit ref="fbc25dd2-5da4-483a-8b19-70928e1b62d7(jetbrains.mps.devkit.general-purpose)" />
  </languages>
  <imports>
    <import index="20wa" ref="r:515d5f51-79c9-42c9-bba4-54c97b772d5b(PRIAM_LANGUAGE.structure)" implicit="true" />
    <import index="tpck" ref="r:00000000-0000-4000-0000-011c89590288(jetbrains.mps.lang.core.structure)" implicit="true" />
    <import index="tpen" ref="r:00000000-0000-4000-0000-011c895902c3(jetbrains.mps.baseLanguage.editor)" implicit="true" />
  </imports>
  <registry>
    <language id="18bc6592-03a6-4e29-a83a-7ff23bde13ba" name="jetbrains.mps.lang.editor">
      <concept id="1071666914219" name="jetbrains.mps.lang.editor.structure.ConceptEditorDeclaration" flags="ig" index="24kQdi" />
      <concept id="1140524381322" name="jetbrains.mps.lang.editor.structure.CellModel_ListWithRole" flags="ng" index="2czfm3">
        <child id="1140524464360" name="cellLayout" index="2czzBx" />
      </concept>
      <concept id="1237303669825" name="jetbrains.mps.lang.editor.structure.CellLayout_Indent" flags="nn" index="l2Vlx" />
      <concept id="1237307900041" name="jetbrains.mps.lang.editor.structure.IndentLayoutIndentStyleClassItem" flags="ln" index="lj46D" />
      <concept id="1237308012275" name="jetbrains.mps.lang.editor.structure.IndentLayoutNewLineStyleClassItem" flags="ln" index="ljvvj" />
      <concept id="1237385578942" name="jetbrains.mps.lang.editor.structure.IndentLayoutOnNewLineStyleClassItem" flags="ln" index="pVoyu" />
      <concept id="1080736578640" name="jetbrains.mps.lang.editor.structure.BaseEditorComponent" flags="ig" index="2wURMF">
        <child id="1080736633877" name="cellModel" index="2wV5jI" />
      </concept>
      <concept id="6718020819487620876" name="jetbrains.mps.lang.editor.structure.TransformationMenuReference_Default" flags="ng" index="A1WHr" />
      <concept id="1186403694788" name="jetbrains.mps.lang.editor.structure.ColorStyleClassItem" flags="ln" index="VaVBg">
        <property id="1186403713874" name="color" index="Vb096" />
        <child id="1186403803051" name="query" index="VblUZ" />
      </concept>
      <concept id="1186404549998" name="jetbrains.mps.lang.editor.structure.ForegroundColorStyleClassItem" flags="ln" index="VechU" />
      <concept id="1186414536763" name="jetbrains.mps.lang.editor.structure.BooleanStyleSheetItem" flags="ln" index="VOi$J">
        <property id="1186414551515" name="flag" index="VOm3f" />
      </concept>
      <concept id="1186415722038" name="jetbrains.mps.lang.editor.structure.FontSizeStyleClassItem" flags="ln" index="VSNWy">
        <property id="1221209241505" name="value" index="1lJzqX" />
      </concept>
      <concept id="1630016958697718209" name="jetbrains.mps.lang.editor.structure.IMenuReference_Default" flags="ng" index="2Z_bC8">
        <reference id="1630016958698373342" name="concept" index="2ZyFGn" />
      </concept>
      <concept id="8313721352726366579" name="jetbrains.mps.lang.editor.structure.CellModel_Empty" flags="ng" index="35HoNQ" />
      <concept id="1088013125922" name="jetbrains.mps.lang.editor.structure.CellModel_RefCell" flags="sg" stub="730538219795941030" index="1iCGBv">
        <child id="1088186146602" name="editorComponent" index="1sWHZn" />
      </concept>
      <concept id="1225456267680" name="jetbrains.mps.lang.editor.structure.RGBColor" flags="ng" index="1iSF2X">
        <property id="1225456424731" name="value" index="1iTho6" />
      </concept>
      <concept id="1381004262292414836" name="jetbrains.mps.lang.editor.structure.ICellStyle" flags="ng" index="1k5N5V">
        <reference id="1381004262292426837" name="parentStyleClass" index="1k5W1q" />
      </concept>
      <concept id="1088185857835" name="jetbrains.mps.lang.editor.structure.InlineEditorComponent" flags="ig" index="1sVBvm" />
      <concept id="1139848536355" name="jetbrains.mps.lang.editor.structure.CellModel_WithRole" flags="ng" index="1$h60E">
        <property id="1140017977771" name="readOnly" index="1Intyy" />
        <reference id="1140103550593" name="relationDeclaration" index="1NtTu8" />
      </concept>
      <concept id="1073389214265" name="jetbrains.mps.lang.editor.structure.EditorCellModel" flags="ng" index="3EYTF0">
        <child id="4202667662392416064" name="transformationMenu" index="3vIgyS" />
      </concept>
      <concept id="1073389446423" name="jetbrains.mps.lang.editor.structure.CellModel_Collection" flags="sn" stub="3013115976261988961" index="3EZMnI">
        <child id="1106270802874" name="cellLayout" index="2iSdaV" />
        <child id="1073389446424" name="childCellModel" index="3EZMnx" />
      </concept>
      <concept id="1073389577006" name="jetbrains.mps.lang.editor.structure.CellModel_Constant" flags="sn" stub="3610246225209162225" index="3F0ifn">
        <property id="1073389577007" name="text" index="3F0ifm" />
      </concept>
      <concept id="1073389658414" name="jetbrains.mps.lang.editor.structure.CellModel_Property" flags="sg" stub="730538219796134133" index="3F0A7n" />
      <concept id="1219418625346" name="jetbrains.mps.lang.editor.structure.IStyleContainer" flags="ng" index="3F0Thp">
        <child id="1219418656006" name="styleItem" index="3F10Kt" />
      </concept>
      <concept id="1073389882823" name="jetbrains.mps.lang.editor.structure.CellModel_RefNode" flags="sg" stub="730538219795960754" index="3F1sOY" />
      <concept id="1073390211982" name="jetbrains.mps.lang.editor.structure.CellModel_RefNodeList" flags="sg" stub="2794558372793454595" index="3F2HdR" />
      <concept id="1166049232041" name="jetbrains.mps.lang.editor.structure.AbstractComponent" flags="ng" index="1XWOmA">
        <reference id="1166049300910" name="conceptDeclaration" index="1XX52x" />
      </concept>
    </language>
  </registry>
  <node concept="24kQdi" id="2ry5VKd1fov">
    <ref role="1XX52x" to="20wa:2ry5VKd0csX" resolve="ProcessingRef" />
    <node concept="3EZMnI" id="2ry5VKd1fox" role="2wV5jI">
      <node concept="1iCGBv" id="51XxSBB6uyl" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:2ry5VKd0yKm" resolve="processing" />
        <node concept="1sVBvm" id="51XxSBB6uyn" role="1sWHZn">
          <node concept="3F0A7n" id="51XxSBB6uyx" role="2wV5jI">
            <property role="1Intyy" value="true" />
            <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
          </node>
        </node>
      </node>
      <node concept="3F0ifn" id="5Drs5VZFU$C" role="3EZMnx">
        <property role="3F0ifm" value="     Consented" />
        <node concept="VechU" id="51XxSBB5lQv" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
      </node>
      <node concept="l2Vlx" id="2ry5VKd1fo$" role="2iSdaV" />
      <node concept="3F0A7n" id="5Drs5VZGaZw" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5Drs5VZG6Fq" resolve="consented" />
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="2ry5VKcWYxP">
    <ref role="1XX52x" to="20wa:5VnHNHVgh8l" resolve="Consent" />
    <node concept="3EZMnI" id="2ry5VKcWYxR" role="2wV5jI">
      <node concept="3F0ifn" id="2ry5VKcWYxY" role="3EZMnx">
        <property role="3F0ifm" value="Consent     " />
        <node concept="pVoyu" id="2ry5VKcXLq$" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="2ry5VKcY6Go" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="pVoyu" id="2ry5VKcYsXH" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="VechU" id="51XxSBB2OHC" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
      </node>
      <node concept="l2Vlx" id="2ry5VKcWYxU" role="2iSdaV" />
      <node concept="3F0ifn" id="51XxSBB3Hws" role="3EZMnx">
        <property role="3F0ifm" value="Processing" />
      </node>
      <node concept="3F1sOY" id="51XxSBB5U6x" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgh95" resolve="processing" />
        <node concept="VechU" id="2gZmXhnG6mO" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="2ry5VKcWYy4" role="3EZMnx">
        <property role="3F0ifm" value="Start date:" />
      </node>
      <node concept="3F0A7n" id="2ry5VKcWYyc" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgh9$" resolve="startDate" />
        <node concept="VechU" id="51XxSBB2OHI" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="2ry5VKcWYyu" role="3EZMnx">
        <property role="3F0ifm" value="End Date" />
      </node>
      <node concept="3F0A7n" id="2ry5VKcWYyE" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgh9A" resolve="endDate" />
        <node concept="VechU" id="51XxSBB2OHK" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="2ry5VKcXVyv">
    <ref role="1XX52x" to="20wa:5VnHNHVg8Bi" resolve="Contract" />
    <node concept="3EZMnI" id="2ry5VKcXVyx" role="2wV5jI">
      <node concept="3F0ifn" id="2ry5VKcXVyC" role="3EZMnx">
        <property role="3F0ifm" value="Contract number   " />
        <node concept="VechU" id="51XxSBB3pRm" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
        <node concept="VSNWy" id="51XxSBB3pRr" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
      </node>
      <node concept="3F0A7n" id="7jX2EUL01lV" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3WaPWglkAyp" resolve="id" />
        <node concept="VechU" id="7jX2EUL01mf" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="7jX2EUL01mA" role="3EZMnx">
        <property role="3F0ifm" value="for" />
      </node>
      <node concept="1iCGBv" id="51XxSBB41zc" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:51XxSBB41yU" resolve="dataSubject" />
        <node concept="1sVBvm" id="51XxSBB41ze" role="1sWHZn">
          <node concept="3F0A7n" id="51XxSBB41zy" role="2wV5jI">
            <property role="1Intyy" value="true" />
            <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
            <node concept="VechU" id="51XxSBB5Cc9" role="3F10Kt">
              <property role="Vb096" value="g1_qRwE/darkGreen" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3F0ifn" id="2ry5VKcXVyM" role="3EZMnx">
        <property role="3F0ifm" value="Sign date: " />
        <node concept="lj46D" id="51XxSBB363u" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0A7n" id="2ry5VKcXVyR" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVg8Bl" resolve="Signaturedate" />
        <node concept="VechU" id="51XxSBB3Hw7" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="2ry5VKcXVz1" role="3EZMnx">
        <property role="3F0ifm" value="Expiration date:" />
      </node>
      <node concept="3F0A7n" id="2ry5VKcXVzd" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVg8BP" resolve="Expirationdate" />
        <node concept="VechU" id="51XxSBB3Hw9" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="l2Vlx" id="2ry5VKcXVy$" role="2iSdaV" />
      <node concept="3F2HdR" id="2ry5VKcXV$5" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgh90" resolve="consent" />
        <node concept="l2Vlx" id="2ry5VKcXV$8" role="2czzBx" />
        <node concept="pVoyu" id="51XxSBB3pRv" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="5VnHNHVgyou">
    <ref role="1XX52x" to="20wa:5VnHNHVgjqK" resolve="DataRef" />
    <node concept="3EZMnI" id="5VnHNHVgBaY" role="2wV5jI">
      <node concept="3F0ifn" id="5VnHNHVgBb5" role="3EZMnx">
        <property role="3F0ifm" value="Data" />
        <node concept="lj46D" id="5VnHNHVi$er" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="pVoyu" id="2ry5VKd01ks" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="VechU" id="AQqjC1I2xm" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
        <node concept="VSNWy" id="AQqjC1IRy$" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
      </node>
      <node concept="1iCGBv" id="5VnHNHVgBcN" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:2olOl3C1TdP" resolve="dataref" />
        <node concept="1sVBvm" id="5VnHNHVgBcP" role="1sWHZn">
          <node concept="3F0A7n" id="5VnHNHVgBcY" role="2wV5jI">
            <property role="1Intyy" value="true" />
            <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
            <node concept="VechU" id="AQqjC1I2xr" role="3F10Kt">
              <property role="Vb096" value="g1_qRwE/darkGreen" />
            </node>
          </node>
        </node>
        <node concept="lj46D" id="5VnHNHViHgx" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="l2Vlx" id="5VnHNHVgBb1" role="2iSdaV" />
      <node concept="3F1sOY" id="5VnHNHVhpEq" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
        <node concept="lj46D" id="5VnHNHViZl0" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="5VnHNHVhIcD">
    <ref role="1XX52x" to="20wa:5VnHNHVgh92" resolve="Processing" />
    <node concept="3EZMnI" id="5VnHNHVhIcM" role="2wV5jI">
      <node concept="3F0ifn" id="7jX2EUKYYbu" role="3EZMnx">
        <property role="3F0ifm" value="Processing number" />
        <node concept="VechU" id="7jX2EUKYYd0" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
        <node concept="VSNWy" id="7jX2EUKYYd6" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
      </node>
      <node concept="3F0A7n" id="7jX2EUKYYcs" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:7jX2EUKYYaU" resolve="id" />
        <node concept="VechU" id="7jX2EUKYYcW" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVhIcW" role="3EZMnx">
        <property role="3F0ifm" value="Processing name" />
        <node concept="VechU" id="AQqjC1JaIc" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
        <node concept="VSNWy" id="AQqjC1JaIh" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
      </node>
      <node concept="l2Vlx" id="5VnHNHVhIcP" role="2iSdaV" />
      <node concept="3F0A7n" id="5VnHNHVhId2" role="3EZMnx">
        <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
        <node concept="ljvvj" id="5VnHNHVhIdY" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="VechU" id="AQqjC1JaI6" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
        <node concept="VSNWy" id="AQqjC1JaIp" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVhIdG" role="3EZMnx">
        <property role="3F0ifm" value="Type:" />
        <node concept="lj46D" id="5VnHNHVircB" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0A7n" id="5VnHNHVhIdQ" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgh97" resolve="tp" />
        <node concept="VechU" id="AQqjC1JaIa" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVhIe7" role="3EZMnx">
        <property role="3F0ifm" value="Category:" />
      </node>
      <node concept="3F0A7n" id="5VnHNHVhIeN" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgh99" resolve="pc" />
        <node concept="VechU" id="AQqjC1JaIu" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVhIf5" role="3EZMnx">
        <property role="3F0ifm" value="Create date:" />
      </node>
      <node concept="3F0A7n" id="5VnHNHVhIfp" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgh9c" resolve="createDate" />
        <node concept="VechU" id="AQqjC1JaIw" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVhIfJ" role="3EZMnx">
        <property role="3F0ifm" value="Updating date:" />
      </node>
      <node concept="3F0A7n" id="5VnHNHVhIg7" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgh9g" resolve="updatingDate" />
        <node concept="ljvvj" id="5VnHNHVhRbA" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="VechU" id="AQqjC1JaID" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F2HdR" id="5VnHNHVhRdl" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgh9G" resolve="dataUsed" />
        <node concept="l2Vlx" id="5VnHNHVhRdn" role="2czzBx" />
        <node concept="lj46D" id="5VnHNHViZkY" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F2HdR" id="7bfLM_U8aNG" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgiAP" resolve="purposes" />
        <node concept="l2Vlx" id="7bfLM_U8aNI" role="2czzBx" />
        <node concept="pVoyu" id="33K18miQGKO" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="33K18miQGKQ" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="5VnHNHVgyoB">
    <ref role="1XX52x" to="20wa:5VnHNHVgh9R" resolve="DataUsage" />
    <node concept="3EZMnI" id="5VnHNHVgyoD" role="2wV5jI">
      <node concept="3F0ifn" id="5VnHNHVgyoK" role="3EZMnx">
        <property role="3F0ifm" value="Usage" />
        <node concept="pVoyu" id="5VnHNHVgyoN" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="ljvvj" id="5VnHNHVgyoV" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="VechU" id="AQqjC1I2xy" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
        <node concept="VSNWy" id="AQqjC1IRyo" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVgyp3" role="3EZMnx">
        <property role="3F0ifm" value="hasPersonalUsage:" />
        <node concept="lj46D" id="5VnHNHVjhqy" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="pVoyu" id="68$ZZoCDhrH" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="l2Vlx" id="5VnHNHVgyoG" role="2iSdaV" />
      <node concept="3F0A7n" id="5VnHNHVgypf" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVghv9" resolve="hasPersonalUsage" />
        <node concept="ljvvj" id="5VnHNHVgypy" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="VechU" id="AQqjC1I2xF" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVgypG" role="3EZMnx">
        <property role="3F0ifm" value="Access rights: " />
        <node concept="lj46D" id="5VnHNHVjhq$" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVgypY" role="3EZMnx">
        <property role="3F0ifm" value="c:" />
      </node>
      <node concept="3F0A7n" id="5VnHNHVgyqi" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVghvb" resolve="c" />
        <node concept="VechU" id="AQqjC1I2xJ" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVgyqC" role="3EZMnx">
        <property role="3F0ifm" value="r:" />
      </node>
      <node concept="3F0A7n" id="5VnHNHVgyr0" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVghve" resolve="r" />
        <node concept="VechU" id="AQqjC1I2xL" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVgyrq" role="3EZMnx">
        <property role="3F0ifm" value="u:" />
      </node>
      <node concept="3F0A7n" id="5VnHNHVgyrQ" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVghvi" resolve="u" />
        <node concept="VechU" id="AQqjC1I2xN" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVgysk" role="3EZMnx">
        <property role="3F0ifm" value="d:" />
      </node>
      <node concept="3F0A7n" id="5VnHNHVgysO" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVghvn" resolve="d" />
        <node concept="VechU" id="AQqjC1I2xP" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="5VnHNHVhc4h">
    <ref role="1XX52x" to="20wa:5VnHNHVghPL" resolve="Purpose" />
    <node concept="3EZMnI" id="5VnHNHVhc4j" role="2wV5jI">
      <node concept="3F0ifn" id="33K18miQGKq" role="3EZMnx">
        <property role="3F0ifm" value="Purpose" />
        <node concept="pVoyu" id="33K18miQZwr" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="VechU" id="AQqjC1IRy1" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
        <node concept="VSNWy" id="AQqjC1IRyd" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
      </node>
      <node concept="3F0ifn" id="33K18miQZuI" role="3EZMnx">
        <property role="3F0ifm" value="Description:" />
        <node concept="pVoyu" id="33K18miQZwt" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="AQqjC1IRxV" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0A7n" id="33K18miQZuY" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVghPM" resolve="description" />
        <node concept="VechU" id="AQqjC1IRy5" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="33K18miQZvg" role="3EZMnx">
        <property role="3F0ifm" value="Type:" />
      </node>
      <node concept="3F0A7n" id="33K18miQZv$" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVghPO" resolve="type" />
        <node concept="VechU" id="AQqjC1IRy7" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="l2Vlx" id="5VnHNHVhc4m" role="2iSdaV" />
    </node>
  </node>
  <node concept="24kQdi" id="7NG5rl3dIGG">
    <ref role="1XX52x" to="20wa:w$4DGO$wJ3" resolve="PRIAM_GDPR" />
    <node concept="3EZMnI" id="7NG5rl3dIGI" role="2wV5jI">
      <node concept="3F0ifn" id="7NG5rl3fao6" role="3EZMnx">
        <property role="3F0ifm" value="PRIAM_GDPR" />
        <node concept="VechU" id="7NG5rl3fD2x" role="3F10Kt">
          <property role="Vb096" value="fLwANPn/red" />
        </node>
        <node concept="ljvvj" id="qb6YOZGp3P" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F1sOY" id="3FQc_Nkrhyd" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:4Xqrfpmh_pD" resolve="dataSubjectCategory" />
      </node>
      <node concept="l2Vlx" id="7NG5rl3dIGL" role="2iSdaV" />
    </node>
  </node>
  <node concept="24kQdi" id="2olOl3C3p__">
    <ref role="1XX52x" to="20wa:2olOl3C34Ay" resolve="PersonalDataAnnotation" />
    <node concept="3EZMnI" id="2olOl3C3p_B" role="2wV5jI">
      <node concept="3F0ifn" id="2olOl3C3IIv" role="3EZMnx">
        <property role="3F0ifm" value="Personal data annotation" />
        <node concept="VechU" id="2olOl3C43LE" role="3F10Kt">
          <property role="Vb096" value="fLwANPo/pink" />
        </node>
        <node concept="VSNWy" id="2olOl3C46Jv" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
      </node>
      <node concept="3F2HdR" id="2olOl3C3p_I" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:2olOl3C34Az" resolve="personalData" />
        <node concept="l2Vlx" id="2olOl3C3p_K" role="2czzBx" />
        <node concept="pVoyu" id="2olOl3C3II$" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="2olOl3C3IIA" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="pVoyu" id="2olOl3C46Jz" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="l2Vlx" id="2olOl3C3p_E" role="2iSdaV" />
    </node>
  </node>
  <node concept="24kQdi" id="2olOl3C7zwF">
    <ref role="1XX52x" to="20wa:2olOl3C6SBB" resolve="NonPersonalDataAnnotation" />
    <node concept="3EZMnI" id="2olOl3C7zwH" role="2wV5jI">
      <node concept="3F0ifn" id="2olOl3C7zwI" role="3EZMnx">
        <property role="3F0ifm" value="Non Personal Data Identification" />
        <node concept="VechU" id="2olOl3C7zwJ" role="3F10Kt">
          <property role="Vb096" value="fLwANPo/pink" />
        </node>
        <node concept="VSNWy" id="2olOl3C7zwK" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
      </node>
      <node concept="3F2HdR" id="2olOl3C7zwL" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:2olOl3C6SBC" resolve="nonPersonalData" />
        <node concept="l2Vlx" id="2olOl3C7zwM" role="2czzBx" />
        <node concept="pVoyu" id="2olOl3C7zwN" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="2olOl3C7zwO" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="pVoyu" id="2olOl3C7zwP" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="l2Vlx" id="2olOl3C7zwQ" role="2iSdaV" />
    </node>
  </node>
  <node concept="24kQdi" id="2olOl3C0Wwx">
    <ref role="1XX52x" to="20wa:2olOl3C0Wwg" resolve="NonPersonalData" />
    <node concept="3EZMnI" id="2olOl3C0WwD" role="2wV5jI">
      <node concept="l2Vlx" id="2olOl3C0WwE" role="2iSdaV" />
      <node concept="3F0ifn" id="2olOl3C0WwF" role="3EZMnx">
        <property role="3F0ifm" value="Data" />
        <node concept="VSNWy" id="2olOl3C0WwH" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
        <node concept="VechU" id="2olOl3C0WwI" role="3F10Kt">
          <property role="Vb096" value="6cZGtrcKCoS/black" />
          <node concept="1iSF2X" id="2olOl3C0WwJ" role="VblUZ">
            <property role="1iTho6" value="8c0000" />
          </node>
        </node>
        <node concept="pVoyu" id="2olOl3C8cHv" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0ifn" id="1PjvIwHAsTB" role="3EZMnx">
        <property role="3F0ifm" value="id:" />
      </node>
      <node concept="3F0A7n" id="1PjvIwHAsUd" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3WaPWglmSTC" resolve="id" />
        <node concept="VechU" id="brqeIhzGOE" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="2olOl3C0WwK" role="3EZMnx">
        <property role="3F0ifm" value="Attribute name:" />
        <node concept="VechU" id="2olOl3C0WwL" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
        <node concept="pVoyu" id="2olOl3C8cH$" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0A7n" id="2olOl3C0WwM" role="3EZMnx">
        <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
        <node concept="VechU" id="2olOl3C0WwN" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
        <node concept="A1WHr" id="2olOl3C0WwO" role="3vIgyS">
          <ref role="2ZyFGn" to="20wa:5VnHNHVgh9D" resolve="Data" />
        </node>
      </node>
      <node concept="3F0ifn" id="2olOl3C0WwP" role="3EZMnx">
        <property role="3F0ifm" value="Data type:" />
        <node concept="VechU" id="2olOl3C0WwQ" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
      </node>
      <node concept="1iCGBv" id="1j2riNJxRK" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:1j2riNJlah" resolve="dataType" />
        <node concept="1sVBvm" id="1j2riNJxRM" role="1sWHZn">
          <node concept="3F0A7n" id="1j2riNJxS6" role="2wV5jI">
            <property role="1Intyy" value="true" />
            <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
          </node>
        </node>
      </node>
      <node concept="VSNWy" id="2olOl3C0Wx1" role="3F10Kt">
        <property role="1lJzqX" value="14" />
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="1LId_7rTT9n">
    <ref role="1XX52x" to="20wa:51XxSBB9rbX" resolve="DataSubjectCategory" />
    <node concept="3EZMnI" id="1LId_7rTT9p" role="2wV5jI">
      <node concept="3F0ifn" id="1LId_7rTT9w" role="3EZMnx">
        <property role="3F0ifm" value="Data subject category" />
      </node>
      <node concept="3F0A7n" id="1LId_7rTT9A" role="3EZMnx">
        <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
        <node concept="VechU" id="1LId_7rV4u5" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="1LId_7rTT9I" role="3EZMnx">
        <property role="3F0ifm" value="ID reference" />
      </node>
      <node concept="3F0A7n" id="1LId_7rTT9S" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:51XxSBB9rc0" resolve="locationId" />
        <node concept="VechU" id="1LId_7rV4u7" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="1iCGBv" id="3FQc_NknGtc" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3FQc_NknC5N" resolve="personalData" />
        <node concept="1sVBvm" id="3FQc_NknGte" role="1sWHZn">
          <node concept="35HoNQ" id="3FQc_NknGtr" role="2wV5jI" />
        </node>
      </node>
      <node concept="l2Vlx" id="1LId_7rTT9s" role="2iSdaV" />
    </node>
  </node>
  <node concept="24kQdi" id="2gZmXhnCEXP">
    <ref role="1XX52x" to="20wa:3WaPWglfBNY" resolve="DataRequestAnswer" />
    <node concept="3EZMnI" id="2gZmXhnCEXR" role="2wV5jI">
      <node concept="3F0ifn" id="2gZmXhnCEXV" role="3EZMnx">
        <property role="3F0ifm" value="Answer to the " />
        <node concept="VechU" id="2gZmXhnDx5E" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
      </node>
      <node concept="1iCGBv" id="2gZmXhnCEXY" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3WaPWglfBO4" resolve="request" />
        <node concept="1sVBvm" id="2gZmXhnCEY0" role="1sWHZn">
          <node concept="3F0A7n" id="2gZmXhnCEY4" role="2wV5jI">
            <property role="1Intyy" value="true" />
            <ref role="1NtTu8" to="20wa:51XxSBB6uyX" resolve="type" />
          </node>
        </node>
        <node concept="VechU" id="2gZmXhnDx5G" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="2gZmXhnCEY7" role="3EZMnx">
        <property role="3F0ifm" value="request of data subject:" />
      </node>
      <node concept="1iCGBv" id="2gZmXhnCEYa" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3WaPWglfBO4" resolve="request" />
        <node concept="1sVBvm" id="2gZmXhnCEYc" role="1sWHZn">
          <node concept="1iCGBv" id="2gZmXhnCEYg" role="2wV5jI">
            <ref role="1NtTu8" to="20wa:51XxSBB6uy$" resolve="datasubject" />
            <node concept="1sVBvm" id="2gZmXhnCEYi" role="1sWHZn">
              <node concept="3F0A7n" id="2gZmXhnCEYm" role="2wV5jI">
                <property role="1Intyy" value="true" />
                <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
                <node concept="VechU" id="2gZmXhnDW3k" role="3F10Kt">
                  <property role="Vb096" value="g1_qRwE/darkGreen" />
                </node>
              </node>
            </node>
          </node>
        </node>
      </node>
      <node concept="l2Vlx" id="2gZmXhnCEXU" role="2iSdaV" />
      <node concept="3F0ifn" id="2gZmXhnCEYs" role="3EZMnx">
        <property role="3F0ifm" value="Answer: " />
        <node concept="pVoyu" id="2gZmXhnCEYw" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="2gZmXhnCEYx" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0A7n" id="2gZmXhnCEYz" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3WaPWglfBO1" resolve="answer" />
        <node concept="VechU" id="2gZmXhnDW3l" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="2gZmXhnCEYA" role="3EZMnx">
        <property role="3F0ifm" value="Justificatif:" />
      </node>
      <node concept="3F0A7n" id="2gZmXhnCEYD" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3WaPWglfBO6" resolve="proof" />
        <node concept="VechU" id="2gZmXhnDW3m" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="VSNWy" id="2gZmXhnDx5F" role="3F10Kt">
        <property role="1lJzqX" value="14" />
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="51XxSBB6uzd">
    <ref role="1XX52x" to="20wa:424h5AVf9rD" resolve="DataRequest" />
    <node concept="3EZMnI" id="51XxSBB6uzf" role="2wV5jI">
      <node concept="3F0ifn" id="51XxSBB6uzm" role="3EZMnx">
        <property role="3F0ifm" value="Request number" />
        <node concept="VechU" id="51XxSBB7w2K" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
        <node concept="VSNWy" id="51XxSBB7w2P" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
      </node>
      <node concept="3F0A7n" id="IIjfDnRGFS" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:7bfLM_U99lL" resolve="id" />
      </node>
      <node concept="3F0ifn" id="IIjfDnRGGU" role="3EZMnx">
        <property role="3F0ifm" value="of" />
      </node>
      <node concept="3F0A7n" id="51XxSBB6uzs" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:51XxSBB6uyX" resolve="type" />
        <node concept="VechU" id="51XxSBB6uCy" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
        <node concept="VSNWy" id="51XxSBB7w2W" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
      </node>
      <node concept="3F0ifn" id="51XxSBB6uz$" role="3EZMnx">
        <property role="3F0ifm" value="Data subject" />
      </node>
      <node concept="1iCGBv" id="51XxSBB6uzI" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:51XxSBB6uy$" resolve="datasubject" />
        <node concept="1sVBvm" id="51XxSBB6uzK" role="1sWHZn">
          <node concept="3F0A7n" id="51XxSBB6uzU" role="2wV5jI">
            <property role="1Intyy" value="true" />
            <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
            <node concept="VechU" id="51XxSBB6uCu" role="3F10Kt">
              <property role="Vb096" value="g1_qRwE/darkGreen" />
            </node>
          </node>
        </node>
        <node concept="VechU" id="51XxSBB6P3E" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="51XxSBB6u$a" role="3EZMnx">
        <property role="3F0ifm" value="Data" />
        <node concept="pVoyu" id="51XxSBB6u$l" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="51XxSBB6u$n" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="1iCGBv" id="51XxSBB6u$_" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:424h5AVfhA1" resolve="dataReq" />
        <node concept="1sVBvm" id="51XxSBB6u$B" role="1sWHZn">
          <node concept="3F0A7n" id="51XxSBB6u$R" role="2wV5jI">
            <property role="1Intyy" value="true" />
            <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
            <node concept="VechU" id="51XxSBB6uCo" role="3F10Kt">
              <property role="Vb096" value="g1_qRwE/darkGreen" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3F0ifn" id="51XxSBB6u_8" role="3EZMnx">
        <property role="3F0ifm" value="New value" />
      </node>
      <node concept="3F0A7n" id="51XxSBB6u_A" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:424h5AVf9rI" resolve="newValue" />
        <node concept="VechU" id="51XxSBB6uCl" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="51XxSBB6uA6" role="3EZMnx">
        <property role="3F0ifm" value="Claim" />
        <node concept="pVoyu" id="51XxSBB6uAU" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="51XxSBB6uAW" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0A7n" id="51XxSBB6uAC" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:424h5AVf9rk" resolve="claim" />
        <node concept="VechU" id="51XxSBB6uCq" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="51XxSBB6uBj" role="3EZMnx">
        <property role="3F0ifm" value="Claim date" />
      </node>
      <node concept="3F0A7n" id="51XxSBB6uBX" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:424h5AVf9rm" resolve="claimDate" />
        <node concept="VechU" id="51XxSBB6uCs" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="l2Vlx" id="51XxSBB6uzi" role="2iSdaV" />
    </node>
  </node>
  <node concept="24kQdi" id="5VnHNHVgl68">
    <ref role="1XX52x" to="20wa:AQqjC1K8N8" resolve="PersonalData" />
    <node concept="3EZMnI" id="5VnHNHVgvpO" role="2wV5jI">
      <node concept="l2Vlx" id="5VnHNHVgvpP" role="2iSdaV" />
      <node concept="3F0ifn" id="5VnHNHVgvpU" role="3EZMnx">
        <property role="3F0ifm" value="Data" />
        <ref role="1k5W1q" to="tpen:hgVS8CF" resolve="KeyWord" />
        <node concept="VSNWy" id="26QASX0cGXQ" role="3F10Kt">
          <property role="1lJzqX" value="14" />
        </node>
        <node concept="VechU" id="26QASX0cGXY" role="3F10Kt">
          <property role="Vb096" value="6cZGtrcKCoS/black" />
          <node concept="1iSF2X" id="26QASX0fg2O" role="VblUZ">
            <property role="1iTho6" value="8c0000" />
          </node>
        </node>
        <node concept="pVoyu" id="2olOl3C4s5J" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0ifn" id="3WaPWglmwEl" role="3EZMnx">
        <property role="3F0ifm" value="id:" />
      </node>
      <node concept="3F0A7n" id="3WaPWgln6GA" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3WaPWglmSTC" resolve="id" />
        <node concept="VechU" id="3WaPWgln6H1" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVgvql" role="3EZMnx">
        <property role="3F0ifm" value="Attribute name:" />
        <node concept="VechU" id="26QASX0e1ba" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
        <node concept="pVoyu" id="2olOl3C5nAi" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="40NILoOZkxv" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0A7n" id="5VnHNHVgvqx" role="3EZMnx">
        <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
        <node concept="VechU" id="26QASX0fg2Y" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
        <node concept="A1WHr" id="26QASX0cI1g" role="3vIgyS">
          <ref role="2ZyFGn" to="20wa:5VnHNHVgh9D" resolve="Data" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVgvrl" role="3EZMnx">
        <property role="3F0ifm" value="Data type:" />
        <node concept="VechU" id="26QASX0fg2Q" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
      </node>
      <node concept="1iCGBv" id="2ewkApshC7r" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:1j2riNJlah" resolve="dataType" />
        <node concept="1sVBvm" id="2ewkApshC7t" role="1sWHZn">
          <node concept="3F0A7n" id="2ewkApshC7W" role="2wV5jI">
            <property role="1Intyy" value="true" />
            <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
            <node concept="VechU" id="2ewkApshFb6" role="3F10Kt">
              <property role="Vb096" value="g1_qRwE/darkGreen" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3F0ifn" id="68$ZZoCDhrv" role="3EZMnx">
        <property role="3F0ifm" value="Category: " />
        <node concept="lj46D" id="68$ZZoCDhrI" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="1iCGBv" id="40NILoOZkxj" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:68$ZZoCzNiB" resolve="personalDataCategory" />
        <node concept="1sVBvm" id="40NILoOZkxl" role="1sWHZn">
          <node concept="3F0A7n" id="40NILoOZkxp" role="2wV5jI">
            <property role="1Intyy" value="true" />
            <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
            <node concept="VechU" id="40NILoOZYpL" role="3F10Kt">
              <property role="Vb096" value="g1_qRwE/darkGreen" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVgvrR" role="3EZMnx">
        <property role="3F0ifm" value="Source:" />
        <node concept="VechU" id="26QASX0fg2S" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
        <node concept="pVoyu" id="40NILoOZkxt" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="lj46D" id="40NILoOZkxu" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0A7n" id="5VnHNHVgvsb" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:5VnHNHVgh9K" resolve="source" />
        <node concept="VechU" id="26QASX0fg33" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="5VnHNHVgvsx" role="3EZMnx">
        <property role="3F0ifm" value="Data conservation" />
        <node concept="VechU" id="26QASX0fg2U" role="3F10Kt">
          <property role="Vb096" value="fLJRk5B/darkGray" />
        </node>
      </node>
      <node concept="3F0A7n" id="5VnHNHVgvsT" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:AQqjC1K8Nq" resolve="dataConservation" />
        <node concept="VechU" id="26QASX0fg35" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="VSNWy" id="26QASX0ffZF" role="3F10Kt">
        <property role="1lJzqX" value="14" />
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="qb6YOZJOaV">
    <ref role="1XX52x" to="20wa:1j2riNJlag" resolve="DataType" />
    <node concept="3EZMnI" id="qb6YOZJOaX" role="2wV5jI">
      <node concept="3F0ifn" id="2ewkApsmtcF" role="3EZMnx">
        <property role="3F0ifm" value="data type: " />
      </node>
      <node concept="3F0A7n" id="qb6YOZJObq" role="3EZMnx">
        <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
        <node concept="VechU" id="qb6YOZJRtJ" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
        <node concept="ljvvj" id="qb6YOZLIKM" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="l2Vlx" id="qb6YOZJOb0" role="2iSdaV" />
    </node>
  </node>
  <node concept="24kQdi" id="qb6YOZL3rU">
    <ref role="1XX52x" to="20wa:3FQc_Nkm_Ey" resolve="DataTypeList" />
    <node concept="3EZMnI" id="qb6YOZL3rY" role="2wV5jI">
      <node concept="3F0ifn" id="2ewkApsk9am" role="3EZMnx">
        <property role="3F0ifm" value="Data types:" />
      </node>
      <node concept="3F2HdR" id="2ewkApsk9at" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3FQc_Nkm_Ez" resolve="dataType" />
        <node concept="l2Vlx" id="2ewkApsk9av" role="2czzBx" />
      </node>
      <node concept="l2Vlx" id="qb6YOZL3s1" role="2iSdaV" />
    </node>
  </node>
  <node concept="24kQdi" id="4BkqmtKk$lG">
    <ref role="1XX52x" to="20wa:33K18miOFQF" resolve="DataSubject" />
    <node concept="3EZMnI" id="4BkqmtKk$lI" role="2wV5jI">
      <node concept="3F0ifn" id="4BkqmtKk$lM" role="3EZMnx">
        <property role="3F0ifm" value="Data Subject" />
        <node concept="ljvvj" id="4BkqmtKk$lP" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="l2Vlx" id="4BkqmtKk$lL" role="2iSdaV" />
      <node concept="3F0ifn" id="4BkqmtKk$lQ" role="3EZMnx">
        <property role="3F0ifm" value="Id:" />
      </node>
      <node concept="3F0A7n" id="4BkqmtKk$lT" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3WaPWglf9AR" resolve="id" />
        <node concept="VechU" id="1JttfezlRJU" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="4BkqmtKk$lW" role="3EZMnx">
        <property role="3F0ifm" value=" username:" />
      </node>
      <node concept="3F0A7n" id="4BkqmtKk$mc" role="3EZMnx">
        <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
        <node concept="VechU" id="1JttfezlRJV" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="4BkqmtKk$mf" role="3EZMnx">
        <property role="3F0ifm" value="age:" />
      </node>
      <node concept="3F0A7n" id="4BkqmtKk$mi" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:33K18miOFQN" resolve="age" />
        <node concept="ljvvj" id="4BkqmtKk$n8" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="VechU" id="1JttfezlRJX" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="4BkqmtKk$mo" role="3EZMnx">
        <property role="3F0ifm" value="category:" />
      </node>
      <node concept="1iCGBv" id="4BkqmtKk$mr" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
        <node concept="1sVBvm" id="4BkqmtKk$mt" role="1sWHZn">
          <node concept="3F0A7n" id="4BkqmtKk$mx" role="2wV5jI">
            <property role="1Intyy" value="true" />
            <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
            <node concept="VechU" id="1JttfezlRJZ" role="3F10Kt">
              <property role="Vb096" value="g1_qRwE/darkGreen" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3F0ifn" id="4BkqmtKk$m$" role="3EZMnx">
        <property role="3F0ifm" value="tutor:" />
      </node>
      <node concept="1iCGBv" id="4BkqmtKk$mB" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3WaPWgleThq" resolve="tutor" />
        <node concept="1sVBvm" id="4BkqmtKk$mD" role="1sWHZn">
          <node concept="3F0A7n" id="4BkqmtKk$mH" role="2wV5jI">
            <property role="1Intyy" value="true" />
            <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
            <node concept="VechU" id="1JttfezlRK0" role="3F10Kt">
              <property role="Vb096" value="g1_qRwE/darkGreen" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3F0ifn" id="4BkqmtKk$mX" role="3EZMnx">
        <property role="3F0ifm" value="country:" />
      </node>
      <node concept="3F0A7n" id="4BkqmtKk$n0" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:4BkqmtKkoIt" resolve="country" />
        <node concept="VechU" id="1JttfezlRK1" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="4BkqmtKk$n3" role="3EZMnx">
        <property role="3F0ifm" value="references id:" />
      </node>
      <node concept="3F0A7n" id="4BkqmtKk$n6" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:3WaPWgld_8O" resolve="idRef" />
        <node concept="VechU" id="1JttfezlRK2" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
    </node>
  </node>
  <node concept="24kQdi" id="68$ZZoC$v5U">
    <ref role="1XX52x" to="20wa:68$ZZoCzNi$" resolve="PersonalDataCategory" />
    <node concept="3EZMnI" id="68$ZZoC$v5W" role="2wV5jI">
      <node concept="3F0ifn" id="68$ZZoC$v68" role="3EZMnx">
        <property role="3F0ifm" value="id:" />
        <node concept="lj46D" id="68$ZZoC$v6f" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="pVoyu" id="68$ZZoCBLuI" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
      </node>
      <node concept="3F0A7n" id="68$ZZoC$v6c" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:68$ZZoCzNiA" resolve="id" />
        <node concept="VechU" id="68$ZZoC$v6K" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="3F0ifn" id="68$ZZoC$v6h" role="3EZMnx">
        <property role="3F0ifm" value="  Category name:" />
      </node>
      <node concept="3F0A7n" id="68$ZZoC$v6k" role="3EZMnx">
        <ref role="1NtTu8" to="tpck:h0TrG11" resolve="name" />
        <node concept="VechU" id="68$ZZoC$v6L" role="3F10Kt">
          <property role="Vb096" value="g1_qRwE/darkGreen" />
        </node>
      </node>
      <node concept="l2Vlx" id="68$ZZoC$v5Z" role="2iSdaV" />
    </node>
  </node>
  <node concept="24kQdi" id="68$ZZoC$v6W">
    <ref role="1XX52x" to="20wa:68$ZZoCzNiC" resolve="ListPersonalDataCat" />
    <node concept="3EZMnI" id="68$ZZoC$v6Y" role="2wV5jI">
      <node concept="3F0ifn" id="68$ZZoCB4$o" role="3EZMnx">
        <property role="3F0ifm" value="Personal data categories" />
        <node concept="ljvvj" id="68$ZZoCB4$q" role="3F10Kt">
          <property role="VOm3f" value="true" />
        </node>
        <node concept="VechU" id="68$ZZoCB4$s" role="3F10Kt">
          <property role="Vb096" value="fLwANPn/red" />
        </node>
      </node>
      <node concept="3F2HdR" id="68$ZZoC$v72" role="3EZMnx">
        <ref role="1NtTu8" to="20wa:68$ZZoCzNiD" resolve="personalDataCategory" />
        <node concept="l2Vlx" id="68$ZZoC$v74" role="2czzBx" />
      </node>
      <node concept="l2Vlx" id="68$ZZoC$v71" role="2iSdaV" />
    </node>
  </node>
</model>

