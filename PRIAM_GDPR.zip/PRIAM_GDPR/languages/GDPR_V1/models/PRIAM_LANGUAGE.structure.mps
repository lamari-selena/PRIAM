<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:515d5f51-79c9-42c9-bba4-54c97b772d5b(PRIAM_LANGUAGE.structure)">
  <persistence version="9" />
  <languages>
    <use id="c72da2b9-7cce-4447-8389-f407dc1158b7" name="jetbrains.mps.lang.structure" version="9" />
    <use id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage" version="11" />
    <devkit ref="78434eb8-b0e5-444b-850d-e7c4ad2da9ab(jetbrains.mps.devkit.aspect.structure)" />
  </languages>
  <imports>
    <import index="tpce" ref="r:00000000-0000-4000-0000-011c89590292(jetbrains.mps.lang.structure.structure)" />
    <import index="tpck" ref="r:00000000-0000-4000-0000-011c89590288(jetbrains.mps.lang.core.structure)" implicit="true" />
  </imports>
  <registry>
    <language id="c72da2b9-7cce-4447-8389-f407dc1158b7" name="jetbrains.mps.lang.structure">
      <concept id="3348158742936976480" name="jetbrains.mps.lang.structure.structure.EnumerationMemberDeclaration" flags="ng" index="25R33">
        <property id="1421157252384165432" name="memberId" index="3tVfz5" />
        <property id="672037151186491528" name="presentation" index="1L1pqM" />
      </concept>
      <concept id="3348158742936976479" name="jetbrains.mps.lang.structure.structure.EnumerationDeclaration" flags="ng" index="25R3W">
        <reference id="1075010451642646892" name="defaultMember" index="1H5jkz" />
        <child id="3348158742936976577" name="members" index="25R1y" />
      </concept>
      <concept id="1082978164218" name="jetbrains.mps.lang.structure.structure.DataTypeDeclaration" flags="ng" index="AxPO6">
        <property id="7791109065626895363" name="datatypeId" index="3F6X1D" />
      </concept>
      <concept id="1169125787135" name="jetbrains.mps.lang.structure.structure.AbstractConceptDeclaration" flags="ig" index="PkWjJ">
        <property id="6714410169261853888" name="conceptId" index="EcuMT" />
        <property id="4628067390765956802" name="abstract" index="R5$K7" />
        <property id="5092175715804935370" name="conceptAlias" index="34LRSv" />
        <child id="1071489727083" name="linkDeclaration" index="1TKVEi" />
        <child id="1071489727084" name="propertyDeclaration" index="1TKVEl" />
      </concept>
      <concept id="1169127622168" name="jetbrains.mps.lang.structure.structure.InterfaceConceptReference" flags="ig" index="PrWs8">
        <reference id="1169127628841" name="intfc" index="PrY4T" />
      </concept>
      <concept id="1071489090640" name="jetbrains.mps.lang.structure.structure.ConceptDeclaration" flags="ig" index="1TIwiD">
        <property id="1096454100552" name="rootable" index="19KtqR" />
        <reference id="1071489389519" name="extends" index="1TJDcQ" />
        <child id="1169129564478" name="implements" index="PzmwI" />
      </concept>
      <concept id="1071489288299" name="jetbrains.mps.lang.structure.structure.PropertyDeclaration" flags="ig" index="1TJgyi">
        <property id="241647608299431129" name="propertyId" index="IQ2nx" />
        <reference id="1082985295845" name="dataType" index="AX2Wp" />
      </concept>
      <concept id="1071489288298" name="jetbrains.mps.lang.structure.structure.LinkDeclaration" flags="ig" index="1TJgyj">
        <property id="1071599776563" name="role" index="20kJfa" />
        <property id="1071599893252" name="sourceCardinality" index="20lbJX" />
        <property id="1071599937831" name="metaClass" index="20lmBu" />
        <property id="241647608299431140" name="linkId" index="IQ2ns" />
        <reference id="1071599976176" name="target" index="20lvS9" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ng" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
    </language>
  </registry>
  <node concept="1TIwiD" id="5VnHNHVg8Bi">
    <property role="EcuMT" value="6834132425656797650" />
    <property role="TrG5h" value="Contract" />
    <property role="34LRSv" value="contract" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyi" id="3WaPWglkAyp" role="1TKVEl">
      <property role="IQ2nx" value="4542680411327850649" />
      <property role="TrG5h" value="id" />
      <ref role="AX2Wp" to="tpck:fKAQMTA" resolve="integer" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVg8Bl" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656797653" />
      <property role="TrG5h" value="Signaturedate" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVg8BP" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656797685" />
      <property role="TrG5h" value="Expirationdate" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyj" id="5VnHNHVgh90" role="1TKVEi">
      <property role="IQ2ns" value="6834132425656832576" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="consent" />
      <property role="20lbJX" value="fLJekj6/_1__n" />
      <ref role="20lvS9" node="5VnHNHVgh8l" resolve="Consent" />
    </node>
    <node concept="1TJgyj" id="51XxSBB41yU" role="1TKVEi">
      <property role="IQ2ns" value="5799940921479927994" />
      <property role="20kJfa" value="dataSubject" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="33K18miOFQF" resolve="DataSubject" />
    </node>
  </node>
  <node concept="1TIwiD" id="5VnHNHVgh8l">
    <property role="EcuMT" value="6834132425656832533" />
    <property role="TrG5h" value="Consent" />
    <property role="34LRSv" value="consent" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyj" id="5VnHNHVgh95" role="1TKVEi">
      <property role="IQ2ns" value="6834132425656832581" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="processing" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="2ry5VKd0csX" resolve="ProcessingRef" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVgh9$" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656832612" />
      <property role="TrG5h" value="startDate" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVgh9A" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656832614" />
      <property role="TrG5h" value="endDate" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
  </node>
  <node concept="1TIwiD" id="5VnHNHVgh92">
    <property role="EcuMT" value="6834132425656832578" />
    <property role="TrG5h" value="Processing" />
    <property role="19KtqR" value="true" />
    <property role="34LRSv" value="processing" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="PrWs8" id="5VnHNHVgh93" role="PzmwI">
      <ref role="PrY4T" to="tpck:h0TrEE$" resolve="INamedConcept" />
    </node>
    <node concept="1TJgyi" id="7jX2EUKYYaU" role="1TKVEl">
      <property role="IQ2nx" value="8429905822917321402" />
      <property role="TrG5h" value="id" />
      <ref role="AX2Wp" to="tpck:fKAQMTA" resolve="integer" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVgh97" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656832583" />
      <property role="TrG5h" value="tp" />
      <ref role="AX2Wp" node="4Xqrfpm3WaZ" resolve="ProcessingType" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVgh99" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656832585" />
      <property role="TrG5h" value="pc" />
      <ref role="AX2Wp" node="33K18miOFRx" resolve="ProcessingCategory" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVgh9c" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656832588" />
      <property role="TrG5h" value="createDate" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVgh9g" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656832592" />
      <property role="TrG5h" value="updatingDate" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyj" id="5VnHNHVgiAP" role="1TKVEi">
      <property role="IQ2ns" value="6834132425656838581" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="purposes" />
      <property role="20lbJX" value="fLJekj6/_1__n" />
      <ref role="20lvS9" node="5VnHNHVghPL" resolve="Purpose" />
    </node>
    <node concept="1TJgyj" id="5VnHNHVgh9G" role="1TKVEi">
      <property role="IQ2ns" value="6834132425656832620" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="dataUsed" />
      <property role="20lbJX" value="fLJekj6/_1__n" />
      <ref role="20lvS9" node="5VnHNHVgjqK" resolve="DataRef" />
    </node>
  </node>
  <node concept="1TIwiD" id="5VnHNHVghPL">
    <property role="EcuMT" value="6834132425656835441" />
    <property role="TrG5h" value="Purpose" />
    <property role="34LRSv" value="purpose" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyi" id="5VnHNHVghPM" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656835442" />
      <property role="TrG5h" value="description" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVghPO" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656835444" />
      <property role="TrG5h" value="type" />
      <ref role="AX2Wp" node="33K18miOIUy" resolve="PurposeType" />
    </node>
  </node>
  <node concept="1TIwiD" id="2ry5VKd0csX">
    <property role="EcuMT" value="2801828014617315133" />
    <property role="TrG5h" value="ProcessingRef" />
    <property role="34LRSv" value="processing" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyj" id="2ry5VKd0yKm" role="1TKVEi">
      <property role="IQ2ns" value="2801828014617406486" />
      <property role="20kJfa" value="processing" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="5VnHNHVgh92" resolve="Processing" />
    </node>
    <node concept="1TJgyi" id="5Drs5VZG6Fq" role="1TKVEl">
      <property role="IQ2nx" value="6510921239613172442" />
      <property role="TrG5h" value="consented" />
      <ref role="AX2Wp" to="tpck:fKAQMTB" resolve="boolean" />
    </node>
  </node>
  <node concept="1TIwiD" id="5VnHNHVgh9D">
    <property role="EcuMT" value="6834132425656832617" />
    <property role="TrG5h" value="Data" />
    <property role="34LRSv" value="data" />
    <property role="R5$K7" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyi" id="3WaPWglmSTC" role="1TKVEl">
      <property role="IQ2nx" value="4542680411328450152" />
      <property role="TrG5h" value="id" />
      <ref role="AX2Wp" to="tpck:fKAQMTA" resolve="integer" />
    </node>
    <node concept="PrWs8" id="AQqjC1LPha" role="PzmwI">
      <ref role="PrY4T" to="tpce:1ob16QT2yIl" resolve="INamedStructureElement" />
    </node>
    <node concept="1TJgyj" id="1j2riNJlah" role="1TKVEi">
      <property role="IQ2ns" value="23373094781276817" />
      <property role="20kJfa" value="dataType" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="1j2riNJlag" resolve="DataType" />
    </node>
  </node>
  <node concept="1TIwiD" id="5VnHNHVgjqK">
    <property role="EcuMT" value="6834132425656841904" />
    <property role="TrG5h" value="DataRef" />
    <property role="34LRSv" value="dataRef" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyj" id="2olOl3C1TdP" role="1TKVEi">
      <property role="IQ2ns" value="2744329693372584821" />
      <property role="20kJfa" value="dataref" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="5VnHNHVgh9D" resolve="Data" />
    </node>
    <node concept="1TJgyj" id="5VnHNHVgjqN" role="1TKVEi">
      <property role="IQ2ns" value="6834132425656841907" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="dataUsage" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="5VnHNHVgh9R" resolve="DataUsage" />
    </node>
  </node>
  <node concept="1TIwiD" id="33K18miOFQF">
    <property role="EcuMT" value="3526323479971544491" />
    <property role="TrG5h" value="DataSubject" />
    <property role="34LRSv" value="dataSubject" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" node="33K18miOFQD" resolve="MainActor" />
    <node concept="1TJgyi" id="33K18miOFQN" role="1TKVEl">
      <property role="IQ2nx" value="3526323479971544499" />
      <property role="TrG5h" value="age" />
      <ref role="AX2Wp" to="tpck:fKAQMTA" resolve="integer" />
    </node>
    <node concept="1TJgyi" id="3WaPWgld_8O" role="1TKVEl">
      <property role="IQ2nx" value="4542680411326009908" />
      <property role="TrG5h" value="idRef" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyj" id="3WaPWgleS5k" role="1TKVEi">
      <property role="IQ2ns" value="4542680411326349652" />
      <property role="20kJfa" value="dsCategory" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="51XxSBB9rbX" resolve="DataSubjectCategory" />
    </node>
    <node concept="1TJgyj" id="3WaPWgleThq" role="1TKVEi">
      <property role="IQ2ns" value="4542680411326354522" />
      <property role="20kJfa" value="tutor" />
      <ref role="20lvS9" node="33K18miOFQH" resolve="Tutor" />
    </node>
  </node>
  <node concept="1TIwiD" id="5VnHNHVgh9R">
    <property role="EcuMT" value="6834132425656832631" />
    <property role="TrG5h" value="DataUsage" />
    <property role="34LRSv" value="dataUsage" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyi" id="5VnHNHVghv9" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656833993" />
      <property role="TrG5h" value="hasPersonalUsage" />
      <ref role="AX2Wp" to="tpck:fKAQMTB" resolve="boolean" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVghvb" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656833995" />
      <property role="TrG5h" value="c" />
      <ref role="AX2Wp" to="tpck:fKAQMTB" resolve="boolean" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVghve" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656833998" />
      <property role="TrG5h" value="r" />
      <ref role="AX2Wp" to="tpck:fKAQMTB" resolve="boolean" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVghvi" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656834002" />
      <property role="TrG5h" value="u" />
      <ref role="AX2Wp" to="tpck:fKAQMTB" resolve="boolean" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVghvn" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656834007" />
      <property role="TrG5h" value="d" />
      <ref role="AX2Wp" to="tpck:fKAQMTB" resolve="boolean" />
    </node>
  </node>
  <node concept="1TIwiD" id="424h5AVf9rG">
    <property role="EcuMT" value="4648915867537282796" />
    <property role="TrG5h" value="ProcessingRequest" />
    <property role="34LRSv" value="processingRequest" />
    <property role="R5$K7" value="true" />
    <ref role="1TJDcQ" node="424h5AVf9rj" resolve="Request" />
    <node concept="1TJgyj" id="424h5AVfh_Z" role="1TKVEi">
      <property role="IQ2ns" value="4648915867537316223" />
      <property role="20kJfa" value="processingReq" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="5VnHNHVgh92" resolve="Processing" />
    </node>
  </node>
  <node concept="1TIwiD" id="33K18miOFQH">
    <property role="EcuMT" value="3526323479971544493" />
    <property role="TrG5h" value="Tutor" />
    <property role="34LRSv" value="tutor" />
    <ref role="1TJDcQ" node="33K18miOFQD" resolve="MainActor" />
    <node concept="1TJgyi" id="33K18miOFRg" role="1TKVEl">
      <property role="IQ2nx" value="3526323479971544528" />
      <property role="TrG5h" value="tutorName" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
  </node>
  <node concept="25R3W" id="51XxSBB6uz1">
    <property role="3F6X1D" value="5799940921480571073" />
    <property role="TrG5h" value="TypeDatarequest" />
    <node concept="25R33" id="51XxSBB6uz2" role="25R1y">
      <property role="3tVfz5" value="5799940921480571074" />
      <property role="TrG5h" value="Rectification" />
      <property role="1L1pqM" value="rectification" />
    </node>
    <node concept="25R33" id="51XxSBB6uz3" role="25R1y">
      <property role="3tVfz5" value="5799940921480571075" />
      <property role="TrG5h" value="Forgotten" />
      <property role="1L1pqM" value="Forgotten" />
    </node>
  </node>
  <node concept="1TIwiD" id="33K18miOFQE">
    <property role="EcuMT" value="3526323479971544490" />
    <property role="TrG5h" value="SecondaryActor" />
    <property role="R5$K7" value="true" />
    <ref role="1TJDcQ" node="33K18miOFQC" resolve="Actor" />
  </node>
  <node concept="1TIwiD" id="424h5AVf9rj">
    <property role="EcuMT" value="4648915867537282771" />
    <property role="TrG5h" value="Request" />
    <property role="R5$K7" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyi" id="7bfLM_U99lL" role="1TKVEl">
      <property role="IQ2nx" value="8273050021459694961" />
      <property role="TrG5h" value="id" />
      <ref role="AX2Wp" to="tpck:fKAQMTA" resolve="integer" />
    </node>
    <node concept="1TJgyi" id="424h5AVf9rk" role="1TKVEl">
      <property role="IQ2nx" value="4648915867537282772" />
      <property role="TrG5h" value="claim" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="424h5AVf9rm" role="1TKVEl">
      <property role="IQ2nx" value="4648915867537282774" />
      <property role="TrG5h" value="claimDate" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
  </node>
  <node concept="25R3W" id="33K18miOIUy">
    <property role="3F6X1D" value="3526323479971557026" />
    <property role="TrG5h" value="PurposeType" />
    <node concept="25R33" id="33K18miOIUz" role="25R1y">
      <property role="3tVfz5" value="3526323479971557027" />
      <property role="TrG5h" value="Main" />
      <property role="1L1pqM" value="Main" />
    </node>
    <node concept="25R33" id="33K18miOIU$" role="25R1y">
      <property role="3tVfz5" value="3526323479971557028" />
      <property role="TrG5h" value="Secondary" />
      <property role="1L1pqM" value="Secondary" />
    </node>
  </node>
  <node concept="1TIwiD" id="33K18miOFQG">
    <property role="EcuMT" value="3526323479971544492" />
    <property role="TrG5h" value="Provider" />
    <property role="34LRSv" value="provider" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" node="33K18miOFQD" resolve="MainActor" />
    <node concept="1TJgyi" id="33K18miOFQP" role="1TKVEl">
      <property role="IQ2nx" value="3526323479971544501" />
      <property role="TrG5h" value="prName" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="33K18miOFQR" role="1TKVEl">
      <property role="IQ2nx" value="3526323479971544503" />
      <property role="TrG5h" value="prAdress" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="33K18miOFQU" role="1TKVEl">
      <property role="IQ2nx" value="3526323479971544506" />
      <property role="TrG5h" value="prPostalCode" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="33K18miOFQY" role="1TKVEl">
      <property role="IQ2nx" value="3526323479971544510" />
      <property role="TrG5h" value="city" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="33K18miOFR3" role="1TKVEl">
      <property role="IQ2nx" value="3526323479971544515" />
      <property role="TrG5h" value="prPhone" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="33K18miOFR9" role="1TKVEl">
      <property role="IQ2nx" value="3526323479971544521" />
      <property role="TrG5h" value="prEmail" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
  </node>
  <node concept="25R3W" id="4Xqrfpm3WaZ">
    <property role="3F6X1D" value="5718002482161894079" />
    <property role="TrG5h" value="ProcessingType" />
    <ref role="1H5jkz" node="4Xqrfpm3WbQ" resolve="Optional" />
    <node concept="25R33" id="4Xqrfpm3WbQ" role="25R1y">
      <property role="3tVfz5" value="5718002482161894134" />
      <property role="TrG5h" value="Optional" />
      <property role="1L1pqM" value="Optional" />
    </node>
    <node concept="25R33" id="4Xqrfpm3WbS" role="25R1y">
      <property role="3tVfz5" value="5718002482161894136" />
      <property role="TrG5h" value="Mandatory" />
      <property role="1L1pqM" value="Mandatory" />
    </node>
    <node concept="25R33" id="4Xqrfpm3WbV" role="25R1y">
      <property role="3tVfz5" value="5718002482161894139" />
      <property role="TrG5h" value="Default" />
      <property role="1L1pqM" value="Dafault" />
    </node>
  </node>
  <node concept="25R3W" id="33K18miOFRx">
    <property role="3F6X1D" value="3526323479971544545" />
    <property role="TrG5h" value="ProcessingCategory" />
    <ref role="1H5jkz" node="33K18miOFRy" resolve="Consent_Contract" />
    <node concept="25R33" id="33K18miOFRy" role="25R1y">
      <property role="3tVfz5" value="3526323479971544546" />
      <property role="TrG5h" value="Consent_Contract" />
      <property role="1L1pqM" value="Consent_Contract" />
    </node>
    <node concept="25R33" id="33K18miOFRz" role="25R1y">
      <property role="3tVfz5" value="3526323479971544547" />
      <property role="TrG5h" value="LegitimateInterest" />
      <property role="1L1pqM" value="LegitimateInterest" />
    </node>
    <node concept="25R33" id="33K18miOFRA" role="25R1y">
      <property role="3tVfz5" value="3526323479971544550" />
      <property role="TrG5h" value="LegalObligation" />
      <property role="1L1pqM" value="LegalObligation" />
    </node>
    <node concept="25R33" id="33K18miOFRE" role="25R1y">
      <property role="3tVfz5" value="3526323479971544554" />
      <property role="TrG5h" value="publicInterest" />
      <property role="1L1pqM" value="publicInterest" />
    </node>
    <node concept="25R33" id="33K18miOFRJ" role="25R1y">
      <property role="3tVfz5" value="3526323479971544559" />
      <property role="TrG5h" value="VitalInterests" />
      <property role="1L1pqM" value="VitalInterests" />
    </node>
  </node>
  <node concept="1TIwiD" id="w$4DGO$wJ3">
    <property role="EcuMT" value="586614309276224451" />
    <property role="TrG5h" value="PRIAM_GDPR" />
    <property role="19KtqR" value="true" />
    <property role="34LRSv" value="PRIAM_GDPR" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyj" id="4Xqrfpmh_pD" role="1TKVEi">
      <property role="IQ2ns" value="5718002482165470825" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="dataSubjectCategory" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="51XxSBB9rbX" resolve="DataSubjectCategory" />
    </node>
  </node>
  <node concept="1TIwiD" id="2olOl3C34Ay">
    <property role="EcuMT" value="2744329693372893602" />
    <property role="TrG5h" value="PersonalDataAnnotation" />
    <property role="34LRSv" value="PDAnnotation" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyj" id="2olOl3C34Az" role="1TKVEi">
      <property role="IQ2ns" value="2744329693372893603" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="personalData" />
      <property role="20lbJX" value="fLJekj5/_0__n" />
      <ref role="20lvS9" node="AQqjC1K8N8" resolve="PersonalData" />
    </node>
  </node>
  <node concept="1TIwiD" id="2olOl3C6SBB">
    <property role="EcuMT" value="2744329693373893095" />
    <property role="TrG5h" value="NonPersonalDataAnnotation" />
    <property role="19KtqR" value="true" />
    <property role="34LRSv" value="NPDAnnotation" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyj" id="2olOl3C6SBC" role="1TKVEi">
      <property role="IQ2ns" value="2744329693373893096" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="nonPersonalData" />
      <property role="20lbJX" value="fLJekj5/_0__n" />
      <ref role="20lvS9" node="2olOl3C0Wwg" resolve="NonPersonalData" />
    </node>
  </node>
  <node concept="1TIwiD" id="2olOl3C0Wwg">
    <property role="EcuMT" value="2744329693372336144" />
    <property role="TrG5h" value="NonPersonalData" />
    <property role="34LRSv" value="nonPersonalData" />
    <ref role="1TJDcQ" node="5VnHNHVgh9D" resolve="Data" />
    <node concept="PrWs8" id="2olOl3C0Wwh" role="PzmwI">
      <ref role="PrY4T" to="tpck:h0TrEE$" resolve="INamedConcept" />
    </node>
  </node>
  <node concept="1TIwiD" id="33K18miOFQD">
    <property role="EcuMT" value="3526323479971544489" />
    <property role="TrG5h" value="MainActor" />
    <property role="R5$K7" value="true" />
    <ref role="1TJDcQ" node="33K18miOFQC" resolve="Actor" />
    <node concept="PrWs8" id="51XxSBB4Efj" role="PzmwI">
      <ref role="PrY4T" to="tpce:6TyNL3imAnw" resolve="INamedAspect" />
    </node>
  </node>
  <node concept="1TIwiD" id="3FQc_Nkm_Ey">
    <property role="EcuMT" value="4248638672751712930" />
    <property role="TrG5h" value="DataTypeList" />
    <property role="34LRSv" value="dataTypeList" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyj" id="3FQc_Nkm_Ez" role="1TKVEi">
      <property role="IQ2ns" value="4248638672751712931" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="dataType" />
      <property role="20lbJX" value="fLJekj6/_1__n" />
      <ref role="20lvS9" node="1j2riNJlag" resolve="DataType" />
    </node>
  </node>
  <node concept="1TIwiD" id="1j2riNJlag">
    <property role="EcuMT" value="23373094781276816" />
    <property role="TrG5h" value="DataType" />
    <property role="34LRSv" value="dataType" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="PrWs8" id="1j2riNJlaj" role="PzmwI">
      <ref role="PrY4T" to="tpck:h0TrEE$" resolve="INamedConcept" />
    </node>
  </node>
  <node concept="1TIwiD" id="51XxSBB9rbX">
    <property role="EcuMT" value="5799940921481343741" />
    <property role="TrG5h" value="DataSubjectCategory" />
    <property role="34LRSv" value="dataSubjectCategory" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="PrWs8" id="51XxSBB9rbY" role="PzmwI">
      <ref role="PrY4T" to="tpck:h0TrEE$" resolve="INamedConcept" />
    </node>
    <node concept="1TJgyi" id="51XxSBB9rc0" role="1TKVEl">
      <property role="IQ2nx" value="5799940921481343744" />
      <property role="TrG5h" value="locationId" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyj" id="3FQc_NknC5N" role="1TKVEi">
      <property role="IQ2ns" value="4248638672751985011" />
      <property role="20kJfa" value="personalData" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="2olOl3C34Ay" resolve="PersonalDataAnnotation" />
    </node>
  </node>
  <node concept="1TIwiD" id="3WaPWglfBNY">
    <property role="EcuMT" value="4542680411326545150" />
    <property role="TrG5h" value="DataRequestAnswer" />
    <property role="19KtqR" value="true" />
    <property role="34LRSv" value="answer" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyj" id="3WaPWglfBO4" role="1TKVEi">
      <property role="IQ2ns" value="4542680411326545156" />
      <property role="20kJfa" value="request" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="424h5AVf9rD" resolve="DataRequest" />
    </node>
    <node concept="1TJgyi" id="3WaPWglfBNZ" role="1TKVEl">
      <property role="IQ2nx" value="4542680411326545151" />
      <property role="TrG5h" value="id" />
      <ref role="AX2Wp" to="tpck:fKAQMTA" resolve="integer" />
    </node>
    <node concept="1TJgyi" id="3WaPWglfBO1" role="1TKVEl">
      <property role="IQ2nx" value="4542680411326545153" />
      <property role="TrG5h" value="answer" />
      <ref role="AX2Wp" to="tpck:fKAQMTB" resolve="boolean" />
    </node>
    <node concept="1TJgyi" id="9qZcQHY3SN" role="1TKVEl">
      <property role="IQ2nx" value="169725896297037363" />
      <property role="TrG5h" value="answerDate" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="3WaPWglfBO6" role="1TKVEl">
      <property role="IQ2nx" value="4542680411326545158" />
      <property role="TrG5h" value="proof" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
  </node>
  <node concept="1TIwiD" id="424h5AVf9rD">
    <property role="EcuMT" value="4648915867537282793" />
    <property role="TrG5h" value="DataRequest" />
    <property role="34LRSv" value="dataRequest" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" node="424h5AVf9rj" resolve="Request" />
    <node concept="1TJgyi" id="424h5AVf9rI" role="1TKVEl">
      <property role="IQ2nx" value="4648915867537282798" />
      <property role="TrG5h" value="newValue" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
    <node concept="1TJgyi" id="2U9My3wrBmN" role="1TKVEl">
      <property role="IQ2nx" value="3353433640107144627" />
      <property role="TrG5h" value="isIsolated" />
      <ref role="AX2Wp" to="tpck:fKAQMTB" resolve="boolean" />
    </node>
    <node concept="1TJgyi" id="51XxSBB6uyX" role="1TKVEl">
      <property role="IQ2nx" value="5799940921480571069" />
      <property role="TrG5h" value="type" />
      <ref role="AX2Wp" node="51XxSBB6uz1" resolve="TypeDatarequest" />
    </node>
    <node concept="1TJgyj" id="424h5AVfhA1" role="1TKVEi">
      <property role="IQ2ns" value="4648915867537316225" />
      <property role="20kJfa" value="dataReq" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="AQqjC1K8N8" resolve="PersonalData" />
    </node>
    <node concept="1TJgyj" id="51XxSBB6uy$" role="1TKVEi">
      <property role="IQ2ns" value="5799940921480571044" />
      <property role="20kJfa" value="datasubject" />
      <property role="20lbJX" value="fLJekj4/_1" />
      <ref role="20lvS9" node="33K18miOFQF" resolve="DataSubject" />
    </node>
  </node>
  <node concept="1TIwiD" id="33K18miOFRk">
    <property role="EcuMT" value="3526323479971544532" />
    <property role="TrG5h" value="Context" />
    <property role="34LRSv" value="context" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyj" id="33K18miOFRl" role="1TKVEi">
      <property role="IQ2ns" value="3526323479971544533" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="processings" />
      <property role="20lbJX" value="fLJekj6/_1__n" />
      <ref role="20lvS9" node="5VnHNHVgh92" resolve="Processing" />
    </node>
    <node concept="1TJgyj" id="brqeIhzGOf" role="1TKVEi">
      <property role="IQ2ns" value="205873568944147727" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="ontology" />
      <property role="20lbJX" value="fLJekj5/_0__n" />
      <ref role="20lvS9" node="14uVSwuOUGX" resolve="Ontology" />
    </node>
    <node concept="1TJgyi" id="33K18miOFRn" role="1TKVEl">
      <property role="IQ2nx" value="3526323479971544535" />
      <property role="TrG5h" value="environmentName" />
      <ref role="AX2Wp" to="tpck:fKAOsGN" resolve="string" />
    </node>
  </node>
  <node concept="1TIwiD" id="33K18miOFQC">
    <property role="EcuMT" value="3526323479971544488" />
    <property role="TrG5h" value="Actor" />
    <property role="R5$K7" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyi" id="3WaPWglf9AR" role="1TKVEl">
      <property role="IQ2nx" value="4542680411326421431" />
      <property role="TrG5h" value="id" />
      <ref role="AX2Wp" to="tpck:fKAQMTA" resolve="integer" />
    </node>
    <node concept="1TJgyi" id="4BkqmtKkoIt" role="1TKVEl">
      <property role="IQ2nx" value="5319992952818338717" />
      <property role="TrG5h" value="country" />
      <ref role="AX2Wp" node="4BkqmtKkjtT" resolve="Country" />
    </node>
  </node>
  <node concept="1TIwiD" id="AQqjC1K8N8">
    <property role="EcuMT" value="699862489961106632" />
    <property role="TrG5h" value="PersonalData" />
    <property role="34LRSv" value="personalData" />
    <ref role="1TJDcQ" node="5VnHNHVgh9D" resolve="Data" />
    <node concept="1TJgyj" id="68$ZZoCzNiB" role="1TKVEi">
      <property role="IQ2ns" value="7072058747586032807" />
      <property role="20kJfa" value="personalDataCategory" />
      <ref role="20lvS9" node="68$ZZoCzNi$" resolve="PersonalDataCategory" />
    </node>
    <node concept="1TJgyi" id="AQqjC1K8Nq" role="1TKVEl">
      <property role="IQ2nx" value="699862489961106650" />
      <property role="TrG5h" value="dataConservation" />
      <ref role="AX2Wp" to="tpck:fKAQMTA" resolve="integer" />
    </node>
    <node concept="1TJgyi" id="5VnHNHVgh9K" role="1TKVEl">
      <property role="IQ2nx" value="6834132425656832624" />
      <property role="TrG5h" value="source" />
      <ref role="AX2Wp" node="5l7YRmKfOvi" resolve="Source" />
    </node>
    <node concept="PrWs8" id="AQqjC1KunA" role="PzmwI">
      <ref role="PrY4T" to="tpck:h0TrEE$" resolve="INamedConcept" />
    </node>
  </node>
  <node concept="25R3W" id="5l7YRmKfOvi">
    <property role="3F6X1D" value="6145156699457013714" />
    <property role="TrG5h" value="Source" />
    <ref role="1H5jkz" node="5l7YRmKfOvj" resolve="Direct" />
    <node concept="25R33" id="5l7YRmKfOvj" role="25R1y">
      <property role="3tVfz5" value="6145156699457013715" />
      <property role="TrG5h" value="Direct" />
    </node>
    <node concept="25R33" id="5l7YRmKfOvk" role="25R1y">
      <property role="3tVfz5" value="6145156699457013716" />
      <property role="TrG5h" value="Indirect" />
    </node>
    <node concept="25R33" id="5l7YRmKfOvn" role="25R1y">
      <property role="3tVfz5" value="6145156699457013719" />
      <property role="TrG5h" value="Produced" />
    </node>
  </node>
  <node concept="25R3W" id="4BkqmtKkjtT">
    <property role="3F6X1D" value="5319992952818317177" />
    <property role="TrG5h" value="Country" />
    <node concept="25R33" id="4BkqmtKkjtU" role="25R1y">
      <property role="3tVfz5" value="5319992952818317178" />
      <property role="TrG5h" value="Spain" />
    </node>
    <node concept="25R33" id="4BkqmtKkjtV" role="25R1y">
      <property role="3tVfz5" value="5319992952818317179" />
      <property role="TrG5h" value="USA" />
    </node>
    <node concept="25R33" id="4BkqmtKkjtW" role="25R1y">
      <property role="3tVfz5" value="5319992952818317180" />
      <property role="TrG5h" value="Algeria" />
    </node>
  </node>
  <node concept="1TIwiD" id="68$ZZoCzNi$">
    <property role="EcuMT" value="7072058747586032804" />
    <property role="TrG5h" value="PersonalDataCategory" />
    <property role="34LRSv" value="personalDataCateogry" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="PrWs8" id="68$ZZoCzNi_" role="PzmwI">
      <ref role="PrY4T" to="tpck:h0TrEE$" resolve="INamedConcept" />
    </node>
    <node concept="1TJgyi" id="68$ZZoCzNiA" role="1TKVEl">
      <property role="IQ2nx" value="7072058747586032806" />
      <property role="TrG5h" value="id" />
      <ref role="AX2Wp" to="tpck:fKAQMTA" resolve="integer" />
    </node>
  </node>
  <node concept="1TIwiD" id="68$ZZoCzNiC">
    <property role="EcuMT" value="7072058747586032808" />
    <property role="TrG5h" value="ListPersonalDataCat" />
    <property role="34LRSv" value="ListPersonalDataCategory" />
    <property role="19KtqR" value="true" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="1TJgyj" id="68$ZZoCzNiD" role="1TKVEi">
      <property role="IQ2ns" value="7072058747586032809" />
      <property role="20lmBu" value="fLJjDmT/aggregation" />
      <property role="20kJfa" value="personalDataCategory" />
      <property role="20lbJX" value="fLJekj5/_0__n" />
      <ref role="20lvS9" node="68$ZZoCzNi$" resolve="PersonalDataCategory" />
    </node>
  </node>
  <node concept="1TIwiD" id="14uVSwuOUGX">
    <property role="EcuMT" value="1233686715857873725" />
    <property role="TrG5h" value="Ontology" />
    <ref role="1TJDcQ" to="tpck:gw2VY9q" resolve="BaseConcept" />
    <node concept="PrWs8" id="14uVSwuOUGY" role="PzmwI">
      <ref role="PrY4T" to="tpck:h0TrEE$" resolve="INamedConcept" />
    </node>
  </node>
</model>

